// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"

#include <chrono>
#include <thread>
using namespace std::this_thread;
using namespace std::chrono_literals;
using namespace Rcpp;


/*
    Definiere Invers-Gauss-Verteilung
*/

class InverseGauss : public Family 
{
  protected:
    const double dispersion;
    virtual const arma::vec random_observation_independent(const arma::vec &expectation) const;
    virtual const arma::vec random_observation(const arma::vec &expectation) const;
    virtual const double log_likelihood(const double &observation, const double &expectation) const;
  public:
    InverseGauss(const double &disp, const bool &only_positive, const Rcpp::Nullable<Rcpp::S4> &copula_obj, const char* link_name_r) : Family(only_positive, copula_obj, "inverse_gaussian", link_name_r), dispersion(disp){
      R_family = Rcpp::Environment("package:stats")["inverse.gaussian"]; // Wozu??
    };
    InverseGauss(const double &disp, const bool &only_positive, const char* link_name_r) : Family(only_positive, "inverse_gaussian", link_name_r), dispersion(disp) {};
    virtual const bool valid_expectation(const arma::mat &x) const;
    virtual const arma::mat variance_fun(const arma::mat &link_values) const;
};

// Siehe Wikipedia
const arma::vec InverseGauss::random_observation_independent(const arma::vec &expectation) const
{
    arma::vec observations(expectation.n_elem, arma::fill::zeros);
    arma::vec random_normal(expectation.n_elem, arma::fill::randn);
    random_normal = arma::square(random_normal);
    arma::vec transform = expectation;
    transform += (arma::square(expectation) % random_normal) / (2.0 * dispersion);
    transform -= (expectation / (2.0 * dispersion)) % arma::sqrt(4.0 * dispersion * (expectation % random_normal) + arma::square(expectation) % arma::square(random_normal));
    arma::vec accept(expectation.n_elem, arma::fill::randu);
    for(unsigned int i = 0; i < expectation.n_elem; i++)
    {
        observations(i) = accept(i) * (expectation(i) + transform(i)) <= expectation(i) ? transform(i) : expectation(i) * expectation(i) / transform(i);
    }
    return observations;
}

const arma::vec InverseGauss::random_observation(const arma::vec &expectation) const
{
    arma::vec observations(expectation.n_elem, arma::fill::zeros);
    arma::vec copula_values(expectation.n_elem);
    copula_values = as<arma::vec>(this->copula_sample(1, this->copula_object));

    arma::vec random_normal(expectation.n_elem, arma::fill::randn);
    random_normal = arma::square(random_normal);
    arma::vec transform = expectation;
    transform += (arma::square(expectation) % random_normal) / (2.0 * dispersion);
    transform -= (expectation / (2.0 * dispersion)) % arma::sqrt(4.0 * dispersion * (expectation % random_normal) + arma::square(expectation) % arma::square(random_normal));
    for(unsigned int i = 0; i < expectation.n_elem; i++)
    {
        observations(i) = copula_values(i) * (expectation(i) + transform(i)) <= expectation(i) ? transform(i) : expectation(i) * expectation(i) / transform(i);
    }
    return observations;
}

const double InverseGauss::log_likelihood(const double &observation, const double &expectation) const 
{
    double value = - (observation - expectation) * (observation - expectation) / (2.0 * expectation * observation * dispersion);
    value -= 0.5 * std::log(2 * arma::datum::pi * dispersion * observation * observation * observation);
    return value;
}

const bool InverseGauss::valid_expectation(const arma::mat &x) const 
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}

const arma::mat InverseGauss::variance_fun(const arma::mat &link_values) const
{
    arma::mat response = this->inverse_link(link_values);
    return (response % response % response) * dispersion;
}


/*
    Definiere Modell mit natuerlichem Link
*/


class NaturalInverseGauss : public InverseGauss {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    NaturalInverseGauss(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : InverseGauss(disp, true, copula_obj, "1/mu^2"){};
    NaturalInverseGauss(const double &disp) : InverseGauss(disp, true, "1/mu^2"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new NaturalInverseGauss(this->dispersion, this->copula_object);
      } else {
        return new NaturalInverseGauss(this->dispersion);
      }
    };
};


const double NaturalInverseGauss::inverse_link(const double x) const
{
  return 1.0 / std::sqrt(x);
}

const double NaturalInverseGauss::derivative_inverse_link(const double x) const
{
  return -0.5 / (x * std::sqrt(x));
}


const double NaturalInverseGauss::observation_trafo(const double x) const
{
  return 1.0 / (x * x);
}

const double NaturalInverseGauss::link_trafo(const double x) const
{
  return x;
}

const double NaturalInverseGauss::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool NaturalInverseGauss::valid_link(const arma::mat &x) const
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}

/*
    Definiere inverse-Link
*/

class InverseInverseGauss : public InverseGauss {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    InverseInverseGauss(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : InverseGauss(disp, true, copula_obj, "inverse"){};
    InverseInverseGauss(const double &disp) : InverseGauss(disp, true, "inverse"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new InverseInverseGauss(this->dispersion, this->copula_object);
      } else {
        return new InverseInverseGauss(this->dispersion);
      }
    };
};



const double InverseInverseGauss::inverse_link(const double x) const
{
  return 1.0 / x;
}

const double InverseInverseGauss::derivative_inverse_link(const double x) const
{
  return -1.0 / (x * x);
}


const double InverseInverseGauss::observation_trafo(const double x) const
{
  return 1.0 / x;
}

const double InverseInverseGauss::link_trafo(const double x) const
{
  return x;
}

const double InverseInverseGauss::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool InverseInverseGauss::valid_link(const arma::mat &x) const
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}

/*
    Definiere Identity-Link
*/

class LinearInverseGauss : public InverseGauss {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LinearInverseGauss(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : InverseGauss(disp, true, copula_obj, "identity"){};
    LinearInverseGauss(const double &disp) : InverseGauss(disp, true, "identity"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LinearInverseGauss(this->dispersion, this->copula_object);
      } else {
        return new LinearInverseGauss(this->dispersion);
      }
    };
};

const double LinearInverseGauss::inverse_link(const double x) const
{
  return x;
}

const double LinearInverseGauss::derivative_inverse_link(const double x) const
{
  return 1.0;
}


const double LinearInverseGauss::observation_trafo(const double x) const
{
  return x;
}

const double LinearInverseGauss::link_trafo(const double x) const
{
  return x;
}

const double LinearInverseGauss::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LinearInverseGauss::valid_link(const arma::mat &x) const
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}


/*
    Definiere log-Link
*/

class LogInverseGauss : public InverseGauss {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LogInverseGauss(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : InverseGauss(disp, false, copula_obj, "log"){};
    LogInverseGauss(const double &disp) : InverseGauss(disp, false, "log"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LogInverseGauss(this->dispersion, this->copula_object);
      } else {
        return new LogInverseGauss(this->dispersion);
      }
    };
};

const double LogInverseGauss::inverse_link(const double x) const
{
  return exp(x);
}

const double LogInverseGauss::derivative_inverse_link(const double x) const
{
  return exp(x);
}


const double LogInverseGauss::observation_trafo(const double x) const
{
  return log(x);
}

const double LogInverseGauss::link_trafo(const double x) const
{
  return x;
}

const double LogInverseGauss::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LogInverseGauss::valid_link(const arma::mat &x) const
{
  return true;
}



Family * generate_inverse_gaussian(const Rcpp::List &family)
{
  Rcpp::CharacterVector link = family["link"];
  Rcpp::NumericVector dispersion = family["shape"];
  double dispersion_param = 1.0 / dispersion[0];
  if(link[0] == "log")
  {
    return new LogInverseGauss(dispersion_param);
  } 
  else if(link[0] == "identity") 
  {
    return new LinearInverseGauss(dispersion_param);
  } 
  else if(link[0] == "inverse") 
  {
    return new InverseInverseGauss(dispersion_param);
  }
  else if(link[0] == "1/mu^2") 
  {
    return new NaturalInverseGauss(dispersion_param);
  } 
  else
  {
    throw std::invalid_argument("The desired link is currently not yet implemented.");
  }
}


Family * generate_inverse_gaussian(const Rcpp::List &family, Rcpp::S4& copula_obj)
{
  Rcpp::CharacterVector link = family["link"];
  Rcpp::NumericVector dispersion = family["shape"];
  double dispersion_param = 1.0 / dispersion[0];
  if(link[0] == "log")
  {
    return new LogInverseGauss(dispersion_param, copula_obj);
  } 
  else if(link[0] == "identity") 
  {
    return new LinearInverseGauss(dispersion_param, copula_obj);
  } 
  else if(link[0] == "inverse") 
  {
    return new InverseInverseGauss(dispersion_param, copula_obj);
  }
  else if(link[0] == "1/mu^2") 
  {
    return new NaturalInverseGauss(dispersion_param, copula_obj);
  } 
  else
  {
    throw std::invalid_argument("The desired link is currently not yet implemented.");
  }
}




