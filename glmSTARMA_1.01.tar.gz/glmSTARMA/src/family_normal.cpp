// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"

#include <chrono>
#include <thread>
using namespace std::this_thread;
using namespace std::chrono_literals;
using namespace Rcpp;



/*
    Definiere Normal-Verteilung
*/

class Normal : public Family 
{
  protected:
    const double dispersion;
    virtual const arma::vec random_observation_independent(const arma::vec &expectation) const;
    virtual const arma::vec random_observation(const arma::vec &expectation) const;
    virtual const double log_likelihood(const double &observation, const double &expectation) const;
  public:
    Normal(const double &disp, const bool &only_positive, const Rcpp::Nullable<Rcpp::S4> &copula_obj, const char* link_name_r) : Family(only_positive, copula_obj, "gaussian", link_name_r), dispersion(disp){
      R_family = Rcpp::Environment("package:stats")["Gaussian"]; // Wozu??
    };
    Normal(const double &disp, const bool &only_positive, const char* link_name_r) : Family(only_positive, "gaussian", link_name_r), dispersion(disp) {};
    virtual const bool valid_expectation(const arma::mat &x) const;
    virtual const arma::mat variance_fun(const arma::mat &link_values) const;
};


const arma::vec Normal::random_observation_independent(const arma::vec &expectation) const
{
  arma::vec observations(expectation.n_elem, arma::fill::randn);
  observations *= std::sqrt(dispersion);
  observations += expectation;
  return observations;
}

const arma::vec Normal::random_observation(const arma::vec &expectation) const
{
    arma::vec observations(expectation.n_elem, arma::fill::zeros);
    arma::vec copula_values(expectation.n_elem);
    copula_values = as<arma::vec>(this->copula_sample(1, this->copula_object));
    for(unsigned int i = 0; i < expectation.n_elem; i++)
    {
        observations(i) = R::qnorm( copula_values(i), expectation(i), std::sqrt(dispersion), true, false );
    }
    return observations;
}

const double Normal::log_likelihood(const double &observation, const double &expectation) const 
{
  return R::dnorm(observation, expectation, std::log(dispersion), true);
}

const bool Normal::valid_expectation(const arma::mat &x) const 
{
  return x.is_finite();
}

const arma::mat Normal::variance_fun(const arma::mat &link_values) const
{
    arma::mat result(link_values.n_rows, link_values.n_cols);
    result.fill(dispersion);
    return result;
}


/*
    Definiere Identity-Link
*/

class LinearNormal : public Normal {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LinearNormal(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Normal(disp, false, copula_obj, "identity"){};
    LinearNormal(const double &disp) : Normal(disp, false, "identity"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LinearNormal(this->dispersion, this->copula_object);
      } else {
        return new LinearNormal(this->dispersion);
      }
    };
};


const double LinearNormal::inverse_link(const double x) const
{
  return x;
}

const double LinearNormal::derivative_inverse_link(const double x) const
{
  return 1.0;
}


const double LinearNormal::observation_trafo(const double x) const
{
  return x;
}

const double LinearNormal::link_trafo(const double x) const
{
  return x;
}

const double LinearNormal::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LinearNormal::valid_link(const arma::mat &x) const
{
  return true;
}


/*
    Definiere log-link
*/

class LogNormal : public Normal {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LogNormal(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Normal(disp, false, copula_obj, "log"){};
    LogNormal(const double &disp) : Normal(disp, false, "log"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LogNormal(this->dispersion, this->copula_object);
      } else {
        return new LogNormal(this->dispersion);
      }
    };
};


const double LogNormal::inverse_link(const double x) const
{
  return exp(x);
}

const double LogNormal::derivative_inverse_link(const double x) const
{
  return exp(x);
}


const double LogNormal::observation_trafo(const double x) const
{
    double y = x < 0 ? -x : x;
    y = (y == 0.0) ? 1e-8 : y;
    return log(y);
}

const double LogNormal::link_trafo(const double x) const
{
  return x;
}

const double LogNormal::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LogNormal::valid_link(const arma::mat &x) const
{
  return true;
}

/*
    Definiere Inverse-Link
*/


class InverseNormal : public Normal {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    InverseNormal(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Normal(disp, false, copula_obj, "inverse"){};
    InverseNormal(const double &disp) : Normal(disp, false, "inverse"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new InverseNormal(this->dispersion, this->copula_object);
      } else {
        return new InverseNormal(this->dispersion);
      }
    };
};


const double InverseNormal::inverse_link(const double x) const
{
  return 1.0 / x;
}

const double InverseNormal::derivative_inverse_link(const double x) const
{
  return -1.0 / (x * x);
}


const double InverseNormal::observation_trafo(const double x) const
{
  return 1.0 / x;
}

const double InverseNormal::link_trafo(const double x) const
{
  return x;
}

const double InverseNormal::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool InverseNormal::valid_link(const arma::mat &x) const
{
  return true;
}



Family * generate_normal(const Rcpp::List &family)
{
  Rcpp::CharacterVector link = family["link"];
  Rcpp::NumericVector dispersion = family["sigma2"];
  double dispersion_param = dispersion[0];
  if(link[0] == "log")
  {
    return new LogNormal(dispersion_param);
  } 
  else if(link[0] == "identity") 
  {
    return new LinearNormal(dispersion_param);
  } 
  else if(link[0] == "inverse") 
  {
    return new InverseNormal(dispersion_param);
  } 
  else
  {
    throw std::invalid_argument("The desired link is currently not yet implemented.");
  }
}


Family * generate_normal(const Rcpp::List &family, Rcpp::S4& copula_obj)
{
  Rcpp::CharacterVector link = family["link"];
  Rcpp::NumericVector dispersion = family["sigma2"];
  double dispersion_param = dispersion[0];
  if(link[0] == "log")
  {
    return new LogNormal(dispersion_param, copula_obj);
  } 
  else if(link[0] == "identity") 
  {
    return new LinearNormal(dispersion_param, copula_obj);
  } 
  else if(link[0] == "inverse") 
  {
    return new InverseNormal(dispersion_param, copula_obj);
  } 
  else
  {
    throw std::invalid_argument("The desired link is currently not yet implemented.");
  }
}






