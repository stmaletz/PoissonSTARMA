// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"
#include <nloptrAPI.h>

#include <chrono>
#include <thread>

#include <roptim.h>
// [[Rcpp::depends(roptim)]]
using namespace roptim;
using namespace std::this_thread;
using namespace std::chrono_literals;


/*
    Hilfsfunktionen und Klassen:
*/

template <typename T> int sgn(T val) {
    return (T(0) < val) - (val < T(0));
}

/*
typedef struct indexe {
    unsigned int lower_index;
    unsigned int upper_index;
    indexe(unsigned int li, unsigned int ui) : lower_index(li), upper_index(ui){};
} autoregressive_index;
*/

class optim_model : public Functor
{
    public:
    ModelOrderInformation * orders;
    Data * data;
    Family * family;

    arma::mat link_init;
    arma::vec score;
    arma::mat information;
    
    arma::mat link_values;
    arma::mat design;
    arma::mat design_covariates_internal;
    arma::mat derivatives;

    optim_model(ModelOrderInformation * model_orders, Data * dataset, DynamicModelInformation * start_values, Family * fam, arma::mat init_link){
        orders = model_orders;
        data = dataset;
        family = fam;

        link_init = init_link;  
        score = start_values->score;
        information = start_values->information;
        link_values = start_values->link_values;
        design = start_values->design;
        design_covariates_internal = start_values->design_covariates_internal;
        derivatives = start_values->derivatives;
    }

    double operator()(const arma::vec &x) override {
        return -Model::log_likelihood(x, score, information, link_values, design, design_covariates_internal, derivatives, *orders, data, family, link_init, false, false);
    }
    void Gradient(const arma::vec &x, arma::vec &gr) override {
        Model::log_likelihood(x, gr, information, link_values, design, design_covariates_internal, derivatives, *orders, data, family, link_init, true, false);
        gr = -gr;
    }
    void Hessian(const arma::vec &x, arma::mat &he) override {
        Model::log_likelihood(x, score, he, link_values, design, design_covariates_internal, derivatives, *orders, data, family, link_init, true, true);
        he = -he;
    }
};




/*
    Optimierung über die Funktion optim in R
*/

class optim : public FittingObject {
    Roptim<optim_model> opt;
    optim_model to_optimize;
    public:
    optim(ModelOrderInformation * model_orders, Data * dataset, DynamicModelInformation * start_values, Family * fam, arma::mat init_link, Rcpp::List control) : FittingObject("optim", fam->only_positive_parameters ? "L-BFGS-B" : "BFGS"), to_optimize(model_orders, dataset, start_values, fam, init_link)
    {
        if(fam->only_positive_parameters)
        {
            opt.set_method("L-BFGS-B");
            opt.set_lower(arma::zeros(model_orders->n_param));
            Rcpp::IntegerVector lmm = control["lmm"];
            Rcpp::NumericVector factr = control["factr"];
            Rcpp::NumericVector pgtol = control["pgtol"];

            opt.control.lmm = lmm[0];
            opt.control.factr = factr[0];
            opt.control.pgtol = pgtol[0];
        }
        else
        {
            opt.set_method("BFGS");
            Rcpp::NumericVector abstol = control["abstol"];
            Rcpp::NumericVector reltol = control["reltol"];

            opt.control.abstol = abstol[0];
            opt.control.reltol = reltol[0];
        }
        Rcpp::IntegerVector trace = control["trace"];
        Rcpp::NumericVector fnscale = control["fnscale"];
        Rcpp::IntegerVector maxit = control["maxit"];

        opt.control.trace = trace[0];
        opt.control.fnscale = fnscale[0];
        opt.control.maxit = maxit[0];
        opt.set_hessian(false);
    };

    arma::vec fit(arma::vec start_value)
    {
        start_vector = arma::vec(start_value);
        arma::vec x = start_value;
        auto start_time = std::chrono::high_resolution_clock::now();

        opt.minimize(to_optimize, x);

        auto stop_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop_time - start_time);
        fitting_time = duration.count();

        // Rcpp::LogicalVector convergence = opt.convergence();
        converged = opt.convergence();
        message = opt.message();

        fcounter = opt.fncount();
        grcounter = opt.grcount();
        info_counter = 0;

        return opt.par();
    };
};



/*
    Optimierung mit der Funktion fastglm
*/


class fastglm : public FittingObject
{
    private:

    arma::mat design;
    arma::vec observations;
    const Rcpp::Function fastglmPure = Rcpp::Environment("package:fastglm")["fastglmPure"];
    Rcpp::List R_family;
    Rcpp::IntegerVector maxit;
    Rcpp::NumericVector tolerance;

    public:
    fastglm(ModelOrderInformation * model_orders, Data * dataset, DynamicModelInformation * start_values, Family * fam, arma::mat init_link, Rcpp::List control) : FittingObject("fastglm", "fisher scoring")
    {
        Rcpp::Function Rfamily = fam->R_family;
        R_family = Rfamily(fam->link_name);
        observations = arma::vectorise(dataset->ts.tail_cols(model_orders->n_obs_effective));
        design = start_values->design;
        maxit = control["maxit"];
        tolerance = control["reltol"];
    };

    arma::vec fit(arma::vec start_value)
    {
        start_vector = arma::vec(start_value);
        auto start_time = std::chrono::high_resolution_clock::now();

        Rcpp::List result = fastglmPure(Rcpp::Named("x") = design, Rcpp::Named("y") = observations, Rcpp::Named("family") = R_family, Rcpp::Named("start") = start_value, Rcpp::Named("tol") = tolerance, Rcpp::Named("maxit") = maxit);
        
        auto stop_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop_time - start_time);
        fitting_time = duration.count();
        Rcpp::LogicalVector convergence = result["converged"];
        converged = Rcpp::is_true( Rcpp::all( convergence ) );
        message = Rcpp::CharacterVector("No message availabe");

        Rcpp::IntegerVector iterations = result["iter"];
        fcounter = iterations[0];
        grcounter = iterations[0];
        info_counter = iterations[0];

        Rcpp::NumericVector coef = result["coefficients"];
        return Rcpp::as<arma::vec>(coef);
    }

};


/*
    TODO:
    Optimierung ueber selbst-implementiertes Fisher-Scoring
*/

/*

class FisherScoring : public FittingObject {
    private:
    int maxit;
    arma::vec prev_param;
    arma::vec step;
    arma::vec new_param;
    double step_length = 1.0;
    double tolerance, grad_tolerance, change_tolerance;
    bool conv;
    double qll, qllold;
    double score_norm;
    bool ignore_negatives, refit;

    public:
    FisherScoring(glmstarma model_and_data, Rcpp::List control){
        Rcpp::IntegerVector iter_limit = control["maxit"];
        Rcpp::NumericVector reltol = control["reltol"];
        Rcpp::NumericVector gradtol = control["gradtol"];
        Rcpp::NumericVector changetol = control["changetol"];
        Rcpp::CharacterVector negative_params = control["negative_params"];
        maxit = iter_limit[0];
        tolerance = reltol[0];
        grad_tolerance = gradtol[0];
        change_tolerance = changetol[0];
        conv = false;

        if((!model_and_data.model->family->only_positive_parameters) || (negative_params[0] == "ignore") ){
            ignore_negatives = true;
            refit = false;
        } else {
            if(negative_params[0] == "clamp"){
                ignore_negatives = false;
                refit = false;
            } else {
                ignore_negatives = false;
                refit = true;
            }
        }


        prev_param = arma::zeros(model_and_data.model->n_param);
        step = arma::zeros(model_and_data.model->n_param);
        new_param = arma::zeros(model_and_data.model->n_param);
        score_norm = 1.0;

    }
    Rcpp::List fit(glmstarma model_and_data, arma::vec start_value){
        // model_and_data->model->set_pars_from_vec(start_value);
        prev_param = start_value;
        int i;
        for(i = 0; i < maxit; i++){
            qllold = model_and_data.model->log_likelihood;
            step_length = 1.0;
            step = arma::solve(model_and_data.model->information, model_and_data.model->score);
            int ittr = 0;
            // Check for boundary violations and infinite likelihood
            new_param = prev_param + step_length * step;
            while(!model_and_data.model->update_if_valid(new_param, model_and_data.data)){
                ittr++;
                if(ittr > maxit){
                    break;
                }
                step_length *= 0.5;
                new_param = prev_param + step_length * step;
            }
            qll = model_and_data.model->log_likelihood;
            if(std::isinf(qll)){
                break;
            }
            // Check for decreasing quasi-loglikelihood
            ittr = 0;
            while ((qll - qllold) / (0.1  + std::abs(qll)) <= -tolerance && i > 0) {
                ittr++;
                if(ittr > maxit){
                    break;
                }
                step_length *= 0.5;
                new_param = prev_param + step_length * step;
                model_and_data.model->update_if_valid(new_param, model_and_data.data);
                qll = model_and_data.model->log_likelihood;
            }
            score_norm = arma::norm(model_and_data.model->score, 2);

            if(converged()){
                conv = true;
                break;
            }
            prev_param = new_param;
        }

        if(conv && !ignore_negatives){
            if(refit){
                i += refit_model(model_and_data, i);
            } else {
                new_param.clamp(0.0, new_param.max());
                model_and_data.model->update_if_valid(new_param, model_and_data.data);
                qll = model_and_data.model->log_likelihood;
            }
        }
        return Rcpp::List::create(Rcpp::Named("value") = qll,
                                  Rcpp::Named("fncount") = i,
                                  Rcpp::Named("grcount") = i,
                                  Rcpp::Named("convergence") = conv);
    }
    bool converged(){
        bool convergence = std::abs(qll - qllold) / (0.1 + std::abs(qll)) < tolerance;
        convergence = convergence || (score_norm < grad_tolerance);
        convergence = convergence || ((arma::norm(new_param - prev_param, 1) / (arma::norm(prev_param, 1) + 0.1)) < change_tolerance);
        return convergence;
    }
    int refit_model(glmstarma model_and_data, int i){
        int iterations = 0;
        int j;
        arma::vec temp_param;
        arma::vec temp_score;
        arma::mat temp_info;
        while(arma::any(new_param < 0.0) && (iterations < maxit - i)){
            arma::uvec positives = arma::find(new_param > 0.0);
            unsigned int number_of_positives = positives.n_elem;
            arma::mat trafo_matrix(number_of_positives, new_param.n_elem);
            for(unsigned int iter = 0; iter < number_of_positives; iter++){
                trafo_matrix(iter, positives(iter)) = 1.0;
            }
            prev_param = (trafo_matrix.t() * trafo_matrix) * new_param;
            // prev_param.clamp(0.0, prev_param.max());
            model_and_data.model->update_if_valid(prev_param, model_and_data.data);

            for(j = 0; j < maxit; j++){
                qllold = model_and_data.model->log_likelihood;
                step_length = 1.0;
                temp_score = trafo_matrix * model_and_data.model->score;
                temp_info = trafo_matrix * model_and_data.model->information * trafo_matrix.t();
                // step = arma::solve(temp_info, temp_score);
                step = trafo_matrix.t() * arma::solve(temp_info, temp_score);
                int ittr = 0;
                // Check for boundary violations and infinite likelihood
                new_param = prev_param + step_length * step;
                while(!model_and_data.model->update_if_valid(new_param, model_and_data.data)){
                    ittr++;
                    if(ittr > maxit){
                        break;
                    }
                    step_length *= 0.5;
                    new_param = prev_param + step_length * step;
                }
                qll = model_and_data.model->log_likelihood;
                if(std::isinf(qll)){
                    break;
                }
                // Check for decreasing quasi-loglikelihood
                ittr = 0;
                while ((qll - qllold) / (0.1  + std::abs(qll)) <= -tolerance && i > 0) {
                    ittr++;
                    if(ittr > maxit){
                        break;
                    }
                    step_length *= 0.5;
                    new_param = prev_param + step_length * step;
                    model_and_data.model->update_if_valid(new_param, model_and_data.data);
                    qll = model_and_data.model->log_likelihood;
                }
                score_norm = arma::norm(temp_score, 2);
                if(converged()){
                    conv = true;
                    break;
                }
                prev_param = new_param;
                iterations++;
            }
        }
        return iterations;
    }
};

*/

/*
    Optimierung mit der nloptr-Bibliothek:
*/

/*

unsigned int fcounter; // set in fit
        unsigned int grcounter; // set in fit
        unsigned int info_counter; // set in fit
        long long int fitting_time; // set in fit
        arma::vec start_vector; // set in fit
        bool converged; // set in fit
        Rcpp::CharacterVector message; // set in fit

*/



class nloptr : public FittingObject {
    nlopt_opt opt;
    optim_model to_optimize;
    public:
    inline static int fcount = 0;
    inline static int gcount = 0;
    inline static int ccount = 0;
    //int n_params;
    //int lower_index; // For constrained optimization
    //int upper_index; // For constrained optimization

    nloptr(ModelOrderInformation * model_orders, Data * dataset, DynamicModelInformation * start_values, Family * fam, arma::mat init_link, Rcpp::List control) : FittingObject("nloptr", "SLSQP"), to_optimize(model_orders, dataset, start_values, fam, init_link)
    {
        Rcpp::LogicalVector constrained = control["constrained"]; // Default TRUE
        Rcpp::NumericVector constraint_tol = control["constraint_tol"]; // Default 1e-8
        Rcpp::NumericVector xtol = control["reltol"]; // Default sqrt(.Machine$double.eps)
        Rcpp::IntegerVector maxit = control["maxit"];


        opt = nlopt_create(NLOPT_LD_SLSQP, model_orders->n_param);
        if(fam->only_positive_parameters){
            double* lb = new double[model_orders->n_param];
            for(int i = 0; i < model_orders->n_param; i++){
                lb[i] = 0.0;
            }
            nlopt_set_lower_bounds(opt, lb);
        }

        nlopt_set_min_objective(opt, neg_log_likelihood, &to_optimize);

        arma::uvec * constrain_param = new arma::uvec(model_orders->n_param);
        (*constrain_param).subvec(model_orders->n_param_intercept, model_orders->n_param_intercept + model_orders->n_param_ar + model_orders->n_param_ma - 1).fill(1);
        if(constrained[0]){
            // indizes.upper_index = (model_orders->n_param - model_orders->n_param_cov);
            nlopt_add_inequality_constraint(opt, constraint, constrain_param, constraint_tol[0]);
        }
        // Set stopping criteria
        nlopt_set_xtol_rel(opt, xtol[0]);
        nlopt_set_maxeval(opt, maxit[0]);
    }

    arma::vec fit(arma::vec start_value){
        
        fcount = 0;
        gcount = 0;
        ccount = 0;
        double* start = new double[start_value.n_elem];
        for(unsigned int i = 0; i < start_value.n_elem; i++){
            start[i] = start_value(i);
        }
        double min_f = 0.0;

        start_vector = arma::vec(start_value);
        auto start_time = std::chrono::high_resolution_clock::now();

        nlopt_result res = nlopt_optimize(opt, start, &min_f);

        auto stop_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(stop_time - start_time);
        fitting_time = duration.count();

        fcounter = fcount;
        grcounter = gcount; 
        info_counter = ccount;
        bool converged = !(res == 6 || res < 0); // set in fit
        message = Rcpp::CharacterVector("No message available");
        Rcpp::LogicalVector convergence = {1};
        if(!converged){
            convergence[0] = FALSE;
        }

        arma::vec res_vec(start_value.n_elem);
        for(int i = 0; i < start_value.n_elem; i++)
        {
            res_vec(i) = start[i];
        }
        return res_vec;
    }

    // Ready:
    static double neg_log_likelihood(unsigned int n, const double *x, double *grad, void *func_data){
        fcount++;
        optim_model * model = (optim_model *) func_data;
        arma::vec param(x, n);
        double value;
        arma::vec score(n);
        if(grad)
        {
            gcount++;
            value = -Model::log_likelihood(param, score, model->information, model->link_values, model->design, model->design_covariates_internal, model->derivatives, *model->orders, model->data, model->family, model->link_init, true, false);
            for(unsigned int i = 0; i < n; i++){
                grad[i] = -score(i);
            }
        }
        else
        {
            value = -Model::log_likelihood(param, score, model->information, model->link_values, model->design, model->design_covariates_internal, model->derivatives, *model->orders, model->data, model->family, model->link_init, false, false);
        }
        return value;
    }

    static double constraint(unsigned int n, const double *x, double *grad, void *func_data){
        ccount++;
        arma::uvec* y = static_cast<arma::uvec*>(func_data);
        arma::uvec temp;
        if(y)
        {
            temp = *y;
        }
        if(grad){
            for(int i = 0; i < n; i++)
            {
                grad[i] = temp(i) > 0 ? x[i] / std::sqrt( x[i] * x[i] + 1e-5) : 0.0;
            }
        }
        double value = 0.0;
        for(int i = 0; i < n; i++)
        {
            value += temp(i) * std::sqrt( x[i] * x[i] + 1e-5);
        }
        return (value - 1.0);
    }
};


FittingObject * generate_fitting(ModelOrderInformation * model_orders, Data * dataset, DynamicModelInformation * start_values, Family * fam, arma::mat init_link, Rcpp::List control){
    Rcpp::CharacterVector method = control["method"];
    // if(method[0] == "fisher"){
    //     return new FisherScoring(model_and_data, control);
    // } else 
    if(method[0] == "fastglm") {
        if(model_orders->n_param_ma > 0){
            Rf_error("Error: Using fastglm is not possible if a feedback-term is included in the model");
        }
        return new fastglm(model_orders, dataset, start_values, fam, init_link, control);
    } else if(method[0] == "nloptr"){
        return new nloptr(model_orders, dataset, start_values, fam, init_link, control);
    } 
    else {
        return new optim(model_orders, dataset, start_values, fam, init_link, control);
    }
}




