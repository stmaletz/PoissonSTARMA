// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"
using namespace Rcpp;

/*
    Implementierungen fuer die Data-Hauptklasse
*/

Data::Data(arma::mat ts, const Rcpp::List &covariates, const Family * family, const int &burn_in) : n_obs(ts.n_cols), dim(ts.n_rows), n_covariates(covariates.size())
{
    this->ts = ts;
    this->transformed_obs = family->observation_trafo(ts);

    arma::vec temp(n_covariates); // For finding time-constant covariates
    for(unsigned int i = 0; i < n_covariates; i++){
        Rcpp::RObject cov_temp = covariates[i];
        if(cov_temp.hasAttribute("const")){
            Rcpp::CharacterVector attribute = cov_temp.attr("const");
            if(attribute[0] == "time"){
                Rcpp::NumericVector values = Rcpp::as<Rcpp::NumericVector>( cov_temp );
                arma::vec arma_vals = Rcpp::as<arma::vec>( values );
                list_of_covariates.push_back( new TimeConstantCovariate(arma_vals, burn_in) );
                temp(i) = 1;
            } else if(attribute[0] == "space"){
                Rcpp::NumericVector values = Rcpp::as<Rcpp::NumericVector>( cov_temp );
                arma::vec arma_vals = Rcpp::as<arma::vec>( values );
                list_of_covariates.push_back( new SpatialConstantCovariate(arma_vals, this->dim, burn_in) );
            } else {
                Rcpp::stop("Covariate not supported");
            }
        } else if(cov_temp.hasAttribute("intervention")) {
            Rcpp::List intervention_list = Rcpp::as<Rcpp::List>(cov_temp);
            Rcpp::IntegerVector time_points = intervention_list["time_points"];
            Rcpp::IntegerVector dimensions = intervention_list["dimensions"];
            Rcpp::NumericVector intensities = intervention_list["intensities"];
            list_of_covariates.push_back( new Intervention(Rcpp::as<arma::uvec>(time_points), Rcpp::as<arma::uvec>(dimensions), Rcpp::as<arma::vec>(intensities), this->dim, burn_in) );
        } else {
            Rcpp::NumericMatrix values = covariates[i];
            list_of_covariates.push_back( new DefaultCovariate(Rcpp::as<arma::mat>( values ), burn_in) );
        }
    }
    this->time_variant_covariates = arma::find(temp == 0);
}


Data::Data(Data* to_clone) : n_obs(to_clone->n_obs), dim(to_clone->dim), n_covariates(to_clone->n_covariates), time_variant_covariates(to_clone->time_variant_covariates)
{
    list_of_covariates = to_clone->list_of_covariates;
    ts = arma::mat(to_clone->dim, to_clone->n_obs); // Warum??
    transformed_obs = arma::mat(to_clone->dim, to_clone->n_obs); // Warum??
}


arma::vec Data::get_covariate_values(const int &k, const int &t) const 
{
        return (list_of_covariates.at(k))->get_values_at(t);
}

/*
static const bool Data::check_sparsity(const Rcpp::List &wlist, const double &sparsity_threshold, const int &dim)
{
    double non_zero = 0.;
    for(Rcpp::NumericMatrix W : wlist){
        non_zero += Rcpp::sum(W != 0);
    }
    return non_zero <= dim * dim * sparsity_threshold;
}
*/

/*
    Implementierungen fuer die DenseData-Klasse die mit dicht besetzten Nachbarschaftsmatrizen arbeitet
*/


// Konstruktoren:
DenseData::DenseData(arma::mat ts, const Rcpp::List &wlist, const Rcpp::List &covariates, const Family* family, const int &burn_in) : Data::Data(ts, covariates, family, burn_in)
{
    this->neighborhood_matrices = arma::cube(this->dim, this->dim, wlist.size());
    this->param_matrix = arma::mat(this->dim, this->dim);
    this->param_matrix_cov = arma::mat(this->dim, this->dim);
    Rcpp::NumericMatrix temp;
    for(int k = 0; k < wlist.size(); k++){
        temp = Rcpp::as<Rcpp::NumericMatrix>(wlist[k]);
        neighborhood_matrices.slice(k) = Rcpp::as<arma::mat>( temp );
    }
    this->neighborhood_matrices_covariates = neighborhood_matrices;
}

DenseData::DenseData(arma::mat ts, const Rcpp::List &wlist, const Rcpp::List &wlist_covariates, const Rcpp::List &covariates, const Family* family, const int burn_in) : Data::Data(ts, covariates, family, burn_in)
{
    this->neighborhood_matrices = arma::cube(this->dim, this->dim, wlist.size());
    this->neighborhood_matrices_covariates = arma::cube(this->dim, this->dim, wlist_covariates.size());
    this->param_matrix = arma::mat(this->dim, this->dim);
    this->param_matrix_cov = arma::mat(this->dim, this->dim);
    Rcpp::NumericMatrix temp;
    for(int k = 0; k < wlist.size(); k++){
        temp = Rcpp::as<Rcpp::NumericMatrix>(wlist[k]);
        this->neighborhood_matrices.slice(k) = Rcpp::as<arma::mat>( temp );
    }
    for(int k = 0; k < wlist_covariates.size(); k++){
        temp = Rcpp::as<Rcpp::NumericMatrix>(wlist_covariates[k]);
        this->neighborhood_matrices_covariates.slice(k) = Rcpp::as<arma::mat>( temp );
    }
}

DenseData::DenseData(DenseData * to_clone) : Data::Data(to_clone) 
{
    neighborhood_matrices = to_clone->neighborhood_matrices;
    neighborhood_matrices_covariates = to_clone->neighborhood_matrices_covariates;
    param_matrix = to_clone->param_matrix;
    param_matrix_cov = to_clone->param_matrix_cov;
    param_matrices = to_clone->param_matrices;
    param_matrices_cov = to_clone->param_matrices_cov;
}



// Sonstige Funktionen:
arma::mat DenseData::multiply_neigh_with_x(const int &order, const arma::mat &x) const 
{
    return this->neighborhood_matrices.slice(order) * x;
}

arma::mat DenseData::multiply_neigh_cov_with_x(const int &order, const arma::mat &x) const
{
    return this->neighborhood_matrices_covariates.slice(order) * x;
}

arma::mat DenseData::multiply_param_with_x(const arma::vec &param, const arma::mat &x) const
{
    arma::mat par_matrix(this->dim, this->dim);
    arma::uvec indices = arma::find(param != 0);
    for( arma::uword index : indices )
    {
        par_matrix += param(index) * this->neighborhood_matrices.slice(index);
    }
    return par_matrix * x;
}

arma::mat DenseData::multiply_param_cov_with_x(const arma::vec &param, const arma::mat &x) const
{
    arma::mat par_matrix(this->dim, this->dim);
    arma::uvec indices = arma::find(param != 0);
    for( arma::uword index : indices )
    {
        par_matrix += param(index) * this->neighborhood_matrices_covariates.slice(index);
    }
    return par_matrix * x;
}

void DenseData::update_param_matrix(const arma::vec &x)
{
    param_matrix.zeros();
    arma::uvec indices = arma::find(x != 0);
    for( arma::uword index : indices )
    {
        param_matrix += x(index) * this->neighborhood_matrices.slice(index);
    }
}

void DenseData::update_param_matrix_cov(const arma::vec &x)
{
    param_matrix_cov.zeros();
    arma::uvec indices = arma::find(x != 0);
    for( arma::uword index : indices )
    {
        param_matrix_cov += x(index) * this->neighborhood_matrices_covariates.slice(index);
    }
}



arma::mat DenseData::internal_multiply_param_with_x(const arma::vec &param, const arma::mat &x, const bool &update)
{
    if(update)
    {
        update_param_matrix(param);
    }
    return param_matrix * x;
}

arma::mat DenseData::internal_multiply_param_cov_with_x(const arma::vec &param, const arma::mat &x, const bool &update)
{
    if(update)
    {
        update_param_matrix_cov(param);
    }
    return param_matrix_cov * x;
}

void DenseData::set_parameter_matrices(const arma::mat &param)
{
    this->param_matrices = arma::cube(this->dim, this->dim, param.n_cols);
    for(unsigned int i = 0; i < param.n_cols; i++){
        arma::vec param_vec = param.col(i);
        update_param_matrix(param_vec);
        param_matrices.slice(i) = param_matrix;
    }
}

void DenseData::set_parameter_matrices_cov(const arma::mat &param)
{
    this->param_matrices_cov = arma::cube(this->dim, this->dim, param.n_cols);
    for(unsigned int i = 0; i < param.n_cols; i++){
        arma::vec param_vec = param.col(i);
        update_param_matrix_cov(param_vec);
        param_matrices_cov.slice(i) = param_matrix_cov;
    }
}

arma::vec DenseData::internal_multiply_param_with_x(const unsigned int &order, const arma::vec &x) const
{
    return param_matrices.slice(order) * x;
}

arma::vec DenseData::internal_multiply_param_cov_with_x(const unsigned int &order, const arma::vec &x) const
{
    return param_matrices_cov.slice(order) * x;
}

const bool DenseData::is_sparse() const
{
    return false;
}



/*
    Implementierungen fuer die SparseData-Klasse die mit sparsam besetzten Nachbarschaftsmatrizen arbeitet
*/

// Konstruktoren:
SparseData::SparseData(arma::mat ts, const Rcpp::List &wlist, const Rcpp::List &covariates, const Family* family, const int &burn_in) : Data::Data(ts, covariates, family, burn_in)
{
    this->neighborhood_matrices = arma::field<arma::sp_mat>(wlist.size());
    this->param_matrix = arma::sp_mat(this->dim, this->dim);
    this->param_matrix_cov = arma::sp_mat(this->dim, this->dim);
    Rcpp::NumericMatrix temp;
    for(int k = 0; k < wlist.size(); k++){
        temp = Rcpp::as<Rcpp::NumericMatrix>(wlist[k]);
        neighborhood_matrices(k) = arma::sp_mat(Rcpp::as<arma::mat>(temp));
    }
    this->neighborhood_matrices_covariates = neighborhood_matrices;
}

SparseData::SparseData(arma::mat ts, const Rcpp::List &wlist, const Rcpp::List &wlist_covariates, const Rcpp::List &covariates, const Family* family, const int burn_in) : Data::Data(ts, covariates, family, burn_in)
{
    this->neighborhood_matrices = arma::field<arma::sp_mat>(wlist.size());
    this->neighborhood_matrices_covariates = arma::field<arma::sp_mat>(wlist_covariates.size());
    this->param_matrix = arma::sp_mat(this->dim, this->dim);
    this->param_matrix_cov = arma::sp_mat(this->dim, this->dim);
    Rcpp::NumericMatrix temp;
    for(int k = 0; k < wlist.size(); k++){
        temp = Rcpp::as<Rcpp::NumericMatrix>(wlist[k]);
        this->neighborhood_matrices(k) = arma::sp_mat(Rcpp::as<arma::mat>(temp));
    }
    for(int k = 0; k < wlist_covariates.size(); k++){
        temp = Rcpp::as<Rcpp::NumericMatrix>(wlist_covariates[k]);
        this->neighborhood_matrices_covariates(k) = arma::sp_mat(Rcpp::as<arma::mat>(temp));
    }
}

SparseData::SparseData(SparseData * to_clone) : Data::Data(to_clone) 
{
    neighborhood_matrices = to_clone->neighborhood_matrices;
    neighborhood_matrices_covariates = to_clone->neighborhood_matrices_covariates;
    param_matrix = to_clone->param_matrix;
    param_matrix_cov = to_clone->param_matrix_cov;
    param_matrices = to_clone->param_matrices;
    param_matrices_cov = to_clone->param_matrices_cov;
}
 /*
SparseData::SparseData* clone() const override
{
    return new SparseData(*this);
}
*/


// Sonstige Funktionen:
arma::mat SparseData::multiply_neigh_with_x(const int &order, const arma::mat &x) const 
{
    return this->neighborhood_matrices(order) * x;
}

arma::mat SparseData::multiply_neigh_cov_with_x(const int &order, const arma::mat &x) const
{
    return this->neighborhood_matrices_covariates(order) * x;
}

arma::mat SparseData::multiply_param_with_x(const arma::vec &param, const arma::mat &x) const
{
    arma::sp_mat par_matrix(this->dim, this->dim);
    arma::uvec indices = arma::find(param != 0);
    for( arma::uword index : indices )
    {
        par_matrix += param(index) * this->neighborhood_matrices(index);
    }
    return par_matrix * x;
}

arma::mat SparseData::multiply_param_cov_with_x(const arma::vec &param, const arma::mat &x) const
{
    arma::sp_mat par_matrix(this->dim, this->dim);
    arma::uvec indices = arma::find(param != 0);
    for( arma::uword index : indices )
    {
        par_matrix += param(index) * this->neighborhood_matrices_covariates(index);
    }
    return par_matrix * x;
}

void SparseData::update_param_matrix(const arma::vec &x)
{
    param_matrix.zeros();
    arma::uvec indices = arma::find(x != 0);
    for( arma::uword index : indices )
    {
        param_matrix += x(index) * this->neighborhood_matrices(index);
    }
}

void SparseData::update_param_matrix_cov(const arma::vec &x)
{
    param_matrix_cov.zeros();
    arma::uvec indices = arma::find(x != 0);
    for( arma::uword index : indices )
    {
        param_matrix_cov += x(index) * this->neighborhood_matrices_covariates(index);
    }
}

arma::mat SparseData::internal_multiply_param_with_x(const arma::vec &param, const arma::mat &x, const bool &update)
{
    if(update)
    {
        update_param_matrix(param);
    }
    return param_matrix * x;
}

arma::mat SparseData::internal_multiply_param_cov_with_x(const arma::vec &param, const arma::mat &x, const bool &update)
{
    if(update)
    {
        update_param_matrix_cov(param);
    }
    return param_matrix_cov * x;
}

void SparseData::set_parameter_matrices(const arma::mat &param)
{
    this->param_matrices = arma::field<arma::sp_mat>(param.n_cols);
    for(unsigned int i = 0; i < param.n_cols; i++){
        arma::vec param_vec = param.col(i);
        update_param_matrix(param_vec);
        param_matrices(i) = param_matrix;
    }
}

void SparseData::set_parameter_matrices_cov(const arma::mat &param)
{
    this->param_matrices_cov = arma::field<arma::sp_mat>(param.n_cols);
    for(unsigned int i = 0; i < param.n_cols; i++){
        arma::vec param_vec = param.col(i);
        update_param_matrix_cov(param_vec);
        param_matrices_cov(i) = param_matrix_cov;
    }
}


arma::vec SparseData::internal_multiply_param_with_x(const unsigned int &order, const arma::vec &x) const
{
    return param_matrices(order) * x;
}

arma::vec SparseData::internal_multiply_param_cov_with_x(const unsigned int &order, const arma::vec &x) const
{
    return param_matrices_cov(order) * x;
}


const bool SparseData::is_sparse() const
{
    return true;
}



/*
    Funktion zur Generierung von Datenobjekten je nach Einstellung:

    TODO: Setze defaults in R auf:
    - save_space = FALSE // In R entfernen
    - use_sparsity = TRUE
    - sparsity_threshold = 2 / 3

*/

Data * generate_data_object(arma::mat ts, const Rcpp::List& wlist, const Rcpp::List& wlist_covariates, const Rcpp::List& covariates, const Family* family, const Rcpp::List& control, const int &burn_in){
    const int dim = ts.n_rows;
    const Rcpp::LogicalVector use_sparsity = control["use_sparsity"];
    const Rcpp::NumericVector sparsity_threshold = control["sparsity_threshold"];
    const bool is_sparse = Data::check_sparsity(wlist, sparsity_threshold[0], dim);
    bool is_sparse_covariates = true;
    if(wlist_covariates.size() > 0){
        is_sparse_covariates = Data::check_sparsity(wlist_covariates, sparsity_threshold[0], dim);
    }

    if(wlist_covariates.size() > 0){
        if( (use_sparsity[0] && is_sparse) && is_sparse_covariates ){
            return new SparseData(ts, wlist, wlist_covariates, covariates, family, burn_in);
        } else {
            return new DenseData(ts, wlist, wlist_covariates, covariates, family, burn_in);
        }
    } else {
        if( (use_sparsity[0] && is_sparse) && is_sparse_covariates ){
            return new SparseData(ts, wlist, covariates, family, burn_in);
        } else {
            return new DenseData(ts, wlist, covariates, family, burn_in);
        }
    }
}
