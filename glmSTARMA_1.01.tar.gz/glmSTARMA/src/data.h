#ifndef DATA_H
#define DATA_H

class Data {
    private:
    virtual void update_param_matrix(const arma::vec &x) = 0;
    virtual void update_param_matrix_cov(const arma::vec &x) = 0;
    public:
    // Saved objects:
    arma::mat ts;
    arma::mat transformed_obs;
    std::vector<Covariate*> list_of_covariates;

    // Additional information about data:
    const unsigned int n_obs;
    const unsigned int dim;
    const unsigned int n_covariates;
    arma::uvec time_variant_covariates; // Indices of time-constant covariates

    // Konstruktoren:
    Data(arma::mat ts, const Rcpp::List &covariates, const Family * family, const int &burn_in);
    Data(Data* to_clone);

    static const bool check_sparsity(const Rcpp::List &wlist, const double &sparsity_threshold, const int &dim)
    {
        double non_zero = 0.;
        for(Rcpp::NumericMatrix W : wlist)
        {
            non_zero += Rcpp::sum(W != 0);
        }
        return non_zero <= dim * dim * sparsity_threshold;
    };

    // Additional functions:
    virtual Data* clone() const = 0;
    arma::vec get_covariate_values(const int &k, const int &t) const;
    
    virtual arma::mat multiply_neigh_with_x(const int &order, const arma::mat &x) const = 0;
    virtual arma::mat multiply_neigh_cov_with_x(const int &order, const arma::mat &x) const = 0;

    virtual arma::mat multiply_param_with_x(const arma::vec &param, const arma::mat &x) const = 0;
    virtual arma::mat multiply_param_cov_with_x(const arma::vec &param, const arma::mat &x) const = 0;
    // Functions for the same as above, but with internally stored parameter matrices
    virtual arma::mat internal_multiply_param_with_x(const arma::vec &param, const arma::mat &x, const bool &update) = 0;
    virtual arma::mat internal_multiply_param_cov_with_x(const arma::vec &param, const arma::mat &x, const bool &update) = 0;
    virtual void set_parameter_matrices(const arma::mat &param) = 0;
    virtual void set_parameter_matrices_cov(const arma::mat &param) = 0;
    virtual arma::vec internal_multiply_param_with_x(const unsigned int &order, const arma::vec &x) const = 0;
    virtual arma::vec internal_multiply_param_cov_with_x(const unsigned int &order, const arma::vec &x) const = 0;

    virtual const bool is_sparse() const = 0;
};


class DenseData : public Data {
    public:
    arma::cube neighborhood_matrices;
    arma::cube neighborhood_matrices_covariates;

    arma::mat param_matrix;
    arma::mat param_matrix_cov;
    arma::cube param_matrices; // For storing multiple
    arma::cube param_matrices_cov; // For storing multiple

    virtual void update_param_matrix(const arma::vec &x) override;
    virtual void update_param_matrix_cov(const arma::vec &x) override;
    DenseData(arma::mat ts, const Rcpp::List &wlist, const Rcpp::List &covariates, const Family* family, const int &burn_in);
    DenseData(arma::mat ts, const Rcpp::List &wlist, const Rcpp::List &wlist_covariates, const Rcpp::List &covariates, const Family* family, const int burn_in);
    DenseData(DenseData * to_clone);

    Data* clone() const override
    {
        return new DenseData(*this);
    };

    
    virtual arma::mat multiply_neigh_with_x(const int &order, const arma::mat &x) const override;
    virtual arma::mat multiply_neigh_cov_with_x(const int &order, const arma::mat &x) const override;
    virtual arma::mat multiply_param_with_x(const arma::vec &param, const arma::mat &x) const override;
    virtual arma::mat multiply_param_cov_with_x(const arma::vec &param, const arma::mat &x) const override;
    virtual arma::mat internal_multiply_param_with_x(const arma::vec &param, const arma::mat &x, const bool &update) override;
    virtual arma::mat internal_multiply_param_cov_with_x(const arma::vec &param, const arma::mat &x, const bool &update) override;
    virtual void set_parameter_matrices(const arma::mat &param) override;
    virtual void set_parameter_matrices_cov(const arma::mat &param) override;
    virtual arma::vec internal_multiply_param_with_x(const unsigned int &order, const arma::vec &x) const override;
    virtual arma::vec internal_multiply_param_cov_with_x(const unsigned int &order, const arma::vec &x) const override;
    virtual const bool is_sparse() const override;
};

class SparseData : public Data {
    public:
    arma::field<arma::sp_mat> neighborhood_matrices;
    arma::field<arma::sp_mat> neighborhood_matrices_covariates;
    arma::sp_mat param_matrix;
    arma::sp_mat param_matrix_cov;
    arma::field<arma::sp_mat> param_matrices;
    arma::field<arma::sp_mat> param_matrices_cov;

    virtual void update_param_matrix(const arma::vec &x) override;
    virtual void update_param_matrix_cov(const arma::vec &x) override;

    
    SparseData(arma::mat ts, const Rcpp::List &wlist, const Rcpp::List &covariates, const Family* family, const int &burn_in);
    SparseData(arma::mat ts, const Rcpp::List &wlist, const Rcpp::List &wlist_covariates, const Rcpp::List &covariates, const Family* family, const int burn_in);
    SparseData(SparseData * to_clone);

    Data* clone() const override
    {
        return new SparseData(*this);
    };
    
    virtual arma::mat multiply_neigh_with_x(const int &order, const arma::mat &x) const override;
    virtual arma::mat multiply_neigh_cov_with_x(const int &order, const arma::mat &x) const override;
    virtual arma::mat multiply_param_with_x(const arma::vec &param, const arma::mat &x) const override;
    virtual arma::mat multiply_param_cov_with_x(const arma::vec &param, const arma::mat &x) const override;
    virtual arma::mat internal_multiply_param_with_x(const arma::vec &param, const arma::mat &x, const bool &update) override;
    virtual arma::mat internal_multiply_param_cov_with_x(const arma::vec &param, const arma::mat &x, const bool &update) override;
    virtual void set_parameter_matrices(const arma::mat &param) override;
    virtual void set_parameter_matrices_cov(const arma::mat &param) override;
    virtual arma::vec internal_multiply_param_with_x(const unsigned int &order, const arma::vec &x) const override;
    virtual arma::vec internal_multiply_param_cov_with_x(const unsigned int &order, const arma::vec &x) const override;
    virtual const bool is_sparse() const override;
};

Data * generate_data_object(arma::mat ts, const Rcpp::List &wlist, const Rcpp::List &wlist_covariates, const Rcpp::List &covariates, const Family* family, const Rcpp::List &control, const int &burn_in);

#endif
