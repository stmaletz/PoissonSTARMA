// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"

#include <chrono>
#include <thread>
using namespace std::this_thread;
using namespace std::chrono_literals;
using namespace Rcpp;



/*
  Definiere Negativ-Binomial-Verteilung:
*/

class NegativeBinomial : public Family 
{
  protected:
    const double dispersion;
    virtual const arma::vec random_observation_independent(const arma::vec &expectation) const;
    virtual const arma::vec random_observation(const arma::vec &expectation) const;
    virtual const double log_likelihood(const double &observation, const double &expectation) const;
  public:
    NegativeBinomial(const double &disp, const bool &only_positive, const Rcpp::Nullable<Rcpp::S4> &copula_obj, const char* link_name_r) : Family(only_positive, copula_obj, "negative_binomial", link_name_r), dispersion(disp){
      R_family = Rcpp::Environment("package:MASS")["negative.binomial"]; // Wozu??
    };
    NegativeBinomial(const double &disp, const bool &only_positive, const char* link_name_r) : Family(only_positive, "negative_binomial", link_name_r), dispersion(disp) {};
    virtual const bool valid_expectation(const arma::mat &x) const;
    virtual const arma::mat variance_fun(const arma::mat &link_values) const;
};

const arma::vec NegativeBinomial::random_observation_independent(const arma::vec &expectation) const
{
  arma::vec observations(expectation.n_elem, arma::fill::zeros);
  for(unsigned int i = 0; i < expectation.n_elem; i++)
  {
    observations(i) = Rcpp::as<double>(Rcpp::rnbinom_mu(1, dispersion,expectation(i)));
  }
  return observations;
}

const arma::vec NegativeBinomial::random_observation(const arma::vec &expectation) const
{
    arma::vec observations(expectation.n_elem, arma::fill::zeros);
    arma::vec copula_values(expectation.n_elem);
    copula_values = as<arma::vec>(this->copula_sample(1, this->copula_object));
    for(unsigned int i = 0; i < expectation.n_elem; i++)
    {
        observations(i) = R::qnbinom_mu( copula_values(i), dispersion, expectation(i), true, false );
    }
    return observations;
}

const double NegativeBinomial::log_likelihood(const double &observation, const double &expectation) const 
{
  return R::dnbinom_mu(observation, dispersion, expectation, true);
}

const bool NegativeBinomial::valid_expectation(const arma::mat &x) const 
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}

const arma::mat NegativeBinomial::variance_fun(const arma::mat &link_values) const
{
    arma::mat response = this->inverse_link(link_values);
    return response + (response % response) / dispersion;
}


/*
  Definiere lineares Modell, d.h. den 'identity'-Link der Negativ-Binomial-Verteilung
*/

class LinearNegativeBinomial : public NegativeBinomial {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LinearNegativeBinomial(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : NegativeBinomial(disp, true, copula_obj, "identity"){};
    LinearNegativeBinomial(const double &disp) : NegativeBinomial(disp, true, "identity"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LinearNegativeBinomial(this->dispersion, this->copula_object);
      } else {
        return new LinearNegativeBinomial(this->dispersion);
      }
    };
};

const double LinearNegativeBinomial::inverse_link(const double x) const
{
  return x;
}

const double LinearNegativeBinomial::derivative_inverse_link(const double x) const
{
  return 1.0;
}


const double LinearNegativeBinomial::observation_trafo(const double x) const
{
  return x;
}

const double LinearNegativeBinomial::link_trafo(const double x) const
{
  return x;
}

const double LinearNegativeBinomial::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LinearNegativeBinomial::valid_link(const arma::mat &x) const
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}


/*
  Definiere log-lineares Modell, d.h. den 'log'-Link der Negativ-Binomial-Verteilung
*/

class LogNegativeBinomial : public NegativeBinomial {
  protected:
    const double added_constant;
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LogNegativeBinomial(const double &disp, double constant, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : NegativeBinomial(disp, false, copula_obj, "log"), added_constant(constant){};
    LogNegativeBinomial(const double &disp, double constant) : NegativeBinomial(disp, false, "log"), added_constant(constant){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LogNegativeBinomial(this->dispersion, this->added_constant, this->copula_object);
      } else {
        return new LogNegativeBinomial(this->dispersion, this->added_constant);
      }
    };
};

const double LogNegativeBinomial::inverse_link(const double x) const
{
  return exp(x);
}


const double LogNegativeBinomial::derivative_inverse_link(const double x) const
{
  return exp(x);
}


const double LogNegativeBinomial::observation_trafo(const double x) const
{
  return log(x + added_constant);
}

const double LogNegativeBinomial::link_trafo(const double x) const
{
  return x;
}

const double LogNegativeBinomial::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LogNegativeBinomial::valid_link(const arma::mat &x) const
{
  return true;
}



/*
  Definiere Wurzel-Modell, d.h. den 'sqrt'-Link der Negativ-Binomial-Verteilung
*/

class SqrtNegativeBinomial : public NegativeBinomial {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    SqrtNegativeBinomial(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : NegativeBinomial(disp, true, copula_obj, "sqrt"){};
    SqrtNegativeBinomial(const double &disp) : NegativeBinomial(disp, true, "sqrt"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new SqrtNegativeBinomial(this->dispersion, this->copula_object);
      } else {
        return new SqrtNegativeBinomial(this->dispersion);
      }
    };
};

const double SqrtNegativeBinomial::inverse_link(const double x) const
{
  return pow(x, 2);
}

const double SqrtNegativeBinomial::derivative_inverse_link(const double x) const
{
  return 2 * x;
}

const double SqrtNegativeBinomial::observation_trafo(const double x) const
{
  return std::sqrt(x);
}

const double SqrtNegativeBinomial::link_trafo(const double x) const
{
  return x;
}

const double SqrtNegativeBinomial::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool SqrtNegativeBinomial::valid_link(const arma::mat &x) const
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}

/*
  Definiere approximativ lineares Modell, d.h. den 'softplus'-Link der Poisson-Verteilung aus der Arbeit von Jahn et al. (2023)
*/

class SoftPlusNegativeBinomial : public NegativeBinomial {
  protected:
    const double tuning_param;
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    SoftPlusNegativeBinomial(const double &disp, double constant, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : NegativeBinomial(disp, false, copula_obj, "softplus"), tuning_param(constant){};
    SoftPlusNegativeBinomial(const double &disp, double constant) : NegativeBinomial(disp, false, "softplus"), tuning_param(constant){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new SoftPlusNegativeBinomial(this->dispersion, this->tuning_param, this->copula_object);
      } else {
        return new SoftPlusNegativeBinomial(this->dispersion, this->tuning_param);
      }
    };
};


const double SoftPlusNegativeBinomial::inverse_link(const double x) const
{
  return tuning_param * std::log(1.0 + exp(x / tuning_param));
}

const double SoftPlusNegativeBinomial::derivative_inverse_link(const double x) const
{
  double val = exp(x / tuning_param);
  return val / (1.0 + val);
}


const double SoftPlusNegativeBinomial::observation_trafo(const double x) const
{
  return x;
}

const double SoftPlusNegativeBinomial::link_trafo(const double x) const
{
  return tuning_param * std::log(1.0 + exp(x / tuning_param));
}

const double SoftPlusNegativeBinomial::derivative_link_trafo(const double x) const
{
  double val = exp(x / tuning_param);
  return val / (1.0 + val);
}

const bool SoftPlusNegativeBinomial::valid_link(const arma::mat &x) const
{
  return true;
}



Family * generate_negative_binomial(const Rcpp::List &family)
{
  Rcpp::CharacterVector link = family["link"];
  Rcpp::NumericVector dispersion = family["dispersion"];
  double dispersion_param = dispersion[0];
  if(link[0] == "log")
  {
    double constant = 1.0;
    if(family.containsElementNamed("const"))
    {
      Rcpp::NumericVector temp_const = family["const"];
      constant = temp_const[0];
    }
    return new LogNegativeBinomial(dispersion_param, constant);
  } 
  else if(link[0] == "identity") 
  {
    return new LinearNegativeBinomial(dispersion_param);
  } 
  else if(link[0] == "sqrt") 
  {
    return new SqrtNegativeBinomial(dispersion_param);
  } 
  else if(link[0] == "softplus") 
  {
    double constant = 1.0;
    if(family.containsElementNamed("const"))
    {
      Rcpp::NumericVector temp_const = family["const"];
      constant = temp_const[0];
    }
    return new SoftPlusNegativeBinomial(dispersion_param, constant);
  } 
  else
  {
    throw std::invalid_argument("The desired link is currently not yet implemented.");
  }
}


Family * generate_negative_binomial(const Rcpp::List &family, Rcpp::S4& copula_obj)
{
    Rcpp::CharacterVector link = family["link"];
    Rcpp::NumericVector dispersion = family["dispersion"];
    double dispersion_param = dispersion[0];
    if(link[0] == "log")
    {
      double constant = 1.0;
      if(family.containsElementNamed("const"))
      {
        Rcpp::NumericVector temp_const = family["const"];
        constant = temp_const[0];
      }
      return new LogNegativeBinomial(dispersion_param, constant, copula_obj);
    } 
    else if(link[0] == "identity") 
    {
      return new LinearNegativeBinomial(dispersion_param, copula_obj);
    } 
    else if(link[0] == "sqrt")
    {
      return new SqrtNegativeBinomial(dispersion_param, copula_obj);
    }
    else if(link[0] == "softplus") 
    {
      double constant = 1.0;
      if(family.containsElementNamed("const"))
      {
        Rcpp::NumericVector temp_const = family["const"];
        constant = temp_const[0];
      }
      return new SoftPlusNegativeBinomial(dispersion_param, constant, copula_obj);
    } 
    else 
    {
      throw std::invalid_argument("The desired link is currently not yet implemented.");
    }
}
