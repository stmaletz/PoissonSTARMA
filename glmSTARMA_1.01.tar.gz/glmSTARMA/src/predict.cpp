// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"

/* Moegliche Predict Methoden:
    - Sample -> type c("sample", "response", "link")
    - one-step
    - mit und ohne kovariablen
    - fortlaufend mit neuen Beobachtungen

Argumente:
    - model -> gefittetes modell
    - type = c("sample", "response", "link") -> fuer Vorhersageart
    - newobs -> Wenn NULL, dann werden Vorhersagen als wahre Werte verwendet, fuer type = "sample" zufaellige Beobachtungen, ansonsten link-Werte
    - newxreg -> wenn NULL, dann letzter bekannter Wert
    - n.ahead -> ganze zahl
*/


// [[Rcpp::export]]
arma::mat glmstarma_predict(Rcpp::XPtr<glmstarma> object, Rcpp::CharacterVector pred_type, Rcpp::Nullable<Rcpp::NumericMatrix> newobs, Rcpp::Nullable<Rcpp::List> newxreg, int n_ahead, Rcpp::Nullable<Rcpp::S4> copula_obj){
    glmstarma * fitted_model = object.get();

    arma::mat obs_predict(fitted_model->data->dim, fitted_model->data->n_obs + n_ahead);
    arma::mat trans_obs_predict(fitted_model->data->dim, fitted_model->data->n_obs + n_ahead);
    arma::mat link_predict(fitted_model->data->dim, fitted_model->data->n_obs + n_ahead);
    int given_future_obs = 0;
    if(newobs.isNotNull()){
        Rcpp::NumericMatrix newobs_matrix(newobs);
        given_future_obs = newobs_matrix.cols();
        arma::mat newobs_arma = Rcpp::as<arma::mat>(newobs_matrix);

        if(given_future_obs > n_ahead){
            newobs_arma = newobs_arma.head_cols(n_ahead);
        } 
        obs_predict.cols(fitted_model->data->n_obs, fitted_model->data->n_obs + newobs_arma.n_cols - 1) = newobs_arma;
        trans_obs_predict = fitted_model->family->observation_trafo(obs_predict);
        // TODO: Fehler wenn pred_type = sample
    }

    obs_predict.head_cols(fitted_model->data->n_obs) = fitted_model->data->ts;
    trans_obs_predict.head_cols(fitted_model->data->n_obs) = fitted_model->data->transformed_obs;
    link_predict.head_cols(fitted_model->orders->max_time_lag) = fitted_model->estimation->link_init;
    link_predict.cols(fitted_model->orders->max_time_lag, fitted_model->data->n_obs - 1) = fitted_model->estimation->link_values;

    arma::vec added_values(fitted_model->data->n_covariates);
    /*
        - Zeitkonstant und Intervention -> keine Werte hinzugefuegt
        - Ansonsten hinzuguegen der Werte
    */
    if(newxreg.isNotNull() & (fitted_model->data->n_covariates > 0)){
        Rcpp::List newx(newxreg);
        for(int i = 0; i < newx.size(); i++){
            Rcpp::RObject cov_temp = newx[i];
            if(cov_temp.hasAttribute("const")){
                Rcpp::CharacterVector attribute = cov_temp.attr("const");
                if(attribute[0] == "time"){
                    added_values(i) = 0;
                } else if(attribute[0] == "space"){
                    Rcpp::NumericVector values = Rcpp::as<Rcpp::NumericVector>( cov_temp );
                    added_values(i) = values.length();
                    fitted_model->data->list_of_covariates.at(i)->append_values(Rcpp::as<arma::vec>( values ));
                } else {
                    Rcpp::stop("Covariate not supported");
                }
            } else if(cov_temp.hasAttribute("intervention")) {
                added_values(i) = 0;
            } else {
                Rcpp::NumericMatrix values = Rcpp::as<Rcpp::NumericMatrix>( cov_temp );
                added_values(i) = values.ncol();
                fitted_model->data->list_of_covariates.at(i)->append_values(Rcpp::as<arma::mat>( values ));
            }
        }
    }
    /*
    TODO: Ueberarbeiten.
    if(pred_type[0] == "sample"){
        if(copula_obj.isNotNull()){
            Rcpp::S4 copula_object(copula_obj);
            //Rcpp::List family_list = fitted_model->additional_results["family"];
            fitted_model->model->family = generate_family_from_list(family_list, copula_object);
        }
    }
    */


    arma::vec prediction;
    arma::vec pred_response;
    arma::vec sample;
    for(unsigned int t = fitted_model->data->n_obs; t < fitted_model->data->n_obs + n_ahead; t++){
        prediction = Model::calc_link_value_at(t, *(fitted_model->orders), fitted_model->estimation->parameter, link_predict, trans_obs_predict, fitted_model->data, false, fitted_model->family);
        link_predict.col(t) = prediction;
        if(pred_type[0] == "sample"){
            pred_response = fitted_model->family->inverse_link( prediction );
            sample = fitted_model->family->sample( pred_response );
            obs_predict.col(t) = sample;
            trans_obs_predict.col(t) = fitted_model->family->observation_trafo( sample );
        } else {
            if(t >= fitted_model->data->n_obs + given_future_obs){
                obs_predict.col(t) = fitted_model->family->inverse_link( prediction ); // Check, dass nicht leer
                pred_response = obs_predict.col(t);
                trans_obs_predict.col(t) = fitted_model->family->observation_trafo( pred_response );
            }
        }
    }
    // Hinzugefuegte Werte aus Kovariablen wieder loeschen
    if(arma::any(added_values)){
        for(unsigned int k = 0; k < fitted_model->data->n_covariates; k++){
            fitted_model->data->list_of_covariates.at(k)->delete_last_values(added_values(k));
        }
    }
    arma::mat result;
    if(pred_type[0] == "sample"){
        result = obs_predict.tail_cols(n_ahead);
    } else {
        result = link_predict.tail_cols(n_ahead);
        if(pred_type[0] == "response"){
            result = fitted_model->family->inverse_link(result);
        }
    } 
    return result;
}


