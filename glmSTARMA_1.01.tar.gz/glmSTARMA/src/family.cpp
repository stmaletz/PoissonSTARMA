// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"

#include <chrono>
#include <thread>
using namespace std::this_thread;
using namespace std::chrono_literals;
using namespace Rcpp;

/*
  Funktionen zur Generierung von Family-Objekten anhand des Inputs aus R
*/

Family * generate_family_from_list(const Rcpp::List &family)
{
  Rcpp::CharacterVector distribution = family["distribution"];
  if(distribution[0] == "poisson")
  {
    return generate_poisson(family);
  }
  else if(distribution[0] == "negative_binomial")
  {
    return generate_negative_binomial(family);
  }
  else if(distribution[0] == "binomial")
  {
    return generate_binomial(family);
  }
  else if(distribution[0] == "gamma")
  {
    return generate_gamma(family);
  }
  else if(distribution[0] == "inverse_gaussian")
  {
    return generate_inverse_gaussian(family);
  }
  else if(distribution[0] == "gaussian")
  {
    return generate_normal(family);
  }
  else if(distribution[0] == "garch")
  {
    return generate_garch(family);
  }
  else 
  {
    throw std::invalid_argument("The desired distribution is currently not yet implemented.");
  }
}


Family * generate_family_from_list(const Rcpp::List &family, Rcpp::S4& copula_obj)
{
  Rcpp::CharacterVector distribution = family["distribution"];
  if(distribution[0] == "poisson")
  {
    return generate_poisson(family, copula_obj);
  }
  else if(distribution[0] == "negative_binomial")
  {
    return generate_negative_binomial(family, copula_obj);
  }
  else if(distribution[0] == "binomial")
  {
    return generate_binomial(family, copula_obj);
  }
  else if(distribution[0] == "gamma")
  {
    return generate_gamma(family, copula_obj);
  }
  else if(distribution[0] == "inverse_gaussian")
  {
    return generate_inverse_gaussian(family, copula_obj);
  }
  else if(distribution[0] == "gaussian")
  {
    return generate_normal(family, copula_obj);
  }
  else if(distribution[0] == "garch")
  {
    return generate_garch(family, copula_obj);
  }
  else 
  {
    throw std::invalid_argument("The desired distribution is currently not yet implemented.");
  }
}
