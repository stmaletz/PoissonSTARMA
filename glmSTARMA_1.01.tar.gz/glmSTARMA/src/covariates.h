#ifndef COVARIATES_H
#define COVARIATES_H

class Covariate{
protected:
    int burn_in;
    arma::mat values;
public:
    Covariate() {};
    Covariate(int burn_in) {
        this->burn_in = burn_in;
    };
    Covariate(arma::mat covariate_values, int burn_in){
        if(covariate_values.is_rowvec()){
            values = covariate_values.t();
        } else {
            values = covariate_values;
        }
        this->burn_in = burn_in;
    };
    virtual arma::vec get_values_at(int t) = 0;
    virtual void append_values(arma::mat vals) = 0;
    virtual void delete_last_values(int to_delete) = 0;
};

class TimeConstantCovariate : public Covariate {
    public:
    TimeConstantCovariate(arma::mat covariate_values, int burn_in) : Covariate(covariate_values, burn_in) {};
    arma::vec get_values_at(int t){
        if(t >= burn_in){
            return values.col(0);
        } else {
            return arma::zeros(values.n_rows);
        }
        
    }
    void append_values(arma::mat vals){};
    void delete_last_values(int to_delete){};
};

class SpatialConstantCovariate : public Covariate {
    private:
    arma::vec returned_value;
    public:
    SpatialConstantCovariate(arma::mat covariate_values, int dim, int burn_in) : Covariate(covariate_values, burn_in) {
        returned_value = arma::vec(dim, arma::fill::zeros);
    }
    arma::vec get_values_at(int t){
        if(t >= burn_in){
            if(t - burn_in >= values.n_elem){
                returned_value.fill(values(values.n_elem - 1));
            } else {
                returned_value.fill(values(t - burn_in));
            }
        } else {
            returned_value.zeros();
        }
        return returned_value;
    }
    void append_values(arma::mat vals){
        values = arma::join_cols(values, vals);
    }
    void delete_last_values(int to_delete){
        values = values.head_rows(values.n_elem - to_delete);
    }
};

class DefaultCovariate : public Covariate {
    public:
    DefaultCovariate(arma::mat covariate_values, int burn_in) : Covariate(covariate_values, burn_in) {};
    arma::vec get_values_at(int t){
        if(t >= burn_in){
            if(t - burn_in >= values.n_cols){
                return values.col(values.n_cols);
            } else {
                return values.col(t - burn_in);
            }
        } else {
            return arma::zeros(values.n_rows);
        }
    }
    void append_values(arma::mat vals){
        values = arma::join_rows(values, vals);
    }
    void delete_last_values(int to_delete){
        values = values.head_cols(values.n_cols - to_delete);
    }
};

class Intervention : public Covariate {
    private:
    arma::uvec time_point; // Zeitpunkte der Intervention
    arma::uvec dimension; // Ort der Intervention
    arma::vec intensity; // Intensitaet der Intervention (Parameter eta)
    arma::vec returned_value;
    public:
    Intervention(arma::uvec time_points, arma::uvec dimensions, arma::vec intensities, int dim, int burn_in) : Covariate(burn_in) {
        if(time_points.n_elem == dimensions.n_elem) {
            dimension = dimensions;
            time_point = time_points;
        } else {
            dimension = dimensions;
            time_point = arma::uvec(dimensions.n_elem);
            time_point.fill(time_points(0));
        }

        if(intensities.n_elem == dimensions.n_elem) {
            intensity = intensities;
        } else {
            intensity = arma::zeros(dimensions.n_elem);
            intensity.fill(intensities(0));
        }
        returned_value = arma::zeros(dim);
    };
    arma::vec get_values_at(int t){
        returned_value.zeros();
        if(t >= burn_in){
            for(unsigned int i = 0; i < dimension.n_elem; i++){
                returned_value( dimension(i) - 1 ) = (t - burn_in < time_point(i)) ? 0.0 : std::pow(intensity(i), t - burn_in - time_point(i));
            }
        }
        return returned_value;
    };
    void append_values(arma::mat vals){};
    void delete_last_values(int to_delete){};
};




#endif
