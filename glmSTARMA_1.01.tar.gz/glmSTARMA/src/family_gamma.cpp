// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"

#include <chrono>
#include <thread>
using namespace std::this_thread;
using namespace std::chrono_literals;
using namespace Rcpp;

/*
    Definiere Gamma-Verteilung
*/

class Gamma : public Family 
{
  protected:
    const double dispersion;
    const double shape;
    virtual const arma::vec random_observation_independent(const arma::vec &expectation) const;
    virtual const arma::vec random_observation(const arma::vec &expectation) const;
    virtual const double log_likelihood(const double &observation, const double &expectation) const;
  public:
    Gamma(const double &disp, const bool &only_positive, const Rcpp::Nullable<Rcpp::S4> &copula_obj, const char* link_name_r) : Family(only_positive, copula_obj, "gamma", link_name_r), dispersion(disp), shape(1.0 / dispersion){
      R_family = Rcpp::Environment("package:stats")["Gamma"]; // Wozu??
    };
    Gamma(const double &disp, const bool &only_positive, const char* link_name_r) : Family(only_positive, "gamma", link_name_r), dispersion(disp), shape(1.0 / dispersion) {};
    virtual const bool valid_expectation(const arma::mat &x) const;
    virtual const arma::mat variance_fun(const arma::mat &link_values) const;
};


const arma::vec Gamma::random_observation_independent(const arma::vec &expectation) const
{
  arma::vec observations(expectation.n_elem, arma::fill::zeros);
  for(unsigned int i = 0; i < expectation.n_elem; i++)
  {
    observations(i) = Rcpp::as<double>(Rcpp::rgamma(1, shape, expectation(i)));
  }
  return observations;
}

const arma::vec Gamma::random_observation(const arma::vec &expectation) const
{
    arma::vec observations(expectation.n_elem, arma::fill::zeros);
    arma::vec copula_values(expectation.n_elem);
    copula_values = as<arma::vec>(this->copula_sample(1, this->copula_object));
    for(unsigned int i = 0; i < expectation.n_elem; i++)
    {
        observations(i) = R::qgamma( copula_values(i), shape, expectation(i), true, false );
    }
    return observations;
}

const double Gamma::log_likelihood(const double &observation, const double &expectation) const 
{
  return R::dgamma(observation, shape, expectation, true);
}

const bool Gamma::valid_expectation(const arma::mat &x) const 
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}

const arma::mat Gamma::variance_fun(const arma::mat &link_values) const
{
    arma::mat response = this->inverse_link(link_values);
    return (response % response) * dispersion;
}


/*
    Definiere log-Modell
*/

class LogGamma : public Gamma {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LogGamma(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Gamma(disp, false, copula_obj, "log"){};
    LogGamma(const double &disp) : Gamma(disp, false, "log"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LogGamma(this->dispersion, this->copula_object);
      } else {
        return new LogGamma(this->dispersion);
      }
    };
};


const double LogGamma::inverse_link(const double x) const
{
  return exp(x);
}

const double LogGamma::derivative_inverse_link(const double x) const
{
  return exp(x);
}


const double LogGamma::observation_trafo(const double x) const
{
  return log(x);
}

const double LogGamma::link_trafo(const double x) const
{
  return x;
}

const double LogGamma::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LogGamma::valid_link(const arma::mat &x) const
{
  return true;
}

/*
    Definiere Lineares, d.h. identity-Modell
*/

class LinearGamma : public Gamma {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LinearGamma(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Gamma(disp, true, copula_obj, "identity"){};
    LinearGamma(const double &disp) : Gamma(disp, true, "identity"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LinearGamma(this->dispersion, this->copula_object);
      } else {
        return new LinearGamma(this->dispersion);
      }
    };
};


const double LinearGamma::inverse_link(const double x) const
{
  return x;
}

const double LinearGamma::derivative_inverse_link(const double x) const
{
  return 1.0;
}


const double LinearGamma::observation_trafo(const double x) const
{
  return x;
}

const double LinearGamma::link_trafo(const double x) const
{
  return x;
}

const double LinearGamma::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LinearGamma::valid_link(const arma::mat &x) const
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}


/*
    Definiere Invers-Modell
*/

class InverseGamma : public Gamma {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    InverseGamma(const double &disp, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Gamma(disp, true, copula_obj, "inverse"){};
    InverseGamma(const double &disp) : Gamma(disp, true, "inverse"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new InverseGamma(this->dispersion, this->copula_object);
      } else {
        return new InverseGamma(this->dispersion);
      }
    };
};


const double InverseGamma::inverse_link(const double x) const
{
  return 1.0 / x;
}

const double InverseGamma::derivative_inverse_link(const double x) const
{
  return -1.0 / (x * x);
}


const double InverseGamma::observation_trafo(const double x) const
{
  return 1.0 / x;
}

const double InverseGamma::link_trafo(const double x) const
{
  return x;
}

const double InverseGamma::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool InverseGamma::valid_link(const arma::mat &x) const
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}



Family * generate_gamma(const Rcpp::List &family)
{
  Rcpp::CharacterVector link = family["link"];
  Rcpp::NumericVector dispersion = family["shape"];
  double dispersion_param = 1.0 / dispersion[0];
  if(link[0] == "log")
  {
    return new LogGamma(dispersion_param);
  } 
  else if(link[0] == "identity") 
  {
    return new LinearGamma(dispersion_param);
  } 
  else if(link[0] == "inverse") 
  {
    return new InverseGamma(dispersion_param);
  } 
  else
  {
    throw std::invalid_argument("The desired link is currently not yet implemented.");
  }
}


Family * generate_gamma(const Rcpp::List &family, Rcpp::S4& copula_obj)
{
  Rcpp::CharacterVector link = family["link"];
  Rcpp::NumericVector dispersion = family["shape"];
  double dispersion_param = 1.0 / dispersion[0];
  if(link[0] == "log")
  {
    return new LogGamma(dispersion_param, copula_obj);
  } 
  else if(link[0] == "identity") 
  {
    return new LinearGamma(dispersion_param, copula_obj);
  } 
  else if(link[0] == "inverse") 
  {
    return new InverseGamma(dispersion_param, copula_obj);
  } 
  else
  {
    throw std::invalid_argument("The desired link is currently not yet implemented.");
  }
}






