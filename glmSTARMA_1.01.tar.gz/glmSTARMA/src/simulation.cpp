// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"
#include <chrono>
#include <thread>
using namespace std::chrono_literals;


// Burnin unbedingt bei data einbeziehen

arma::mat glmstarma_sim_internal(const arma::vec &param, const ModelOrderInformation &orders, arma::mat &link_values, const Data * data, const Family * family, const int &burn_in, const int &dim, const arma::mat &initals, const bool &use_init)
{

    // Waehle erste Link-Werte
    double unconditional_mean = arma::mean(param.head(orders.n_param_intercept)) / (1.0 - arma::sum(param.subvec(orders.n_param_intercept, orders.n_param_intercept + orders.n_param_ar + orders.n_param_ma - 1)));
    arma::vec init_link(dim, arma::fill::value( unconditional_mean ));
    arma::vec init_mean = family->inverse_link( init_link );
    arma::vec sample(dim);
    arma::vec expectation(dim);

    arma::mat link_vals(dim, data->n_obs);
    arma::mat observations(dim, data->n_obs);
    arma::mat transformed_observations(dim, data->n_obs);
    if(use_init)
    {
        link_vals.head_cols(orders.max_time_lag) = initals;
        for(unsigned int t = 0; t < orders.max_time_lag; t++)
        {
            sample = family->sample(link_vals.col(t));
            observations.col(t) = sample;
            transformed_observations.col(t) = family->observation_trafo( sample );
        }
    }
    else
    {
        // Erste Beobachtungen unabhaengig samplen:
        for(unsigned int t = 0; t < orders.max_time_lag; t++)
        {
            link_vals.col(t) = init_link;
            sample = family->sample(init_mean);
            observations.col(t) = sample;
            transformed_observations.col(t) = family->observation_trafo( sample );
        }
    }
    // Rest des burn-in ohne Kovariablen samplen:
    for(unsigned int t = orders.max_time_lag; t < burn_in; t++)
    {
        init_link = Model::calc_link_value_at(t, orders, param, link_vals, transformed_observations, data, true, family);
        link_vals.col(t) = init_link;
        init_mean = family->inverse_link( init_link );
        sample = family->sample(init_mean);
        observations.col(t) = sample;
        transformed_observations.col(t) = family->observation_trafo( sample );
    }
    // Den Rest dann mit Kovariablen samplen
    for(unsigned int t = burn_in; t < data->n_obs; t++)
    {
        init_link = Model::calc_link_value_at(t, orders, param, link_vals, transformed_observations, data, false, family);
        link_vals.col(t) = init_link;
        init_mean = family->inverse_link( init_link );
        sample = family->sample(init_mean);
        observations.col(t) = sample;
        transformed_observations.col(t) = family->observation_trafo( sample );
    }
    link_values = link_vals.tail_cols(data->n_obs - burn_in);
    return observations.tail_cols(data->n_obs - burn_in);
}




// [[Rcpp::export]]
Rcpp::List glmstarma_sim_cpp(const Rcpp::IntegerVector& n_obs_in_time, const Rcpp::List& parameters, const Rcpp::List& model, const Rcpp::List& wlist,
                                const Rcpp::List& family, const Rcpp::List& covariates, const Rcpp::List& wlist_covariates,
                                const Rcpp::Nullable<Rcpp::S4> copula_obj, const Rcpp::IntegerVector& n_start, const Rcpp::List &control)
{
    // Transform input:
    const int number_of_observations_in_time = n_obs_in_time[0];
    const int burn_in = n_start[0];
    Rcpp::NumericMatrix tempW = wlist[0];
    const int dim = tempW.nrow();
    // Modell-, Parameter- & Datenobjekte erstellen etc.
    Family * fam;
    if(copula_obj.isNotNull())
    {
        Rcpp::S4 copula_object(copula_obj);
        fam = generate_family_from_list(family, copula_object);
    } 
    else 
    {
        fam = generate_family_from_list(family);
    }
    arma::mat ts(dim, number_of_observations_in_time + burn_in);
    arma::mat link_values(dim, number_of_observations_in_time + burn_in);
    Data * data = generate_data_object(ts, wlist, wlist_covariates, covariates, fam, control, burn_in);
    ModelOrderInformation orders(model, dim, number_of_observations_in_time + burn_in);
    arma::vec params = Init::init_param(parameters, orders, data, fam);
    if(orders.max_time_lag >= burn_in){
        throw std::invalid_argument("n_start must be greater than the largest time lag in the model.");
    }

    // Ueberpruefung, dass Parameterwerte mit dem zu simulierenden Modell uebereinstimmen:
    /*
    if(!check_subset(model_to_simulate.autoregressive_orders, model_to_simulate.autoregressive)){
       Rcpp::warning("There are non-zero autoregressive parameters, which are not used in the model. These will be ignored.");
       model_to_simulate.autoregressive(arma::find(model_to_simulate.autoregressive_orders == 0)).zeros();
    }
    if(!check_subset(model_to_simulate.moving_average_orders, model_to_simulate.moving_average)){
        Rcpp::warning("There are non-zero moving average parameters, which are not used in the model. These will be ignored.");
        model_to_simulate.moving_average(arma::find(model_to_simulate.moving_average_orders == 0)).zeros();
    }
    if(!check_subset(model_to_simulate.covariate_orders, model_to_simulate.covariate)){
        Rcpp::warning("There are non-zero covariate parameters, which are not used in the model. These will be ignored.");
        model_to_simulate.covariate(arma::find(model_to_simulate.covariate == 0)).zeros();
    }
    */
    arma::mat init(1, 1);
    arma::mat sim_obs = glmstarma_sim_internal(params, orders, link_values, data, fam, burn_in, dim, init, false);
    // Beobachtungen zurueckgeben:
    Rcpp::List result = Rcpp::List::create(Rcpp::Named("observations") = sim_obs, Rcpp::Named("link_values") = link_values, Rcpp::Named("model") = model, Rcpp::Named("parameters") = parameters);
    return result;
}


