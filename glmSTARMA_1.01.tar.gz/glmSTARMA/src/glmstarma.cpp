// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"

#include <chrono>
#include <thread>
using namespace std::this_thread;
using namespace std::chrono_literals;

/*
    Funktion die in R zum Fitten des Modells aufgerufen wird.
    Eingabe sind saemtliche Daten die benoetigt werden.
    Rueckgabe ist ein Pointer der auf ein glmstarma-Objekt zeigt.
    Die Rueckgabe muss in R noch weiter verarbeitet werden
*/


// [[Rcpp::export]]
Rcpp::XPtr<glmstarma> glmstarma_cpp(const Rcpp::NumericMatrix &ts, const Rcpp::List &model, const Rcpp::List &wlist, const Rcpp::List &covariates, const Rcpp::List &wlist_covariates, const Rcpp::List &family, const Rcpp::List &control){
    
    arma::mat time_series = Rcpp::as<arma::mat>(ts);

    // Generate internal objects for fitting:
    //Rcpp::Rcout << "Fitting - 1\n";
    Family * fam = generate_family_from_list(family);
    //Rcpp::Rcout << "Fitting - 2\n";
    Data * data = generate_data_object(time_series, wlist, wlist_covariates, covariates, fam, control, 0);
    //Rcpp::Rcout << "Fitting - 3\n";
    ModelOrderInformation * model_orders =  new ModelOrderInformation(model, data->dim, data->n_obs);
    //Rcpp::Rcout << "Fitting - 4\n";

    // Initialize parameter_est:
    Rcpp::RObject init_method_param = control["parameter_init"];
    Rcpp::RObject init_method_link = control["init_link"];

    arma::vec start = Init::init_param(init_method_param, *model_orders, data, fam);
    //Rcpp::Rcout << "Fitting - 5\n";
    arma::mat link_init = Init::init_link(init_method_link, *model_orders, data, fam);
    //Rcpp::Rcout << "Fitting - 6\n";

    DynamicModelInformation * start_values = new DynamicModelInformation(start, *model_orders, data, fam, link_init);
    //Rcpp::Rcout << "Fitting - 7\n";
    FittingObject * fitting = generate_fitting(model_orders, data, start_values, fam, link_init, control);
    //Rcpp::Rcout << "Fitting - 8\n";
    arma::vec estimation = fitting->fit(start);
    //Rcpp::Rcout << "Fitting - 9\n";
    DynamicModelInformation * result = new DynamicModelInformation(estimation, *model_orders, data, fam, link_init);
    //Rcpp::Rcout << "Fitting - 10\n";
    glmstarma* res = new glmstarma(model_orders, data, result, fam, fitting);
    // Rcpp::Rcout << "Fitting - 11\n";
    Rcpp::XPtr<glmstarma> result_ptr(res);

    return result_ptr;
}


/*
    Funktion um relevante Informationen des Modells an R zurueckzugeben.
*/

// [[Rcpp::export]]
Rcpp::List get_results(Rcpp::XPtr<glmstarma> result_ptr){
    glmstarma * ptr = result_ptr.get();
    Rcpp::List param_est = ptr->estimation->get_parameter_list(*(ptr->orders));
    arma::vec coefficients  = ptr->estimation->parameter;
    arma::vec start = ptr->fitting_info->get_start();
    unsigned int target_dim = ptr->data->dim;
    unsigned int n_obs_effective = ptr->orders->n_obs_effective;
    unsigned int max_time_lag = ptr->orders->max_time_lag;
    double log_likelihood = ptr->estimation->log_likelihood;
    arma::vec score = ptr->estimation->score;
    arma::mat information = ptr->estimation->information;
    arma::mat var_temp = ptr->estimation->variance_estimation(*ptr->orders, ptr->data, ptr->family, ptr->estimation->link_init);
    var_temp = information * var_temp / n_obs_effective;

    double aic = -2.0 * log_likelihood + 2.0 * ptr->orders->n_param;
    double bic = -2.0 * log_likelihood + std::log( static_cast<double>(ptr->orders->n_obs_effective * target_dim) ) * ptr->orders->n_param;
    double qic = -2.0 * log_likelihood + 2.0 * arma::trace(var_temp);
    arma::mat fitted_values(ptr->data->dim, ptr->data->n_obs);
    fitted_values.head_cols(ptr->orders->max_time_lag) = ptr->family->inverse_link( ptr->estimation->link_init );
    fitted_values.tail_cols(ptr->orders->n_obs_effective) = ptr->family->inverse_link( ptr->estimation->link_values );
    Rcpp::List algo_info = ptr->fitting_info->get_algorithm_info();
    Rcpp::List convergence = ptr->fitting_info->get_fitting_info();


    Rcpp::List results = Rcpp::List::create(Rcpp::Named("coefficients_list") = param_est, 
                                            Rcpp::Named("coefficients") = coefficients,
                                            Rcpp::Named("target_dim") = target_dim,
                                            Rcpp::Named("n_obs_effective") = n_obs_effective,
                                            Rcpp::Named("max_time_lag") = max_time_lag,
                                            Rcpp::Named("log_likelihood") = log_likelihood,
                                            Rcpp::Named("score") = score,
                                            Rcpp::Named("information") = information,
                                            Rcpp::Named("aic") = aic,
                                            Rcpp::Named("bic") = bic,
                                            Rcpp::Named("qic") = qic,
                                            Rcpp::Named("fitted.values") = fitted_values,
                                            Rcpp::Named("start") = start,
                                            Rcpp::Named("algorithm") = algo_info,
                                            Rcpp::Named("convergence") = convergence);
    return results;
}


// [[Rcpp::export]]
arma::mat variance_estimation(Rcpp::XPtr<glmstarma> result_ptr){
    glmstarma * ptr = result_ptr.get();
    return ptr->estimation->variance_estimation(*ptr->orders, ptr->data, ptr->family, ptr->estimation->link_init);
}



