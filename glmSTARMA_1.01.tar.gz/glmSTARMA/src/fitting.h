#ifndef FITTING_H
#define FITTING_H

class FittingObject{
    protected:
    const Rcpp::CharacterVector method; // Set in Constructor
    const Rcpp::CharacterVector algorithm; // Set in Konstruktor
    unsigned int fcounter; // set in fit
    unsigned int grcounter; // set in fit
    unsigned int info_counter; // set in fit
    long long int fitting_time; // set in fit
    arma::vec start_vector; // set in fit
    bool converged; // set in fit
    Rcpp::CharacterVector message; // set in fit
    public:
    FittingObject(const char* methode, const char* alg) : method(methode), algorithm(alg) 
    {
        fcounter = 0;
        grcounter = 0;
        info_counter = 0;
    };
    virtual arma::vec fit(arma::vec start_value) = 0;
    Rcpp::List get_algorithm_info() const 
    {
        return Rcpp::List::create(Rcpp::Named("method") = method, Rcpp::Named("algorithm") = algorithm);
    };
    Rcpp::List get_fitting_info() const
    {
        return Rcpp::List::create(Rcpp::Named("fncount") = fcounter, Rcpp::Named("grcount") = grcounter,
        Rcpp::Named("hecount") = info_counter, Rcpp::Named("fitting_time") = fitting_time,
        Rcpp::Named("convergence") = Rcpp::LogicalVector(converged), Rcpp::Named("message") = message);
    };
    const arma::vec get_start() const 
    {
        return start_vector;
    }
};

FittingObject * generate_fitting(ModelOrderInformation * model_orders, Data * dataset, DynamicModelInformation * start_values, Family * fam, arma::mat init_link, Rcpp::List control);

#endif
