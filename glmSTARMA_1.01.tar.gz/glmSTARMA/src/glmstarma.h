// family.h
#ifndef GLMSTARMA_H
#define GLMSTARMA_H

#include <cmath>
#include <iostream>
#include <iterator>
#include <list>

#include <RcppArmadillo.h>
#include <roptim.h>
// [[Rcpp::depends(roptim)]]
using namespace roptim;

class Family;
class Covariate;
class Model;
class Data;


#include "family.h"
#include "covariates.h"
#include "data.h"
#include "model.h"
#include "fitting.h"

class glmstarma
{
  public:
  ModelOrderInformation * orders;
  Data * data;
  DynamicModelInformation * estimation;
  Family * family;
  FittingObject * fitting_info;
  glmstarma(ModelOrderInformation * model_to_save, Data * data_to_save, DynamicModelInformation * estimation_to_save, Family * family_to_save, FittingObject * fitting_information_to_save)
  {
    orders = model_to_save;
    data = data_to_save;
    estimation = estimation_to_save;
    family = family_to_save;
    fitting_info = fitting_information_to_save;
  }
};

arma::mat glmstarma_sim_internal(const arma::vec &param, const ModelOrderInformation &orders, arma::mat &link_values, const Data * data, const Family * family, const int &burn_in, const int &dim, const arma::mat &initals, const bool &use_init);

#endif


/*

class glmstarma : public Functor {
    public:
    Model * model;
    Data * data;
    Rcpp::List additional_results;
    glmstarma(Model * model_to_save, Data * data_to_save){
      model = model_to_save;
      data = data_to_save;
    }
    void set_results(Rcpp::List parameter_est, arma::vec start, double aic, double bic, Rcpp::List model_list, Rcpp::List family, Rcpp::List convergence, long long int duration){
      additional_results = Rcpp::List::create(Rcpp::Named("coefficients_list") = parameter_est, 
                                           Rcpp::Named("coefficients") = model->pars_as_vec(),
                                           Rcpp::Named("start") = start,
                                           Rcpp::Named("target_dim") = data->dim,
                                           Rcpp::Named("n_obs_effective") = model->n_obs_effective,
                                           Rcpp::Named("max_time_lag") = model->max_time_lag,
                                           Rcpp::Named("log_likelihood") = model->log_likelihood,
                                           Rcpp::Named("score") = model->score,
                                           Rcpp::Named("information") = model->information,
                                           Rcpp::Named("aic") = aic,
                                           Rcpp::Named("bic") = bic,
                                           Rcpp::Named("model") = model_list,
                                           Rcpp::Named("family") = family,
                                           Rcpp::Named("fitted.values") = model->response,
                                           Rcpp::Named("fitting_time") = duration,
                                           Rcpp::Named("convergence") = convergence);
    }
    double operator()(const arma::vec &x) override {
      if(!arma::all(model->parameter_vector == x)){
        arma::vec temp = x;
        model->update_model_for_log(temp, data);
      }
      return -model->log_likelihood;
    }
    void Gradient(const arma::vec &x, arma::vec &gr) override {
      arma::vec temp = x;
      model->update_model(temp, data);
      gr = -model->score;
    }
    void Hessian(const arma::vec &x, arma::mat &he) override {
      if(!arma::all(model->parameter_vector == x)){
        arma::vec temp = x;
        model->update_model(temp, data);
      }
      he = -model->information;
    }
};

*/
