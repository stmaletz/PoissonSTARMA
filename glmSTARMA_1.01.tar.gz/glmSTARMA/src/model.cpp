// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"
#include <chrono>
#include <thread>
using namespace std::this_thread;
using namespace std::chrono_literals;
using namespace Rcpp;


/*
    Hilfsfunktionen fuer Konstruktion der Modellobjekte:
*/


bool ModelOrderInformation::get_intercept_information(const Rcpp::List& model_definition) const 
{
        Rcpp::CharacterVector intercept_definition = model_definition["intercept"];
        return (intercept_definition[0] == "homogeneous");
}

arma::umat ModelOrderInformation::get_model_order(const Rcpp::List& model_definition, const char* variable) const
{
    arma::umat result;
    if(model_definition.containsElementNamed(variable)){
        Rcpp::IntegerMatrix orders = model_definition[variable];
        result = Rcpp::as<arma::umat>( orders );
    } 
    return result;
}

arma::uvec ModelOrderInformation::get_time_lags(const Rcpp::List& model_definition, const char* variable) const
{
    arma::uvec result;
    if(model_definition.containsElementNamed(variable)){
        Rcpp::IntegerVector lags = model_definition[variable];
        result = Rcpp::as<arma::uvec>( lags );
    }
    return result;
}

unsigned int ModelOrderInformation::calc_max_time_lag() const
{
    unsigned int max_ar_lag = ar_time_lags.n_elem > 0 ? ar_time_lags.max() : 0;
    unsigned int max_ma_lag = ma_time_lags.n_elem > 0 ? ma_time_lags.max() : 0;
    return max_ma_lag > max_ar_lag ? max_ma_lag : max_ar_lag;
}





/*
    Funktion zur Initialisierung der Link-Werte:
*/

arma::mat Init::init_link(const Rcpp::RObject &method, const ModelOrderInformation &orders, const Data* data, const Family* family)
{
    arma::mat linkvals(data->dim, orders.max_time_lag);
    if(orders.n_param_ma > 0){
        if(Rf_isMatrix(method)){
            Rcpp::NumericMatrix init_values = Rcpp::as<Rcpp::NumericMatrix>( method );
            return Rcpp::as<arma::mat>( init_values );
        }

        Rcpp::CharacterVector init_method = Rcpp::as<Rcpp::CharacterVector>( method );
        if(init_method[0] == "first_obs"){
            for(unsigned int i = 0; i < orders.max_time_lag; i++){
                linkvals.col(i) = data->transformed_obs.col(i);
            }
        } else if(init_method[0] == "mean"){
            arma::vec row_mean = arma::mean(data->transformed_obs, 1);
            for(unsigned int i = 0; i < orders.max_time_lag; i++){
                linkvals.col(i) = row_mean;
            }
        } else if(init_method[0] == "transformed_mean"){
            arma::vec row_mean = family->observation_trafo(arma::mean(data->ts, 1));
            for(unsigned int i = 0; i < orders.max_time_lag; i++){
                linkvals.col(i) = row_mean;
            }
        }
    }
    return linkvals;
}





/*
    Funktion zur Initialisierung/Generierung einer Designmatrix.
    Input:
    - orders
    - data
    - linkvals: Initial link-Values
*/

arma::mat Init::initialize_design(const ModelOrderInformation &orders, const Data* data, const arma::mat &linkvals)
{
    arma::mat design(data->dim * orders.n_obs_effective, orders.n_param);
    
    // Design for intercept:
    if(orders.intercepts_equal){
        design.col(0) = arma::ones<arma::vec>(design.n_rows);
    } else {
        arma::mat identity = arma::eye(data->dim, data->dim);
        for(int i = 0; i < orders.n_obs_effective; i++){
            design.submat(i * data->dim, 0, (i + 1) * data->dim - 1, data->dim - 1) = identity;
        }
    }
    unsigned int col_index = orders.n_param_intercept; // Index for running throw the columns

    // Design for Link-Values
    // Set to zero. Is updated if needed in calculate_link_values
    if(orders.n_param_ma > 0){
        col_index += orders.n_param_ma;
    }
    // Rcpp::Rcout << "Init - 1\n";
    // Design for observations:
    if(orders.n_param_ar > 0){
        arma::mat temp_obs;
        for(unsigned int i = 0; i < orders.autoregressive_orders.n_cols; i++){
            temp_obs = data->transformed_obs.cols(orders.max_time_lag - orders.ar_time_lags(i), orders.max_time_lag - orders.ar_time_lags(i) + orders.n_obs_effective - 1);
            arma::uvec orders_lag = arma::find( orders.autoregressive_orders.col(i) );
            for(unsigned int o : orders_lag){
                design.col(col_index) = arma::vectorise( data->multiply_neigh_with_x(o, temp_obs) );
                col_index++;
            }
        }
    }

    // Rcpp::Rcout << "Init - 2\n";
    // Design for covariates:
    if(orders.n_param_cov > 0){
        for(unsigned int k = 0; k < orders.covariate_orders.n_cols; k++){
            arma::uvec orders_lag = arma::find( orders.covariate_orders.col(k) );
            for(unsigned int o : orders_lag){
                for(unsigned int t = orders.max_time_lag; t < data->n_obs; t++){
                    design.submat((t - orders.max_time_lag) * data->dim, col_index, (t - orders.max_time_lag + 1) * data->dim - 1, col_index) = data->multiply_neigh_cov_with_x(o, data->get_covariate_values(k, t));
                }
                col_index++;
            }
        }
    }

    return design;
}



/*
    Funktion zur Initialisierung der Parameter des Modells
*/

arma::vec Init::init_param(const Rcpp::RObject &method, const ModelOrderInformation &orders, const Data* data, const Family* family)
{
    arma::vec intercept;
    arma::mat autoregressive_params;
    arma::mat moving_average_params;
    arma::mat covariate_params;

    if(Rcpp::is<Rcpp::List>(method)){
        Rcpp::List initial_parameters = Rcpp::as<Rcpp::List>( method );
        Rcpp::NumericVector intercept_vector = initial_parameters["intercept"];
        intercept = Rcpp::as<arma::vec>(intercept_vector);

        if(orders.n_param_ar > 0){
            Rcpp::NumericMatrix temp_ar = initial_parameters["past_obs"];
            autoregressive_params = Rcpp::as<arma::mat>(temp_ar);
        }

        if(orders.n_param_ma > 0){
            Rcpp::NumericMatrix temp_ma = initial_parameters["past_mean"];
            moving_average_params = Rcpp::as<arma::mat>(temp_ma);
        }

        if(orders.n_param_cov > 0){
            Rcpp::NumericMatrix temp_cov = initial_parameters["covariates"];
            covariate_params = Rcpp::as<arma::mat>(temp_cov);
        }

    } else if(Rcpp::is<Rcpp::NumericVector>(method)){
        Rcpp::NumericVector initial_parameters = Rcpp::as<Rcpp::NumericVector>( method );
        arma::vec params = Rcpp::as<arma::vec>(initial_parameters);
        return params;
    } else {
        Rcpp::CharacterVector init_method = Rcpp::as<Rcpp::CharacterVector>( method );

        // Create param-matrices:
        intercept = arma::vec(orders.n_param_intercept);
        if(orders.n_param_ar > 0){
            autoregressive_params = arma::mat(orders.autoregressive_orders.n_rows, orders.autoregressive_orders.n_cols);
        }
        if(orders.n_param_ma > 0){
            moving_average_params = arma::mat(orders.moving_average_orders.n_rows, orders.moving_average_orders.n_cols);
        }
        if(orders.n_param_cov > 0){
            covariate_params = arma::mat(orders.covariate_orders.n_rows, orders.covariate_orders.n_cols);
        }

        // Modify value of parameters depending on control-argument:
        double param_sum = 0.0;
        if(init_method[0] == "zero"){
            if(family->only_positive_parameters){
                if(orders.n_param_ar > 0){
                    autoregressive_params.elem(orders.which_autoregressive_orders).fill( 1.0 / (orders.n_param_ar + orders.n_param_ma + 10.0) );
                    param_sum += arma::accu(autoregressive_params);
                }
                if(orders.n_param_ma > 0){
                    moving_average_params.elem(orders.which_moving_average_orders).fill( 1.0 / (orders.n_param_ar + orders.n_param_ma + 10.0) );
                    param_sum += arma::accu(moving_average_params);
                }
                if(orders.n_param_cov > 0){
                    covariate_params.elem(orders.which_covariate_orders).fill( 1.0 );
                }
            }
            if(orders.intercepts_equal){
                intercept(0) = (1.0 - param_sum) * arma::mean(arma::mean(data->transformed_obs));
            } else {
                intercept = (1.0 - param_sum) * arma::mean(data->transformed_obs, 1);
            }

        } else if(init_method[0] == "random"){
            if(family->only_positive_parameters){
                if(orders.n_param_ar > 0){
                    autoregressive_params.elem(orders.which_autoregressive_orders) = arma::randu(orders.n_param_ar, arma::distr_param(0.0, 1.0 / (orders.n_param + orders.n_param_ma)));
                    param_sum += arma::accu(autoregressive_params);
                }
                if(orders.n_param_ma > 0){
                    moving_average_params.elem(orders.which_moving_average_orders) = arma::randu(orders.n_param_ma, arma::distr_param(0.0, 1.0 / (orders.n_param + orders.n_param_ma)));
                    param_sum += arma::accu(moving_average_params);
                }
                if(orders.n_param_cov > 0){
                    covariate_params.elem(orders.which_covariate_orders).randu();
                }
            } else {
                if(orders.n_param_ar > 0){
                    autoregressive_params.elem(orders.which_autoregressive_orders) = arma::randu(orders.n_param_ar, arma::distr_param(-1.0 / (orders.n_param + orders.n_param_ma), 1.0 / (orders.n_param + orders.n_param_ma)));
                    param_sum += arma::accu(autoregressive_params);
                }
                if(orders.n_param_ma > 0){
                    moving_average_params.elem(orders.which_moving_average_orders) = arma::randu(orders.n_param_ma, arma::distr_param(-1.0 / (orders.n_param + orders.n_param_ma), 1.0 / (orders.n_param + orders.n_param_ma)));
                    param_sum += arma::accu(moving_average_params);
                }
                if(orders.n_param_cov > 0){
                    covariate_params.elem(orders.which_covariate_orders) = arma::randu(orders.n_param_cov, arma::distr_param(-1.0, 1.0 ));
                }
            }
            if(orders.intercepts_equal){
                intercept(0) = (1.0 - param_sum) * arma::mean(arma::mean(data->transformed_obs));
            } else {
                intercept = (1.0 - param_sum) * arma::mean(data->transformed_obs, 1);
            }

        } else if(init_method[0] == "lm"){
            arma::mat links(data->dim, orders.max_time_lag);
            arma::mat design = initialize_design(orders, data, links);
            arma::vec y = arma::vectorise(data->transformed_obs.tail_cols(orders.n_obs_effective));
            if(orders.n_param_ma > 0){
                arma::uvec indices1 = arma::linspace<arma::uvec>(0, orders.n_param_intercept - 1, orders.n_param_intercept);
                arma::uvec indices2 = arma::linspace<arma::uvec>(orders.n_param_intercept, orders.n_param_intercept + orders.n_param_ma - 1, orders.n_param_ar + orders.n_param_cov);
                arma::uvec indices = arma::join_cols(indices1, indices2);

                design = design.cols(indices);
                arma::mat XtX = design.t() * design;
                arma::vec Xty = design.t() * y;
                arma::vec param_init = arma::solve(XtX, Xty, arma::solve_opts::likely_sympd + arma::solve_opts::no_approx);
                
                if(family->only_positive_parameters){
                    param_init  = arma::clamp(param_init, 0.001, arma::datum::inf);
                }
                if(orders.n_param_ma > 0){
                    arma::vec intercept = param_init.head(orders.n_param_intercept);
                    arma::vec moving_average_params(orders.n_param_ma, arma::fill::value(0.001));
                    arma::vec temp = arma::join_cols(intercept, moving_average_params);
                    temp = arma::join_cols(temp, param_init.tail_cols(orders.n_param_ar + orders.n_param_cov));
                    param_init = temp;
                }

                // Check for stationarity:
                double param_sum = arma::accu( arma::abs( param_init.subvec(orders.n_param_intercept, orders.n_param_intercept + orders.n_param_ma + orders.n_param_ar - 1) ));
                // for(unsigned int i = orders.n_param_intercept; i < orders.n_param_intercept + orders.n_param_ma + orders.n_param_ar; i++){
                //    param_sum += arma::accu() arma::abs(param_init(i));
                // }
                if(param_sum >= 1.0){
                    for(unsigned int i = orders.n_param_intercept; i < orders.n_param_intercept + orders.n_param_ma + orders.n_param_ar; i++){
                        param_init(i) = param_init(i) / (param_sum + 0.1);
                    }
                }
                return param_init;
            }
        } 
    }
    // create and fill parameter vector
    // Rcpp::Rcout << "Param Init 2.0\n";
    arma::vec parameter(orders.n_param);
    parameter.head(orders.n_param_intercept) = intercept;
    if(orders.n_param_ma > 0){
        parameter.subvec(orders.n_param_intercept, orders.n_param_intercept + orders.n_param_ma - 1) = moving_average_params.elem( orders.which_moving_average_orders );
    }
    if(orders.n_param_ar > 0){
        parameter.subvec(orders.n_param_intercept + orders.n_param_ma, orders.n_param_intercept + orders.n_param_ma + orders.n_param_ar - 1) = autoregressive_params.elem( orders.which_autoregressive_orders );
    }
    if(orders.n_param_cov > 0){
        parameter.tail( orders.n_param_cov ) = covariate_params.elem( orders.which_covariate_orders );
    }
    return parameter;
}


/*
    Funktion zum Berechnen von Link-Werten:

    Achtung bei Modellen mit nicht-negativen Parametern: Warnung vor internen Effekten bei solchen Modellen
    for(unsigned int t = 0; t < orders.max_time_lag; t++){
        link_values.col(t) -= internal_cov_effect.subvec(t * data->dim, (t + 1) * data->dim - 1);
    }
*/


arma::mat Model::calc_link_values(const arma::vec &param, const ModelOrderInformation &orders, arma::mat &design, const arma::mat &design_covariates_internal, const Data * data, const arma::mat &init_link, const Family * family){
    arma::mat link_values(data->dim, data->n_obs);
    link_values.head_cols(orders.max_time_lag) = init_link;
    arma::vec link_values_temp;
    if(orders.n_param_ma > 0){
        arma::vec internal_cov_effect;
        if(orders.n_param_cov > 0 && orders.n_internal > 0){
            arma::vec cov_params_internal = param.tail(orders.n_param_cov);
            cov_params_internal = cov_params_internal.elem(orders.which_internal_expanded);
            internal_cov_effect = design_covariates_internal * cov_params_internal;
        }
        unsigned int col_index = orders.n_param_intercept;
        for(unsigned int t = orders.max_time_lag; t < data->n_obs; t++){
            col_index = orders.n_param_intercept;
            for(unsigned int j = 0; j < orders.moving_average_orders.n_cols; j++){
                link_values_temp = link_values.col(t - orders.ma_time_lags(j));
                if(orders.n_internal > 0){
                    link_values_temp -= internal_cov_effect.subvec((t - orders.ma_time_lags(j)) * data->dim, (t - orders.ma_time_lags(j) + 1) * data->dim - 1);
                }
                link_values_temp = family->link_trafo( link_values_temp );
                arma::uvec orders_lag = arma::find( orders.moving_average_orders.col(j) );
                for(unsigned int o : orders_lag){
                    design.submat((t - orders.max_time_lag) * data->dim, col_index, (t - orders.max_time_lag + 1) * data->dim - 1, col_index) = data->multiply_neigh_with_x(o, link_values_temp);
                    col_index++;
                }
            }
            link_values.col(t) = design.rows((t - orders.max_time_lag) * data->dim, (t - orders.max_time_lag + 1) * data->dim - 1) * param;
        }
        link_values = link_values.tail_cols(orders.n_obs_effective);
    } else {
        arma::vec link_values_temp = design * param;
        link_values = arma::reshape(link_values_temp, data->dim, orders.n_obs_effective);
    }
    return link_values;
}

const arma::mat Model::get_ma_parameters(const ModelOrderInformation &orders, const arma::vec &param)
{
    arma::vec ma_params = param.subvec(orders.n_param_intercept, orders.n_param_intercept + orders.n_param_ma - 1); 
    arma::mat param_matrix(orders.moving_average_orders.n_rows, orders.moving_average_orders.n_cols);
    param_matrix.elem(orders.which_moving_average_orders) = ma_params;
    return param_matrix;
}

const arma::mat Model::get_ar_parameters(const ModelOrderInformation &orders, const arma::vec &param)
{
    arma::vec ar_params = param.subvec(orders.n_param_intercept + orders.n_param_ma, orders.n_param_intercept + orders.n_param_ma + orders.n_param_ar - 1); 
    arma::mat param_matrix(orders.autoregressive_orders.n_rows, orders.autoregressive_orders.n_cols);
    param_matrix.elem(orders.which_autoregressive_orders) = ar_params;
    return param_matrix;
}

const arma::mat Model::get_cov_parameters(const ModelOrderInformation &orders, const arma::vec &param)
{
    arma::vec cov_params = param.tail(orders.n_param_cov); 
    arma::mat param_matrix(orders.covariate_orders.n_rows, orders.covariate_orders.n_cols);
    param_matrix.elem(orders.which_covariate_orders) = cov_params;
    return param_matrix;
}

const arma::vec Model::calc_link_value_at(const unsigned int &t, const ModelOrderInformation &orders, const arma::vec &param, const arma::mat &link_vals, const arma::mat &transformed_obs, const Data * data, const bool &ignore_covariates, const Family * family)
{
    arma::vec result(data->dim);
    if(orders.intercepts_equal)
    {
        result.fill( param(0) );
    } else {
        result = param.head(orders.n_param_intercept);
    }

    arma::vec obs;
    arma::vec param_col;
    if(orders.n_param_ar > 0)
    {
        arma::mat ar_params = Model::get_ar_parameters(orders, param);
        for(unsigned int i = 0; i < ar_params.n_cols; i++)
        {
            obs = transformed_obs.col(t - orders.ar_time_lags(i));
            param_col = ar_params.col(i);
            result += data->multiply_param_with_x(param_col, obs);
        }
    }

    arma::mat cov_params;
    arma::vec cov_value;
    if((!ignore_covariates) && (orders.n_param_cov > 0))
    {
        cov_params = Model::get_cov_parameters(orders, param);
    }

    if(orders.n_param_ma > 0)
    {
        arma::mat ma_params = Model::get_ma_parameters(orders, param);
        for(unsigned int j = 0; j < ma_params.n_cols; j++)
        {
            obs = link_vals.col(t - orders.ma_time_lags(j));
            if((!ignore_covariates) && (orders.n_internal > 0))
            {
                for(unsigned int k_int : orders.which_internal)
                {
                    param_col = cov_params.col(k_int);
                    cov_value = data->get_covariate_values(k_int, t - orders.ma_time_lags(j));
                    obs -= data->multiply_param_cov_with_x(param_col, cov_value);
                }
            }
            param_col =  ma_params.col(j);
            result += family->link_trafo( data->multiply_param_with_x(param_col, obs) );
        }
    }
    
    if((!ignore_covariates) && (orders.n_param_cov > 0))
    {
        for(unsigned int k = 0; k < cov_params.n_cols; k++)
        {
            param_col = cov_params.col(k);
            cov_value = data->get_covariate_values(k, t);
            result += data->multiply_param_cov_with_x(param_col, cov_value);
        }
    }
    return result;
}



// Eventuell transponieren und alles spaltenweise machen falls zu langsam

/*
    Funktion zur Berechnung der log-likelihood
*/


double Model::log_likelihood(const arma::vec &param, arma::vec &score, arma::mat &information, arma::mat &link_vals, arma::mat &design, const arma::mat &design_covariates_internal, arma::mat &deriv, const ModelOrderInformation &orders, const Data * data, const Family * family, const arma::mat &init_link, const bool &calc_score, const bool &calc_information)
{
    // Calculate link-values and log-likelihood
    // Rcpp::Rcout << "LogLike - 1\n";
    link_vals = calc_link_values(param, orders, design, design_covariates_internal, data, init_link, family);
    // Rcpp::Rcout << "LogLike - 2\n";
    arma::mat fitted_values = family->inverse_link( link_vals );
    arma::mat weighted_residuals = data->ts.tail_cols(orders.n_obs_effective);
    
    double log_like = arma::accu( family->log_likelihood( weighted_residuals, fitted_values ));
    // Rcpp::Rcout << "LogLike - 3\n";
    if(calc_score || calc_information){
        // Calculate weighted residuals for Score and information:
        arma::mat multiplicant = family->derivative_inverse_link( link_vals );
        multiplicant = multiplicant / family->variance_fun( link_vals );


        // arma::mat divisor = family->derivative_link(fitted_values);
        //divisor = (divisor % fitted_values);
        weighted_residuals -= fitted_values;
        // weighted_residuals = (weighted_residuals / fitted_values);
        weighted_residuals = (multiplicant % weighted_residuals);
        arma::vec vectorised_resid = arma::vectorise(weighted_residuals);
        // Rcpp::Rcout << "LogLike - 4\n";
        arma::mat derivatives;
        if(orders.n_param_ma > 0){
            // Definiere Hilfsvariablen fuer alte Ableitungen usw.
            arma::mat deriv_old;
            arma::mat cov_old;
            arma::uvec internal_cols = orders.which_internal_expanded;
            internal_cols += (orders.n_param_intercept + orders.n_param_ma + orders.n_param_ma);
            // Rcpp::Rcout << "LogLike - 5\n";
            // Erstelle Parametermatrix mit ma-Parametern:
            arma::mat ma_params = get_ma_parameters(orders, param);
            arma::vec ma_param_j;

            derivatives = arma::mat(data->dim * data->n_obs, orders.n_param); // Ableitungen initialisieren
            unsigned int li_old, ui_old, li, ui; // Zaehlindex

            // Berechnung der Ableitung der Link-Transformation
            arma::mat deriv_link_trafo(data->dim, data->n_obs);
            deriv_link_trafo.head_cols(orders.max_time_lag) = init_link;
            deriv_link_trafo.tail_cols(orders.n_obs_effective) = link_vals;
            if(orders.n_param_cov > 0 && orders.n_internal > 0)
            {
                arma::vec cov_params_internal = param.tail(orders.n_param_cov);
                cov_params_internal = cov_params_internal.elem(orders.which_internal_expanded);
                arma::mat internal_cov_effect = design_covariates_internal * cov_params_internal;
                arma::mat subtrahend = arma::reshape(internal_cov_effect, data->dim, data->n_obs);
                deriv_link_trafo -= subtrahend;
            }
            deriv_link_trafo = family->derivative_link_trafo( deriv_link_trafo ); 

            for(int t = orders.max_time_lag; t < data->n_obs; t++)
            {
                li = t * data->dim;
                ui = (t + 1) * data->dim - 1;
                for(unsigned int j = 0; j < orders.moving_average_orders.n_cols; j++)
                {
                    li_old = (t - orders.ma_time_lags(j)) * data->dim;
                    ui_old = (t - orders.ma_time_lags(j) + 1) * data->dim - 1;
                    deriv_old = derivatives.rows(li_old, ui_old);
                    deriv_old = deriv_old.each_col() % deriv_link_trafo.col(t - orders.ma_time_lags(j));
                    ma_param_j = ma_params.col(j);
                    derivatives.rows(li, ui) += data->multiply_param_with_x(ma_param_j, deriv_old);
                    if(orders.n_internal > 0)
                    {
                        cov_old = design_covariates_internal.rows(li_old, ui_old);
                        cov_old = cov_old.each_col() % deriv_link_trafo.col(t - orders.ma_time_lags(j));
                        derivatives.submat(arma::regspace<arma::uvec>(li, ui), internal_cols) -= data->multiply_param_with_x(ma_param_j, cov_old);
                    }
                }
                derivatives.rows(li, ui) += design.rows(li - orders.max_time_lag * data->dim, ui - orders.max_time_lag * data->dim);
            }
            // Rcpp::Rcout << "LogLike - 6\n";
            derivatives = derivatives.tail_rows(orders.n_obs_effective * data->dim);
        }
        else
        {
            derivatives = design;
        }
        deriv = derivatives;
        if(calc_score)
        {
            score = derivatives.t() * vectorised_resid;
        }
        if(calc_information)
        {
            multiplicant = multiplicant % family->derivative_inverse_link( link_vals );
            // multiplicant = multiplicant / fitted_values;
            // arma::sp_mat middle(data->dim * orders.n_obs_effective, data->dim * orders.n_obs_effective);
            // middle.diag() = arma::vectorise( multiplicant );
            information = derivatives.t() * (derivatives.each_col() % arma::vectorise( multiplicant ));
        }
    }
    return log_like;
} 



/*
    Hilfsfunktion zur Rueckgabe des gefitteten Modells
*/

 DynamicModelInformation::DynamicModelInformation(const arma::vec param, const ModelOrderInformation &orders, Data * data, const Family * family, const arma::mat &init_link)
 {
    parameter = param;
    score = arma::vec(orders.n_param);
    information = arma::mat(orders.n_param, orders.n_param);
    // Rcpp::Rcout << "DynamicModel - 1\n";
    design = Init::initialize_design(orders, data, init_link);
    link_values = arma::mat(data->dim, orders.n_obs_effective);
    derivatives = arma::mat(design.n_rows, design.n_cols);
    link_init = init_link;
    // Rcpp::Rcout << "DynamicModel - 2\n";
    if(orders.n_internal > 0)
    {
        design_covariates_internal = arma::mat(data->dim * data->n_obs, orders.n_param_cov);
        design_covariates_internal.tail_rows(data->dim * orders.n_obs_effective) = design.tail_cols(orders.n_param_cov);
        design_covariates_internal = design_covariates_internal.cols(orders.which_internal_expanded);
    } 
    else
    {
        design_covariates_internal = arma::mat(0, 0);
    }
    // Rcpp::Rcout << "DynamicModel - 3\n";
    log_likelihood = Model::log_likelihood(param, score, information, link_values, design, design_covariates_internal, derivatives, orders, data, family, init_link, true, true);
    // Rcpp::Rcout << "DynamicModel - 4\n";
 }

 const arma::mat DynamicModelInformation::variance_estimation(const ModelOrderInformation &orders, const Data* data, const Family * family, const arma::mat &init_link) const
 {
    arma::mat temp(data->dim, orders.n_param);
    arma::vec score_temp(orders.n_param);
    arma::mat H(orders.n_param, orders.n_param);

    arma::mat multiplicant = family->derivative_inverse_link( link_values );
    multiplicant = multiplicant / family->variance_fun( link_values );
    arma::mat fitted_vals = family->inverse_link( link_values );
    arma::mat weighted_residuals = data->ts.tail_cols(orders.n_obs_effective);

    weighted_residuals -= fitted_vals;
    // weighted_residuals = (weighted_residuals / fitted_vals);
    weighted_residuals = (multiplicant % weighted_residuals);

    for(unsigned int t = 0; t < orders.n_obs_effective; t++){
        temp = derivatives.rows(t * data->dim, (t + 1) * data->dim - 1);
        score_temp = temp.t() * weighted_residuals.col(t);
        H += score_temp * score_temp.t();
    }

    arma::mat variance = arma::inv_sympd(information / orders.n_obs_effective);
    return (variance * H * variance) / orders.n_obs_effective;
 }



const Rcpp::List DynamicModelInformation::get_parameter_list(const ModelOrderInformation &orders) const
{
    Rcpp::List parameter_list = Rcpp::List::create(Rcpp::Named("intercept") = parameter.head(orders.n_param_intercept));
    if(orders.n_param_ar > 0){
        arma::mat ar_params(orders.autoregressive_orders.n_rows, orders.autoregressive_orders.n_cols);
        ar_params.elem( orders.which_autoregressive_orders ) = parameter.subvec(orders.n_param_intercept + orders.n_param_ma, orders.n_param_intercept + orders.n_param_ma + orders.n_param_ar - 1);
        parameter_list.push_back(ar_params, "past_obs");
    }
    if(orders.n_param_ma > 0){
        arma::mat ma_params(orders.moving_average_orders.n_rows, orders.moving_average_orders.n_cols);
        ma_params.elem( orders.which_moving_average_orders ) = parameter.subvec(orders.n_param_intercept, orders.n_param_intercept + orders.n_param_ma - 1);
        parameter_list.push_back(ma_params, "past_mean");
    }
    if(orders.n_param_cov > 0){
        arma::mat cov_params(orders.covariate_orders.n_rows, orders.covariate_orders.n_cols);
        cov_params.elem( orders.which_covariate_orders ) = parameter.tail( orders.n_param_cov );
        parameter_list.push_back(cov_params, "covariates");
    }
    return parameter_list;
}




