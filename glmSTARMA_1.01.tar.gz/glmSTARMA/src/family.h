// family.h
#ifndef FAMILY_H
#define FAMILY_H

/*
Diese Klasse enthaelt die Funktionen zum Anpassen von Modellen fuer verschiedene Verteilungen mit unterschiedlichen Link-Funktionen
benoetigt werden.

Folgende Funktionen sind enthalten:

log_likelihood -> Funktion zur Berechnung der Log-Likelihood
inverse_link -> Umkehrfunktion der Link-Funktion
observation_trafo -> Funktion mit der die Beobachtungen im Modell transformiert werden
random_observation -> Funktion zur Erzeugung einer zufaelligen Beobachtung

Optional wird gespeichert:
Copula-Objekt aus dem R-Paket 'copula', um Abhaengigkeiten bei der Erzeugung von zufaelligen Beobachtungen erzeugen zu koennen.
*/


class Family
{
protected:
    Rcpp::S4 copula_object;
    bool use_dependence = false;
    const Rcpp::Environment pkg = Rcpp::Environment::namespace_env("copula");
    Rcpp::Function copula_sample = Rcpp::Environment("package:stats")["rpois"]; // Platzhalter, wird vom Konstruktor ueberschrieben
    virtual const arma::vec random_observation_independent(const arma::vec &expectation) const = 0;
    virtual const arma::vec random_observation(const arma::vec &expectation) const = 0;
    virtual const double inverse_link(const double x) const = 0;
    virtual const double derivative_link_trafo(const double x) const = 0;
    virtual const double derivative_inverse_link(const double x) const = 0;
    virtual const double observation_trafo(const double x) const = 0;
    virtual const double link_trafo(const double x) const = 0;
    virtual const double log_likelihood(const double &observation, const double &expectation) const = 0;
public:
    const bool only_positive_parameters;
    const Rcpp::CharacterVector family_in_R; // Name der Family in R
    const Rcpp::CharacterVector link_name; // Link-Name fuer R

    Family(const bool &only_positive, const Rcpp::Nullable<Rcpp::S4> &copula_obj, const char* family_name, const char* link_name_r)  : only_positive_parameters(only_positive), family_in_R(family_name), link_name(link_name_r)
    {
        copula_sample = pkg["rCopula"];
        if(copula_obj.isNotNull())
        {
            this->use_dependence = true;
            this->copula_object = Rcpp::S4( copula_obj );
        }
    };
    Family(const bool &only_positive, const char* family_name, const char* link_name_r) : only_positive_parameters(only_positive), family_in_R(family_name), link_name(link_name_r)
    {
        copula_sample = pkg["rCopula"];
    };
    virtual Family* clone() const = 0;
    
    Rcpp::Function R_family = Rcpp::Environment("package:stats")["poisson"]; // Temporaere initialisierung
    
    const arma::mat inverse_link(const arma::mat &x) const
    {
        arma::mat result(x.n_rows, x.n_cols);
        for(unsigned int i = 0; i < x.n_rows; i++)
        {
            for(unsigned int j = 0; j < x.n_cols; j++)
            {
                result(i, j) = this->inverse_link( (double) x(i, j));
            }
        }
        return result;
    };
    const arma::mat derivative_inverse_link(const arma::mat &x) const
    {
        arma::mat result(x.n_rows, x.n_cols);
        for(unsigned int i = 0; i < x.n_rows; i++)
        {
            for(unsigned int j = 0; j < x.n_cols; j++)
            {
                result(i, j) = this->derivative_inverse_link( (double) x(i, j));
            }
        }
        return result;
    };
    const arma::mat observation_trafo(const arma::mat &x) const
    {
        arma::mat result(x.n_rows, x.n_cols);
        for(unsigned int i = 0; i < x.n_rows; i++)
        {
            for(unsigned int j = 0; j < x.n_cols; j++)
            {
                result(i, j) = this->observation_trafo( (double) x(i, j));
            }
        }
        return result;
    };
    const arma::mat link_trafo(const arma::mat &x) const
    {
        arma::mat result(x.n_rows, x.n_cols);
        for(unsigned int i = 0; i < x.n_rows; i++)
        {
            for(unsigned int j = 0; j < x.n_cols; j++)
            {
                result(i, j) = this->link_trafo( (double) x(i, j));
            }
        }
        return result;
    };
    const arma::mat derivative_link_trafo(const arma::mat &x) const
    {
        arma::mat result(x.n_rows, x.n_cols);
        for(unsigned int i = 0; i < x.n_rows; i++)
        {
            for(unsigned int j = 0; j < x.n_cols; j++)
            {
                result(i, j) = this->derivative_link_trafo( (double) x(i, j));
            }
        }
        return result;
    };
    const arma::mat log_likelihood(const arma::mat &observations, const arma::mat &expectations) const
    {
        arma::mat result(observations.n_rows, observations.n_cols);
        for(unsigned int i = 0; i < observations.n_rows; i++)
        {
            for(unsigned int j = 0; j < observations.n_cols; j++)
            {
                result(i, j) = this->log_likelihood( (double) observations(i, j), (double) expectations(i, j) );
            }
        }
        return result;
    };
    virtual const arma::mat variance_fun(const arma::mat &link_values) const = 0;

    const arma::vec sample(const arma::vec &expectation) const
    {
        if(this->use_dependence){
            return random_observation(expectation);
        } else {
            return random_observation_independent(expectation);
        }
    };
    virtual const bool valid_expectation(const arma::mat &x) const = 0;
    virtual const bool valid_link(const arma::mat &x) const = 0;
};

Family * generate_family_from_list(const Rcpp::List &family);
Family * generate_family_from_list(const Rcpp::List &family, Rcpp::S4& copula_obj);

Family * generate_poisson(const Rcpp::List &family);
Family * generate_poisson(const Rcpp::List &family, Rcpp::S4& copula_obj);

Family * generate_negative_binomial(const Rcpp::List &family);
Family * generate_negative_binomial(const Rcpp::List &family, Rcpp::S4& copula_obj);

Family * generate_binomial(const Rcpp::List &family);
Family * generate_binomial(const Rcpp::List &family, Rcpp::S4& copula_obj);

Family * generate_gamma(const Rcpp::List &family);
Family * generate_gamma(const Rcpp::List &family, Rcpp::S4& copula_obj);

Family * generate_inverse_gaussian(const Rcpp::List &family);
Family * generate_inverse_gaussian(const Rcpp::List &family, Rcpp::S4& copula_obj);

Family * generate_normal(const Rcpp::List &family);
Family * generate_normal(const Rcpp::List &family, Rcpp::S4& copula_obj);

Family * generate_garch(const Rcpp::List &family);
Family * generate_garch(const Rcpp::List &family, Rcpp::S4& copula_obj);


#endif
