// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"

#include <chrono>
#include <thread>
using namespace std::this_thread;
using namespace std::chrono_literals;
using namespace Rcpp;

/*
    Definiere Verteilung fuer GARCH-Modell
*/

class GARCH : public Family 
{
  protected:
    virtual const arma::vec random_observation_independent(const arma::vec &expectation) const;
    virtual const arma::vec random_observation(const arma::vec &expectation) const;
    virtual const double log_likelihood(const double &observation, const double &expectation) const;
  public:
    GARCH(const bool &only_positive, const Rcpp::Nullable<Rcpp::S4> &copula_obj, const char* link_name_r) : Family(only_positive, copula_obj, "GARCH", link_name_r){
      R_family = Rcpp::Environment("package:stats")["Gaussian"]; // Wozu??
    };
    GARCH(const bool &only_positive, const char* link_name_r) : Family(only_positive, "GARCH", link_name_r) {};
    virtual const bool valid_expectation(const arma::mat &x) const;
    virtual const arma::mat variance_fun(const arma::mat &link_values) const;
};


const arma::vec GARCH::random_observation_independent(const arma::vec &expectation) const
{
  arma::vec observations(expectation.n_elem, arma::fill::randn);
  observations *= sqrt(expectation);
  observations = square(observations);
  return observations;
}

const arma::vec GARCH::random_observation(const arma::vec &expectation) const
{
    arma::vec observations(expectation.n_elem, arma::fill::randn);
    observations *= sqrt(expectation);
    observations = square(observations);
    return observations;
}


const double GARCH::log_likelihood(const double &observation, const double &expectation) const 
{
    double val = -0.5 * log(2.0 * arma::datum::pi * expectation);
    val -= 0.5 * observation / expectation;
    return val;
}

const bool GARCH::valid_expectation(const arma::mat &x) const 
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}

const arma::mat GARCH::variance_fun(const arma::mat &link_values) const
{
    arma::mat response = this->inverse_link(link_values);
    return 2.0 * arma::square(response);
}


/*
    Definiere Identity-Link, d.h. normales GARCH-Modell
*/


class LinearGARCH : public GARCH {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LinearGARCH(const Rcpp::Nullable<Rcpp::S4> &copula_obj) : GARCH(true, copula_obj, "identity"){};
    LinearGARCH() : GARCH(true, "identity"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LinearGARCH(this->copula_object);
      } else {
        return new LinearGARCH();
      }
    };
};


const double LinearGARCH::inverse_link(const double x) const
{
  return x;
}

const double LinearGARCH::derivative_inverse_link(const double x) const
{
  return 1.0;
}


const double LinearGARCH::observation_trafo(const double x) const
{
  return x;
}

const double LinearGARCH::link_trafo(const double x) const
{
  return x;
}

const double LinearGARCH::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LinearGARCH::valid_link(const arma::mat &x) const
{
  return x.is_finite() && arma::all(arma::vectorise(x) > 0.0);
}


/*
    Definiere Log-GARCH Modell
*/

class LogGARCH : public GARCH {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LogGARCH(const Rcpp::Nullable<Rcpp::S4> &copula_obj) : GARCH(false, copula_obj, "log"){};
    LogGARCH() : GARCH(false, "log"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LogGARCH(this->copula_object);
      } else {
        return new LogGARCH();
      }
    };
};


const double LogGARCH::inverse_link(const double x) const
{
  return exp(x);
}

const double LogGARCH::derivative_inverse_link(const double x) const
{
  return exp(x);
}


const double LogGARCH::observation_trafo(const double x) const
{
  return log(x);
}

const double LogGARCH::link_trafo(const double x) const
{
  return x;
}

const double LogGARCH::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LogGARCH::valid_link(const arma::mat &x) const
{
  return true;
}



Family * generate_garch(const Rcpp::List &family)
{
  Rcpp::CharacterVector link = family["link"];
  if(link[0] == "log")
  {
    return new LogGARCH();
  } 
  else if(link[0] == "identity") 
  {
    return new LinearGARCH();
  }
  else
  {
    throw std::invalid_argument("The desired link is currently not yet implemented.");
  }
}


Family * generate_garch(const Rcpp::List &family, Rcpp::S4& copula_obj)
{
  Rcpp::CharacterVector link = family["link"];
  if(link[0] == "log")
  {
    return new LogGARCH(copula_obj);
  } 
  else if(link[0] == "identity") 
  {
    return new LinearGARCH(copula_obj);
  } 
  else
  {
    throw std::invalid_argument("The desired link is currently not yet implemented.");
  }
}




