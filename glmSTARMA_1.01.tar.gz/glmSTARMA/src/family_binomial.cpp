// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"

#include <chrono>
#include <thread>
using namespace std::this_thread;
using namespace std::chrono_literals;
using namespace Rcpp;


/*
  Definiere Binomial-Verteilung:
*/

class Binomial : public Family 
{
  protected:
    const unsigned int n_upper;
    virtual const arma::vec random_observation_independent(const arma::vec &expectation) const;
    virtual const arma::vec random_observation(const arma::vec &expectation) const;
    virtual const double log_likelihood(const double &observation, const double &expectation) const;
  public:
    Binomial(const unsigned int n, const bool &only_positive, const Rcpp::Nullable<Rcpp::S4> &copula_obj, const char* link_name_r) : Family(only_positive, copula_obj, "binomial", link_name_r), n_upper(n){
      R_family = Rcpp::Environment("package:stats")["binomial"]; 
    };
    Binomial(const unsigned int n, const bool &only_positive, const char* link_name_r) : Family(only_positive, "binomial", link_name_r), n_upper(n) {};
    virtual const bool valid_expectation(const arma::mat &x) const;
    virtual const arma::mat variance_fun(const arma::mat &link_values) const;
};

const arma::vec Binomial::random_observation_independent(const arma::vec &expectation) const
{
  arma::vec observations(expectation.n_elem, arma::fill::zeros);
  for(unsigned int i = 0; i < expectation.n_elem; i++)
  {
    observations(i) = Rcpp::as<double>(Rcpp::rbinom(1, n_upper, expectation(i) / n_upper));
  }
  return observations;
}

const arma::vec Binomial::random_observation(const arma::vec &expectation) const
{
    arma::vec observations(expectation.n_elem, arma::fill::zeros);
    arma::vec copula_values = as<arma::vec>(this->copula_sample(1, this->copula_object));
    for(unsigned int i = 0; i < expectation.n_elem; i++)
    {
        observations(i) = R::qbinom(copula_values(i), n_upper, expectation(i) / n_upper, true, false);
    }
    return observations;
}

const double Binomial::log_likelihood(const double &observation, const double &expectation) const 
{
  return R::dbinom( observation, n_upper, expectation / n_upper, true );
}


const bool Binomial::valid_expectation(const arma::mat &x) const 
{
  return x.is_finite() && arma::all(arma::vectorise(x) >= 0.0) && arma::all(arma::vectorise(x) <= n_upper);
}

const arma::mat Binomial::variance_fun(const arma::mat &link_values) const
{
    arma::mat fitted = this->inverse_link(link_values);
    arma::mat ones = arma::ones(fitted.n_rows, fitted.n_cols);
    return fitted % (ones - fitted) * n_upper;
}


/*
    Definiere verschiedene Link-Funktionen fuer das Binomial-Modell:
*/


/*
  Definiere approximativ lineares Modell, d.h. den 'softclipping'-Link der Binomial-Verteilung aus der Arbeit von Jahn et al. (2023)
*/

class SoftClippingBinomial : public Binomial {
  protected:
    const double tuning_param;
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    SoftClippingBinomial(unsigned int n, double constant, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Binomial(n, false, copula_obj, "softclipping"), tuning_param(constant){};
    SoftClippingBinomial(unsigned int n, double constant) : Binomial(n, false, "softclipping"), tuning_param(constant){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new SoftClippingBinomial(this->n_upper, this->tuning_param, this->copula_object);
      } else {
        return new SoftClippingBinomial(this->n_upper, this->tuning_param);
      }
    };
};


const double SoftClippingBinomial::inverse_link(const double x) const
{
    double upper = 1.0 + exp(x / tuning_param);
    double lower = 1.0 + exp((x - 1.0) / tuning_param);
    return n_upper * tuning_param * std::log(upper / lower);
}

const double SoftClippingBinomial::derivative_inverse_link(const double x) const
{
  double val_first = exp(x / tuning_param) / (1.0 + exp(x / tuning_param));
  double val_second = exp((x - 1.0) / tuning_param) / (1.0 + exp((x - 1.0) / tuning_param));
  return n_upper * (val_first - val_second);
}

const double SoftClippingBinomial::observation_trafo(const double x) const
{
  return x / n_upper;
}


const double SoftClippingBinomial::link_trafo(const double x) const
{
    return inverse_link(x) / n_upper;
}

const double SoftClippingBinomial::derivative_link_trafo(const double x) const
{
  return derivative_inverse_link(x) / n_upper;
}

const bool SoftClippingBinomial::valid_link(const arma::mat &x) const
{
  return true;
}

/*
  Implementierung des Identity-Links
*/


class IdentityBinomial : public Binomial {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double observation_trafo(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    IdentityBinomial(unsigned int n, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Binomial(n, true, copula_obj, "identity"){};
    IdentityBinomial(unsigned int n) : Binomial(n, true, "identity"){};
    virtual const bool valid_link(const arma::mat &x) const;
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new IdentityBinomial(this->n_upper, this->copula_object);
      } else {
        return new IdentityBinomial(this->n_upper);
      }
    };
};


const double IdentityBinomial::inverse_link(const double x) const
{
    return n_upper * x;
}

const double IdentityBinomial::derivative_inverse_link(const double x) const
{
  return n_upper * 1.0;
}

const double IdentityBinomial::observation_trafo(const double x) const
{
  return x / n_upper;
}


const double IdentityBinomial::link_trafo(const double x) const
{
    return x;
}

const double IdentityBinomial::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool IdentityBinomial::valid_link(const arma::mat &x) const
{
  return x.is_finite() && arma::all(arma::vectorise(x) >= 0.0) && arma::all(arma::vectorise(x) <= n_upper);
}



/*
  Implementierung des Logit-Links
*/

class LogitBinomial : public Binomial {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LogitBinomial(unsigned int n, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Binomial(n, false, copula_obj, "logit"){};
    LogitBinomial(unsigned int n) : Binomial(n, false, "logit"){};
    virtual const bool valid_link(const arma::mat &x) const;
};

const double LogitBinomial::inverse_link(const double x) const
{
    return n_upper / (1.0 + exp(-x));
}

const double LogitBinomial::derivative_inverse_link(const double x) const
{
  return n_upper / ((1.0 + exp(-x)) * (1.0 + exp(x)));
}

const double LogitBinomial::link_trafo(const double x) const
{
    return x;
}

const double LogitBinomial::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LogitBinomial::valid_link(const arma::mat &x) const
{
  return true;
}


class LogitBinomialTrafo : public LogitBinomial {
  protected:
    const double tuning_param;
    virtual const double observation_trafo(const double x) const;
  public:
    LogitBinomialTrafo(unsigned int n, double constant, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : LogitBinomial(n, copula_obj), tuning_param(constant){};
    LogitBinomialTrafo(unsigned int n, double constant) : LogitBinomial(n), tuning_param(constant){};
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LogitBinomialTrafo(this->n_upper, this->tuning_param, this->copula_object);
      } else {
        return new LogitBinomialTrafo(this->n_upper, this->tuning_param);
      }
    };
};

class LogitBinomialNoTrafo : public LogitBinomial {
  protected:
    virtual const double observation_trafo(const double x) const;
  public:
    LogitBinomialNoTrafo(unsigned int n, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : LogitBinomial(n, copula_obj){};
    LogitBinomialNoTrafo(unsigned int n) : LogitBinomial(n){};
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LogitBinomialNoTrafo(this->n_upper, this->copula_object);
      } else {
        return new LogitBinomialNoTrafo(this->n_upper);
      }
    };
};


const double LogitBinomialTrafo::observation_trafo(const double x) const
{
  double temp_trafo = x / n_upper;
  temp_trafo = (1.0 - 2.0 * tuning_param) * temp_trafo + tuning_param;
  return log(temp_trafo / (1.0 - temp_trafo));
}

const double LogitBinomialNoTrafo::observation_trafo(const double x) const
{
  return x / n_upper;
}

/*
  Implementierung des Probit-Links
*/


class ProbitBinomial : public Binomial {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    ProbitBinomial(unsigned int n, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Binomial(n, false, copula_obj, "probit"){};
    ProbitBinomial(unsigned int n) : Binomial(n, false, "probit"){};
    virtual const bool valid_link(const arma::mat &x) const;
};

const double ProbitBinomial::inverse_link(const double x) const
{
    return n_upper * R::pnorm( x, 0.0, 1.0, true, false);
}

const double ProbitBinomial::derivative_inverse_link(const double x) const
{
  return n_upper * R::dnorm( x, 0.0, 1.0, false);
}

const double ProbitBinomial::link_trafo(const double x) const
{
    return x;
}

const double ProbitBinomial::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool ProbitBinomial::valid_link(const arma::mat &x) const
{
  return true;
}


class ProbitBinomialTrafo : public ProbitBinomial {
  protected:
    const double tuning_param;
    virtual const double observation_trafo(const double x) const;
  public:
    ProbitBinomialTrafo(unsigned int n, double constant, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : ProbitBinomial(n, copula_obj), tuning_param(constant){};
    ProbitBinomialTrafo(unsigned int n, double constant) : ProbitBinomial(n), tuning_param(constant){};
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new ProbitBinomialTrafo(this->n_upper, this->tuning_param, this->copula_object);
      } else {
        return new ProbitBinomialTrafo(this->n_upper, this->tuning_param);
      }
    };
};

class ProbitBinomialNoTrafo : public ProbitBinomial {
  protected:
    virtual const double observation_trafo(const double x) const;
  public:
    ProbitBinomialNoTrafo(unsigned int n, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : ProbitBinomial(n, copula_obj){};
    ProbitBinomialNoTrafo(unsigned int n) : ProbitBinomial(n){};
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new ProbitBinomialNoTrafo(this->n_upper, this->copula_object);
      } else {
        return new ProbitBinomialNoTrafo(this->n_upper);
      }
    };
};

const double ProbitBinomialTrafo::observation_trafo(const double x) const
{
  double temp_trafo = x / n_upper;
  temp_trafo = (1.0 - 2.0 * tuning_param) * temp_trafo + tuning_param;
  return R::qnorm(temp_trafo, 0.0, 1.0, true, false);
}

const double ProbitBinomialNoTrafo::observation_trafo(const double x) const
{
  return x / n_upper;
}

/*
  Implementiere Log-Link
*/

class LogBinomial : public Binomial {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    LogBinomial(unsigned int n, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Binomial(n, false, copula_obj, "log"){};
    LogBinomial(unsigned int n) : Binomial(n, false, "log"){};
    virtual const bool valid_link(const arma::mat &x) const;
};

const double LogBinomial::inverse_link(const double x) const
{
    return n_upper * exp(x);
}

const double LogBinomial::derivative_inverse_link(const double x) const
{
  return n_upper * exp(x);
}

const double LogBinomial::link_trafo(const double x) const
{
    return x;
}

const double LogBinomial::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool LogBinomial::valid_link(const arma::mat &x) const
{
  return true;
}


class LogBinomialTrafo : public LogBinomial {
  protected:
    const double tuning_param;
    virtual const double observation_trafo(const double x) const;
  public:
    LogBinomialTrafo(unsigned int n, double constant, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : LogBinomial(n, copula_obj), tuning_param(constant){};
    LogBinomialTrafo(unsigned int n, double constant) : LogBinomial(n), tuning_param(constant){};
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LogBinomialTrafo(this->n_upper, this->tuning_param, this->copula_object);
      } else {
        return new LogBinomialTrafo(this->n_upper, this->tuning_param);
      }
    };
};

class LogBinomialNoTrafo : public LogBinomial {
  protected:
    virtual const double observation_trafo(const double x) const;
  public:
    LogBinomialNoTrafo(unsigned int n, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : LogBinomial(n, copula_obj){};
    LogBinomialNoTrafo(unsigned int n) : LogBinomial(n){};
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new LogBinomialNoTrafo(this->n_upper, this->copula_object);
      } else {
        return new LogBinomialNoTrafo(this->n_upper);
      }
    };
};

const double LogBinomialTrafo::observation_trafo(const double x) const
{
  double temp_trafo = x / n_upper;
  temp_trafo = (1.0 - 2.0 * tuning_param) * temp_trafo + tuning_param;
  return log(temp_trafo);
}

const double LogBinomialNoTrafo::observation_trafo(const double x) const
{
  return x / n_upper;
}

/*
 Implementiere cloglog-Link
*/


class cLogLogBinomial : public Binomial {
  protected:
    virtual const double inverse_link(const double x) const;
    virtual const double derivative_inverse_link(const double x) const;
    virtual const double link_trafo(const double x) const;
    virtual const double derivative_link_trafo(const double x) const;
  public:
    cLogLogBinomial(unsigned int n, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : Binomial(n, false, copula_obj, "cloglog"){};
    cLogLogBinomial(unsigned int n) : Binomial(n, false, "cloglog"){};
    virtual const bool valid_link(const arma::mat &x) const;
};

const double cLogLogBinomial::inverse_link(const double x) const
{
    return n_upper * (1.0 - exp(-exp(x)));
}

const double cLogLogBinomial::derivative_inverse_link(const double x) const
{
  return n_upper * exp(x - exp(x));
}

const double cLogLogBinomial::link_trafo(const double x) const
{
    return x;
}

const double cLogLogBinomial::derivative_link_trafo(const double x) const
{
  return 1.0;
}

const bool cLogLogBinomial::valid_link(const arma::mat &x) const
{
  return true;
}


class cLogLogBinomialTrafo : public cLogLogBinomial {
  protected:
    const double tuning_param;
    virtual const double observation_trafo(const double x) const;
  public:
    cLogLogBinomialTrafo(unsigned int n, double constant, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : cLogLogBinomial(n, copula_obj), tuning_param(constant){};
    cLogLogBinomialTrafo(unsigned int n, double constant) : cLogLogBinomial(n), tuning_param(constant){};
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new cLogLogBinomialTrafo(this->n_upper, this->tuning_param, this->copula_object);
      } else {
        return new cLogLogBinomialTrafo(this->n_upper, this->tuning_param);
      }
    };
};

class cLogLogBinomialNoTrafo : public cLogLogBinomial {
  protected:
    virtual const double observation_trafo(const double x) const;
  public:
    cLogLogBinomialNoTrafo(unsigned int n, const Rcpp::Nullable<Rcpp::S4> &copula_obj) : cLogLogBinomial(n, copula_obj){};
    cLogLogBinomialNoTrafo(unsigned int n) : cLogLogBinomial(n){};
    virtual Family* clone() const
    {
      if(use_dependence)
      {
        return new cLogLogBinomialNoTrafo(this->n_upper, this->copula_object);
      } else {
        return new cLogLogBinomialNoTrafo(this->n_upper);
      }
    };
};

const double cLogLogBinomialTrafo::observation_trafo(const double x) const
{
  double temp_trafo = x / n_upper;
  temp_trafo = (1.0 - 2.0 * tuning_param) * temp_trafo + tuning_param;
  return log(-log(1 - temp_trafo));
}

const double cLogLogBinomialNoTrafo::observation_trafo(const double x) const
{
  return x / n_upper;
}





// TODO:

/*
- identity
- softclipping
- logit
- probit
- log
- cloglog
*/

Family * generate_binomial(const Rcpp::List &family)
{
  Rcpp::CharacterVector link = family["link"];
  Rcpp::IntegerVector size = family["size"];
  unsigned int n = size[0];
  if(link[0] == "identity")
  {
    return new IdentityBinomial(n);
  } else if(link[0] == "softclipping")
  {
    Rcpp::NumericVector temp_const = family["const"];
    double constant = temp_const[0];
    return new SoftClippingBinomial(n, constant);
  }
  else
  {
    Rcpp::LogicalVector transform_obs = family["transform_obs"];
    if(transform_obs[0])
    {
      Rcpp::NumericVector temp_const = family["const"];
      double constant = temp_const[0];
      if(link[0] == "logit")
      {
        return new LogitBinomialTrafo(n, constant);
      } else if(link[0] == "probit")
      {
        return new ProbitBinomialTrafo(n, constant);
      } else if(link[0] == "log")
      {
        return new LogBinomialTrafo(n, constant);
      } else if(link[0] == "cloglog")
      {
        return new cLogLogBinomialTrafo(n, constant);
      } else {
        throw std::invalid_argument("The desired link is currently not yet implemented.");
      }
    }
    else
    {
      if(link[0] == "logit")
      {
        return new LogitBinomialNoTrafo(n);
      } else if(link[0] == "probit")
      {
        return new ProbitBinomialNoTrafo(n);
      } else if(link[0] == "log")
      {
        return new LogBinomialNoTrafo(n);
      } else if(link[0] == "cloglog")
      {
        return new cLogLogBinomialNoTrafo(n);
      } else {
        throw std::invalid_argument("The desired link is currently not yet implemented.");
      }
    }
  }
}



Family * generate_binomial(const Rcpp::List &family, Rcpp::S4& copula_obj)
{
  Rcpp::CharacterVector link = family["link"];
  Rcpp::IntegerVector size = family["size"];
  unsigned int n = size[0];
  if(link[0] == "identity")
  {
    return new IdentityBinomial(n, copula_obj);
  } else if(link[0] == "softclipping")
  {
    Rcpp::NumericVector temp_const = family["const"];
    double constant = temp_const[0];
    return new SoftClippingBinomial(n, constant, copula_obj);
  }
  else
  {
    Rcpp::LogicalVector transform_obs = family["transform_obs"];
    if(transform_obs[0])
    {
      Rcpp::NumericVector temp_const = family["const"];
      double constant = temp_const[0];
      if(link[0] == "logit")
      {
        return new LogitBinomialTrafo(n, constant, copula_obj);
      } else if(link[0] == "probit")
      {
        return new ProbitBinomialTrafo(n, constant, copula_obj);
      } else if(link[0] == "log")
      {
        return new LogBinomialTrafo(n, constant, copula_obj);
      } else if(link[0] == "cloglog")
      {
        return new cLogLogBinomialTrafo(n, constant, copula_obj);
      } else {
        throw std::invalid_argument("The desired link is currently not yet implemented.");
      }
    }
    else
    {
      if(link[0] == "logit")
      {
        return new LogitBinomialNoTrafo(n, copula_obj);
      } else if(link[0] == "probit")
      {
        return new ProbitBinomialNoTrafo(n, copula_obj);
      } else if(link[0] == "log")
      {
        return new LogBinomialNoTrafo(n, copula_obj);
      } else if(link[0] == "cloglog")
      {
        return new cLogLogBinomialNoTrafo(n, copula_obj);
      } else {
        throw std::invalid_argument("The desired link is currently not yet implemented.");
      }
    }
  }
}
