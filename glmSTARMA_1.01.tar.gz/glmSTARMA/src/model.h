#ifndef MODEL_H
#define MODEL_H

/*
    Klasse mit allen Hyperparametern des Modells, d.h. den Einstellungen die sich nicht mehr aendern koennen
*/

class ModelOrderInformation
{
    private:
    bool get_intercept_information(const Rcpp::List& model_definition) const;
    arma::umat get_model_order(const Rcpp::List& model_definition, const char* variable) const;
    arma::uvec get_time_lags(const Rcpp::List& model_definition, const char* variable) const;
    unsigned int calc_max_time_lag() const;

    public:
    // Modellordnungen
    const bool intercepts_equal;
    const arma::umat autoregressive_orders;
    const arma::uvec which_autoregressive_orders;
    const arma::uvec ar_time_lags;
    const arma::umat moving_average_orders;
    const arma::uvec which_moving_average_orders;
    const arma::uvec ma_time_lags;
    const arma::umat covariate_orders;
    const arma::uvec which_covariate_orders;
    const arma::uvec internal_external_covariates;
    const arma::uvec which_internal;
    

    // Anzahl Parameter und weiteres:
    const unsigned int max_time_lag;
    const unsigned int max_ma_lag;
    const unsigned int n_param_intercept;
    const unsigned int n_param_ar;
    const unsigned int n_param_ma;
    const unsigned int n_param_cov;
    const unsigned int n_param;
    const unsigned int n_obs_effective;
    const unsigned int n_internal;

    // Nicht konstante Vektoren:
    arma::vec external_expanded;
    arma::uvec which_internal_expanded;


    // Konstruktor:
    ModelOrderInformation(const Rcpp::List &model_definition, const unsigned int &dim, const unsigned int &obs) : intercepts_equal( get_intercept_information(model_definition) ), 
                                                                                              autoregressive_orders( get_model_order(model_definition, "past_obs") ), 
                                                                                              which_autoregressive_orders( arma::find(autoregressive_orders != 0) ),
                                                                                              ar_time_lags( get_time_lags(model_definition, "past_obs_time_lags") ), 
                                                                                              moving_average_orders( get_model_order(model_definition, "past_mean") ),
                                                                                              which_moving_average_orders( arma::find(moving_average_orders != 0) ),
                                                                                              ma_time_lags( get_time_lags(model_definition, "past_mean_time_lags") ),
                                                                                              covariate_orders( get_model_order(model_definition, "covariates") ),
                                                                                              which_covariate_orders( arma::find(covariate_orders != 0) ), 
                                                                                              internal_external_covariates( get_time_lags(model_definition, "external") ),
                                                                                              which_internal( arma::find(internal_external_covariates != 0) ),
                                                                                              max_time_lag( calc_max_time_lag() ),
                                                                                              max_ma_lag( ma_time_lags.n_elem > 0 ? ma_time_lags.max() : 0 ),
                                                                                              n_param_intercept( intercepts_equal ? 1 : dim ), 
                                                                                              n_param_ar( arma::accu(autoregressive_orders) ), 
                                                                                              n_param_ma( arma::accu(moving_average_orders) ), 
                                                                                              n_param_cov( arma::accu(covariate_orders) ), 
                                                                                              n_param(n_param_intercept + n_param_ar + n_param_ma + n_param_cov),
                                                                                              n_obs_effective( obs - max_time_lag ),
                                                                                              n_internal( which_internal.n_elem ) 
    {
        external_expanded = arma::vec(n_param_cov);
        external_expanded.zeros();
        unsigned int counter = 0;
        unsigned int k_order = 0;
        for(unsigned int k = 0; k < covariate_orders.n_cols; k++){
            k_order = arma::accu(covariate_orders.col(k) != 0);
            external_expanded.subvec(counter, counter + k_order - 1) = internal_external_covariates(k);
            counter += k_order;
        }
        which_internal_expanded = arma::find(external_expanded != 0);
    };
    /*ModelOrderInformation(ModelOrderInformation &orders) : intercepts_equal(orders.intercepts_equal),
                                                          autoregressive_orders(orders.autoregressive_orders),
                                                          which_autoregressive_orders(orders.which_autoregressive_orders),
                                                          ar_time_lags(orders.ar_time_lags),
                                                          moving_average_orders(orders.moving_average_orders),
                                                          which_moving_average_orders(orders.which_moving_average_orders),
                                                          ma_time_lags(orders.ma_time_lags),
                                                          covariate_orders(orders.covariate_orders),
                                                          which_covariate_orders(orders.which_covariate_orders),
                                                          internal_external_covariates(orders.internal_external_covariates),
                                                          which_internal(orders.which_internal),
                                                          max_time_lag(orders.max_time_lag),
                                                          max_ma_lag(orders.max_ma_lag),
                                                          n_param_intercept(orders.n_param_intercept),
                                                          n_param_ar(orders.n_param_ar),
                                                          n_param_ma(orders.n_param_ma),
                                                          n_param_cov(orders.n_param_cov),
                                                          n_param(orders.n_param),
                                                          n_obs_effective(orders.n_obs_effective),
                                                          n_internal(orders.n_internal){};
                                                          //external_expanded(orders.external_expanded),
                                                          //which_internal_expanded(orders.which_internal_expanded){};*/
};

/*
    Klasse zur Initialsierung des Modells.
    Enthaelt Funktionen zur Wahl der ersten Link-Werte, d.h. des Feedbackterms, sowie der Parameter
*/

class Init
{
    public:
    static arma::mat init_link(const Rcpp::RObject &method,  const ModelOrderInformation &orders, const Data* data, const Family* family);
    static arma::mat initialize_design(const ModelOrderInformation &orders, const Data* data, const arma::mat &linkvals);
    static arma::vec init_param(const Rcpp::RObject &method, const ModelOrderInformation &orders, const Data* data, const Family* family);
};



/*
    Klasse mit verschiedenen Funktionen zur Berechnung der Likelihood usw.
*/

class Model
{
    public:
    static double log_likelihood(const arma::vec &param, arma::vec &score, arma::mat &information, arma::mat &link_vals, arma::mat &design, const arma::mat &design_covariates_internal, arma::mat &deriv, const ModelOrderInformation &orders, const Data * data, const Family * family, const arma::mat &init_link, const bool &calc_score, const bool &calc_information);
    static arma::mat calc_link_values(const arma::vec &param, const ModelOrderInformation &orders, arma::mat &design, const arma::mat &design_covariates_internal, const Data * data, const arma::mat &init_link, const Family * family);
    static const arma::mat get_ma_parameters(const ModelOrderInformation &orders, const arma::vec &param);
    static const arma::mat get_ar_parameters(const ModelOrderInformation &orders, const arma::vec &param);
    static const arma::mat get_cov_parameters(const ModelOrderInformation &orders, const arma::vec &param);
    static const arma::vec calc_link_value_at(const unsigned int &t, const ModelOrderInformation &orders, const arma::vec &param, const arma::mat &link_vals, const arma::mat &transformed_obs, const Data * data, const bool &ignore_covariates, const Family * family);
};



/*
    Klasse die alle Informationen enthaelt, die sich waehrend der Parameterschaetzung aendern koennen.
*/

// Konstruktor fehlt noch

class DynamicModelInformation
{
    public:
    arma::vec parameter;
    arma::vec score;
    arma::mat information;
    
    double log_likelihood;
    arma::mat link_values;
    arma::mat design;
    arma::mat design_covariates_internal;
    arma::mat derivatives;
    arma::mat link_init;

    DynamicModelInformation(const arma::vec param, const ModelOrderInformation &orders, Data * data, const Family * family, const arma::mat &init_link);
    const Rcpp::List get_parameter_list(const ModelOrderInformation &orders) const;
    const arma::mat variance_estimation(const ModelOrderInformation &orders, const Data* data, const Family * family, const arma::mat &init_link) const;
};




// TODO: Nachschauen ob noch relevant:
/*
        Moeglichkeiten zur Parameterinitialisierung
        - Werte uebergeben (fuer Simulation) in Liste
        - zero  -> Fuer Modelle mit negativen Parametern, AR usw. auf 0 und Intercept auf Mittelwert der transformierten Beobachtungen
                -> Fuer rein positive Modelle: anteilig AR und MA-Anzahl + 15 und Kovariablen auf 1 / Mittelwert auf 1 - summe... * x_quer
        - random    -> auch negative Parameter: anteilig zufaellig zwischen - und + (anzahl Parameter) / Mittelwert entsprechend / Kovariablen in [-1, 1]
                    -> nur Positive:  anteilig zwischen AR und MA-Anzahl / Kovariablen auf 1
    */





/*
Initialisierungsmoeglichkeiten der Link-Werte:
- Uebergabe als Matrix
- Character aus:
    - first_obs -> entspricht den ersten transformierten Beobachtungen
    - mean -> Mittelwert der transformierten Zeitreihe (pro Zeile)
    - transformed_mean -> transformierter Mittelwert der original Zeitreihe (pro Zeile)
    - zero -> mit 0 initialisiert
    - parameter -> basierend auf Startparametern der unbedingte Mittelwert
*/

#endif
