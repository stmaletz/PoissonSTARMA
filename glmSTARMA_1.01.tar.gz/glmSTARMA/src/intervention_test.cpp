// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
// [[Rcpp::depends(RcppProgress)]]
#include "glmstarma.h"

#include <chrono>
#include <thread>
#include <iostream>
#include <vector>
#include <future>
#include <thread>
#include <mutex>
#include <RcppThread.h>
#include <progress.hpp>
#include <progress_bar.hpp>

// Protect against compilers without OpenMP
#ifdef _OPENMP
#include <omp.h>
#endif
// [[Rcpp::plugins(openmp)]]
using namespace std::this_thread;
using namespace std::chrono_literals;
using namespace Rcpp;

// std::mutex resultsMutex;


arma::mat detect_intervention(const ModelOrderInformation& orders, const Data * data, const DynamicModelInformation& estimation, const Family * family, const arma::uvec& time_points, const arma::uvec& locations, const arma::vec& intervention_param, const bool& external)
{
    arma::mat link_values = estimation.link_values;
    arma::mat deriv_inverse_link = family->derivative_inverse_link( link_values );
    arma::mat fitted_vals = family->inverse_link( link_values );
    arma::mat weighted_residuals = data->ts.tail_cols(orders.n_obs_effective);
    weighted_residuals -= fitted_vals;
    weighted_residuals = (weighted_residuals / family->variance_fun(link_values));
    weighted_residuals = (deriv_inverse_link % weighted_residuals); // For Score-Vector

    arma::mat information_middle = (deriv_inverse_link % deriv_inverse_link) / fitted_vals; // For the middle of information matrix
    arma::vec info_middle = arma::vectorise(information_middle);
    arma::sp_mat middle(data->dim * orders.n_obs_effective, data->dim * orders.n_obs_effective);
    middle.diag() = arma::vectorise( info_middle );

    // Get Information and Information with correlation
    arma::mat derivatives = estimation.derivatives;

    arma::mat information_estimate = derivatives.t() * middle * derivatives / orders.n_obs_effective;
    arma::mat information_with_correlation(orders.n_param, orders.n_param);
    
    arma::mat temp(data->dim, orders.n_param);
    arma::vec score_temp(orders.n_param);
    for(unsigned int t = 0; t < orders.n_obs_effective; t++){
        temp = derivatives.rows(t * data->dim, (t + 1) * data->dim - 1);
        score_temp = temp.t() * weighted_residuals.col(t);
        information_with_correlation += score_temp * score_temp.t();
    }
    information_with_correlation = information_with_correlation / orders.n_obs_effective;
    information_estimate = arma::inv_sympd(information_estimate);
    arma::mat variance_est = (information_estimate * information_with_correlation * information_estimate);

    
    
    arma::mat test_values(time_points.n_elem, locations.n_elem);
    arma::mat link_derivative_intervention(data->dim, data->n_obs);
    arma::mat temp_ma_design(data->dim, orders.n_param_ma);
    arma::mat information_correlation_expanded(orders.n_param + 1, orders.n_param + 1);
    arma::vec score_temp_expanded(orders.n_param + 1);
    arma::vec score_expanded(orders.n_param + 1);
    arma::vec information_expanded(orders.n_param + 1);
    arma::vec param_ma;
    arma::vec deriv_interv_vec;
    arma::mat variance_adjust(1, 1);
    if(orders.n_param_ma > 0)
    {
        param_ma = estimation.parameter.subvec(orders.n_param_intercept, orders.n_param_intercept + orders.n_param_ma - 1); 
    }
    for(unsigned int j = 0; j < locations.n_elem; j++)
    {
        for(unsigned int i = 0; i < time_points.n_elem; i++)
        {
            information_correlation_expanded.zeros();
            score_expanded.zeros();
            score_temp_expanded.zeros();
            // Create Intervention covariate
            arma::uvec tp = time_points.subvec(i, i);
            arma::uvec loc = locations.subvec(j, j);
            Intervention interv(tp, loc, intervention_param, data->dim, 0);
            // Calculate Score and Variance:
            for(unsigned int t = orders.max_time_lag; t < data->n_obs; t++)
            {
                link_derivative_intervention.col(t) = interv.get_values_at(t);
                if(orders.n_param_ma > 0)
                {
                    unsigned int index = 0;
                    for(unsigned int j = 0; j < orders.ma_time_lags.n_elem; j++)
                    {
                        arma::uvec orders_lag = arma::find( orders.moving_average_orders.col(j) );
                        for(unsigned int o : orders_lag)
                        {
                            temp_ma_design.col(index) = link_derivative_intervention.col(t - orders.ma_time_lags(j));
                            if(external)
                            {
                                temp_ma_design.col(index) -= interv.get_values_at(t - orders.ma_time_lags(j));
                            }
                            temp_ma_design.col(index) = data->multiply_neigh_with_x(o, temp_ma_design.col(index));
                            index++;
                        }
                    }
                    link_derivative_intervention.col(t) += temp_ma_design * param_ma;
                }
                
                temp = derivatives.rows((t - orders.max_time_lag) * data->dim, (t - orders.max_time_lag + 1) * data->dim - 1);
                score_temp_expanded.head(orders.n_param) = temp.t() * weighted_residuals.col(t - orders.max_time_lag);
                score_temp_expanded.tail(1) = link_derivative_intervention.col(t).t() * weighted_residuals.col(t - orders.max_time_lag);
                information_correlation_expanded += score_temp_expanded * score_temp_expanded.t();
                score_expanded += score_temp_expanded;
            }
            information_correlation_expanded = information_correlation_expanded / orders.n_obs_effective;
            deriv_interv_vec = arma::vectorise( link_derivative_intervention.tail_cols(orders.n_obs_effective) );
            information_expanded.head(orders.n_param) = derivatives.t() * middle * deriv_interv_vec;
            information_expanded.tail(1) = deriv_interv_vec.t() * middle * deriv_interv_vec;
            information_expanded = information_expanded / orders.n_obs_effective;
            variance_adjust(0, 0) = information_correlation_expanded(orders.n_param, orders.n_param);
            variance_adjust -= 2.0 * information_expanded.head(orders.n_param).t() * information_estimate * information_correlation_expanded.col(orders.n_param).head(orders.n_param);
            variance_adjust += information_expanded.head(orders.n_param).t() * variance_est * information_expanded.head(orders.n_param);

            // Calculate Test-Statistic:
            test_values.submat(i, j, i, j) = (score_expanded(orders.n_param) * score_expanded(orders.n_param)) / variance_adjust;
        }
    }
    return test_values / orders.n_obs_effective;
}


/*
    TODO in R:
    Ueberpruefen ob Copula in Family vorhanden
    Falls ja, dann Copula-Objekt erstellen
    Falls nein, dann Copula-Objekt erstellen (falls Argument verwendet)
    Falls Argument = NULL, dann unter unabhaengigkeit
    Falls Copula in Family vorhanden und Argument verwendet, dann Warnmeldung und ueberschreiben (Argument verwenden)
*/


/*
// [[Rcpp::export]]
arma::vec bootstrap_intervention(Rcpp::XPtr<glmstarma> result_ptr, const arma::uvec& time_points, const arma::uvec& locations, const arma::vec& intervention_param, const Rcpp::LogicalVector& external, const unsigned int B, const int n_cores, const Rcpp::LogicalVector& display_progress, const Rcpp::List& family, const Rcpp::Nullable<Rcpp::S4> copula_obj){
    // Get Model Information:
    glmstarma * ptr = result_ptr.get();
    arma::vec param = ptr->estimation->parameter;
    ModelOrderInformation orders = *(ptr->orders);
    arma::mat init = ptr->estimation->link_init + 0.001;
    arma::mat design_covariates_internal = ptr->estimation->design_covariates_internal;

    // Family neu erstellen
    Family * fam;
    if(copula_obj.isNotNull())
    {
        Rcpp::S4 copula_object(copula_obj);
        fam = generate_family_from_list(family, copula_object);
    } 
    else 
    {
        fam = generate_family_from_list(family);
    }

    arma::vec results(B);
    if(display_progress[0]){
        Rcpp::Rcout << "Start of " << B << " bootstrap iterations.\n";
    }
    #pragma omp parallel for num_threads(n_cores)
    for(unsigned int i = 0; i < B; i++)
    {
        Data * cloned_data = ptr->data->clone();
        // 1. Daten aus Modell simulieren
        arma::mat link_val(cloned_data->dim, cloned_data->n_obs);
        cloned_data->ts = glmstarma_sim_internal(param, orders, link_val, ptr->data, fam, orders.max_time_lag, cloned_data->dim, init, true);
        cloned_data->transformed_obs = fam->observation_trafo(cloned_data->ts);
        // 2. Design und Ableitungen initialisieren
        DynamicModelInformation model_infos(param, orders, cloned_data, fam, init);
        // 3. Teststatistik bestimmen
        arma::mat test_values = detect_intervention(orders, cloned_data, model_infos, fam, time_points, locations, intervention_param, external[0]);
        results(i) = test_values.max();
    }
    return results;
}
*/


/*
// [[Rcpp::export]]
arma::vec bootstrap_intervention(Rcpp::XPtr<glmstarma> result_ptr, const arma::uvec& time_points, const arma::uvec& locations, const arma::vec& intervention_param, const Rcpp::LogicalVector& external, const unsigned int B, const int n_cores, const Rcpp::List& family, const Rcpp::Nullable<Rcpp::S4> copula_obj){
    // Get Model Information:
    glmstarma * ptr = result_ptr.get();
    arma::vec param = ptr->estimation->parameter;
    ModelOrderInformation orders = *(ptr->orders);
    arma::mat init = ptr->estimation->link_init + 0.001;
    arma::mat design_covariates_internal = ptr->estimation->design_covariates_internal;

    // Family neu erstellen
    Family * fam;
    if(copula_obj.isNotNull())
    {
        Rcpp::S4 copula_object(copula_obj);
        fam = generate_family_from_list(family, copula_object);
    } 
    else 
    {
        fam = generate_family_from_list(family);
    }

    arma::vec results(B);

    // Parallelisierte Schleife
    int iters_per_thread = B / n_cores;
    int iters_left = B % n_cores;
    // Starte die Arbeit in der äußeren Schleife
    std::vector<std::future<void>> futures;
    std::mutex resultsMutex;
    // std::vector<std::thread> threads;
    int start = 0;
    int end;

    for(unsigned int threadID = 0; threadID < n_cores; threadID++)
    {
        int iterations = iters_per_thread + (threadID < iters_left ? 1 : 0);
        end = start + iterations;
        futures.push_back(std::async(std::launch::async, [param, orders, ptr, fam, init, time_points, locations, intervention_param, external, start, end, &results, &resultsMutex]() {
            std::unique_lock<std::mutex> lock1(resultsMutex);
            Data * cloned_data = ptr->data->clone();
            arma::vec par = param;
            arma::uvec tp = time_points;
            arma::uvec loc = locations;
            arma::vec inp = intervention_param;
            bool externa = external[0];
            ModelOrderInformation ord(orders);
            // Family * fami = fam->clone();
            arma::mat inita = init;
            lock1.unlock();
            for(unsigned int i = start; i < end; i++)
            {
                // 1. Daten aus Modell simulieren
                arma::mat link_val(cloned_data->dim, cloned_data->n_obs);
                std::unique_lock<std::mutex> lock2(resultsMutex);
                cloned_data->ts = glmstarma_sim_internal(par, ord, link_val, cloned_data, fam, ord.max_time_lag, cloned_data->dim, inita, true);
                cloned_data->transformed_obs = fam->observation_trafo(cloned_data->ts);
                lock2.unlock();
                // 2. Design und Ableitungen initialisieren
                DynamicModelInformation model_infos(par, ord, cloned_data, fam, inita);
                // 3. Teststatistik bestimmen
                arma::mat test_values = detect_intervention(ord, cloned_data, model_infos, fam, tp, loc, inp, externa);
                // std::lock_guard<std::mutex> lock(resultsMutex);
                results(i) = test_values.max();
            }
        }));
        start = end;
        Rcpp::Rcout << "Bootstrap 1." << threadID << "\n";
    }
    // Warte auf das Ende aller Threads
    for (auto& future : futures) {
        future.wait();
    }
    Rcpp::Rcout << "Bootstrap 2\n";
    return results;
}
*/

/*
void bootstrap_iteration(std::vector<double> &result_double, unsigned int i, const glmstarma * ptr, const ModelOrderInformation &orders, const arma::mat &init, const Family * fam, const arma::vec &param, const arma::uvec &time_points, const arma::uvec &locations, const arma::vec &intervention_param, const bool &ext)
{
    std::unique_lock<std::mutex> lock1(resultsMutex);
    Data * cloned_data = ptr->data->clone();
    arma::vec par = param;
    arma::uvec tp = time_points;
    arma::uvec loc = locations;
    arma::vec inp = intervention_param;
    bool externa = ext;
    ModelOrderInformation ord(orders);
    Family * fami = fam->clone();
    arma::mat inita = init;
    lock1.unlock();
    // 1. Daten aus Modell simulieren
    arma::mat link_val(cloned_data->dim, cloned_data->n_obs);
    // std::unique_lock<std::mutex> lock2(resultsMutex);
    cloned_data->ts = glmstarma_sim_internal(par, ord, link_val, cloned_data, fami, ord.max_time_lag, cloned_data->dim, inita, true);
    // lock2.unlock();
    cloned_data->transformed_obs = fami->observation_trafo(cloned_data->ts);
    // 2. Design und Ableitungen initialisieren
    DynamicModelInformation model_infos(par, ord, cloned_data, fami, inita);
    // 3. Teststatistik bestimmen
    // std::unique_lock<std::mutex> lock3(resultsMutex);
    arma::mat test_values = detect_intervention(ord, cloned_data, model_infos, fami, tp, loc, inp, externa);
    // lock3.unlock();
    // std::unique_lock<std::mutex> lock(resultsMutex);
    result_double[i] = test_values.max();
    // lock.unlock();
}
*/


// [[Rcpp::export]]
arma::vec bootstrap_intervention(Rcpp::XPtr<glmstarma> result_ptr, const arma::uvec& time_points, const arma::uvec& locations, const arma::vec& intervention_param, const Rcpp::LogicalVector& external, const unsigned int B, const int n_cores, const Rcpp::List& family, const Rcpp::Nullable<Rcpp::S4> copula_obj){
    // Get Model Information:
    glmstarma * ptr = result_ptr.get();
    arma::vec param = ptr->estimation->parameter;
    ModelOrderInformation orders = *(ptr->orders);
    arma::mat init = ptr->estimation->link_init + 0.001;
    arma::mat design_covariates_internal = ptr->estimation->design_covariates_internal;

    // Family neu erstellen
    Family * fam;
    if(copula_obj.isNotNull())
    {
        Rcpp::S4 copula_object(copula_obj);
        fam = generate_family_from_list(family, copula_object);
    } 
    else 
    {
        fam = generate_family_from_list(family);
    }

    arma::vec results(B);
    std::vector<double> result_double(B);
    bool ext = external[0];

    // Parallelisierte Schleife
    // Starte die Arbeit in der äußeren Schleife
    std::mutex resultsMutex;
    RcppThread::ThreadPool pool(n_cores);

    auto task = [&result_double, &resultsMutex] (unsigned int start, unsigned int end, const glmstarma * ptr, const ModelOrderInformation &orders, const arma::mat &init, const Family * fam, const arma::vec &param, const arma::uvec &time_points, const arma::uvec &locations, const arma::vec &intervention_param, const bool &ext){
        std::unique_lock<std::mutex> lock1(resultsMutex);
        Data * cloned_data = ptr->data->clone();
        arma::vec par = param;
        arma::uvec tp = time_points;
        arma::uvec loc = locations;
        arma::vec inp = intervention_param;
        bool externa = ext;
        ModelOrderInformation ord(orders);
        Family * fami = fam->clone();
        arma::mat inita = init;
        lock1.unlock();
        for(unsigned int i = start; i < end; i++)
        {
            // 1. Daten aus Modell simulieren
            arma::mat link_val(cloned_data->dim, cloned_data->n_obs);
            std::unique_lock<std::mutex> lock2(resultsMutex);
            cloned_data->ts = glmstarma_sim_internal(par, ord, link_val, cloned_data, fami, ord.max_time_lag, cloned_data->dim, inita, true);
            lock2.unlock();
            cloned_data->transformed_obs = fami->observation_trafo(cloned_data->ts);
            // 2. Design und Ableitungen initialisieren
            DynamicModelInformation model_infos(par, ord, cloned_data, fami, inita);
            // 3. Teststatistik bestimmen
            // std::unique_lock<std::mutex> lock3(resultsMutex);
            arma::mat test_values = detect_intervention(ord, cloned_data, model_infos, fami, tp, loc, inp, externa);
            // lock3.unlock();
            // std::unique_lock<std::mutex> lock(resultsMutex);
            result_double[i] = test_values.max();
            // lock.unlock();
        }
    };


    // Parallelisierte Schleife
    int iters_per_thread = B / n_cores;
    int iters_left = B % n_cores;
    int start = 0;
    int end;


    for(unsigned int i = 0; i < n_cores; i++)
    {
        int iterations = iters_per_thread + (i < iters_left ? 1 : 0);
        end = start + iterations;
        pool.push(task, start, end, ptr, orders, init, fam, param, time_points, locations, intervention_param, ext);
        start = end;
    }
    // Warte auf das Ende aller Threads
    pool.join();

    for(unsigned int i = 0; i < B; i++)
    {
        results(i) = result_double[i];
    }
    return results;
}



// [[Rcpp::export]]
arma::mat detect_intervention(Rcpp::XPtr<glmstarma> result_ptr, const arma::uvec& time_points, const arma::uvec& locations, const arma::vec& intervention_param, const Rcpp::LogicalVector& external)
{
    glmstarma * ptr = result_ptr.get();
    return detect_intervention(*(ptr->orders), ptr->data, *(ptr->estimation), ptr->family, time_points, locations, intervention_param, external[0]);
}







// Muss noch aktualisiert werden:

/*




// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include "glmstarma.h"

#include <chrono>
#include <thread>
#include <iostream>
#include <vector>
#include <future>
// [[Rcpp::depends(RcppProgress)]]
#include <progress.hpp>
#include <progress_bar.hpp>

// Add a flag to enable OpenMP at compile time

// Protect against compilers without OpenMP
#ifdef _OPENMP
#include <omp.h>
#endif
// [[Rcpp::plugins(openmp)]]
using namespace std::this_thread;
using namespace std::chrono_literals;
using namespace Rcpp;



// TODO: Fehlermeldung wenn Zeitpunkt kleiner als Maximalier zeitlag uebergeben wird





// Parallelisierte Berechnung der Teststatistik

// ChatGPT Variante
arma::mat detect_intervention_parallel(Model model, Data * data, arma::uvec time_points, arma::uvec locations, arma::vec intervention_param, Rcpp::CharacterVector var_estimation, Rcpp::LogicalVector adjust, int n_cores){
    // Erzeugen der Matrix fuer Rueckgabe:
    arma::mat test_values(time_points.n_elem, locations.n_elem);

    // Konstanten abspeichern:
    const unsigned int n_params = model.n_param + 1;
    const unsigned int ts_dim = data->dim;
    const unsigned int n_obs = data->n_obs;
    const unsigned int index = model.n_param; // Index fuer die Intervention
    const bool sandwich = (var_estimation[0] == "sandwich");

    // Varianz des bereits geschaetzen Modells abspeichern:
    arma::mat variance = arma::inv_sympd(model.information / model.n_obs_effective);
    arma::mat information_inv = variance;
    if(sandwich){
        variance = variance * (model.information_with_correlation / model.n_obs_effective) * variance;
    }

    // Matrizen bei Regression auf vergangene Linkwerte initialisieren um wiederholte Berechnung zu vermeiden.
    if(model.n_param_ma > 0){
        data->set_param_matrices(model.moving_average);
    }


    // Parallelisiert mit Hilfe von ChatGPT
    int outerLoopStep = time_points.n_elem / n_cores;
    int remainderThreads = time_points.n_elem % n_cores;
    // Starte die Arbeit in der äußeren Schleife
    std::vector<std::future<void>> futures;
    int start = 0;
    int end;

    for (unsigned int threadID = 0; threadID < n_cores; threadID++) {
        int numSteps = outerLoopStep + (threadID < remainderThreads ? 1 : 0);
        end = start + numSteps;
        // Starte die Arbeit für die aktuellen Schleifenschritte in einem separaten Thread
        futures.emplace_back(std::async(std::launch::async, [locations, time_points, model, data, variance, intervention_param, information_inv, sandwich, start, end, &test_values]() {
            for (int i = start; i < end; ++i) {
                for (int j = 0; j < locations.n_elem; ++j) {
                    arma::uvec tp = time_points.subvec(i, i);
                    arma::uvec loc = locations.subvec(j, j);
                    Intervention interv(tp, loc, intervention_param, data->dim, 0);
                    test_values(i, j) = calc_test_value(model, data, interv, variance, information_inv, sandwich);
                }
            }
        }));
        start = end;
    }
    // Warte auf das Ende aller Threads
    for (auto& future : futures) {
        future.get();
    }

    return test_values;
}


// OMP Variante
arma::mat detect_intervention_parallel(Model model, Data * data, arma::uvec time_points, arma::uvec locations, arma::vec intervention_param, Rcpp::CharacterVector var_estimation, int n_cores){
    // Erzeugen der Matrix fuer Rueckgabe:
    arma::mat test_values(time_points.n_elem, locations.n_elem);

    // Konstanten abspeichern:
    // const unsigned int n_params = model.n_param + 1;
    // const unsigned int ts_dim = data->dim;
    // const unsigned int n_obs = data->n_obs;
    // const unsigned int index = model.n_param; // Index fuer die Intervention
    const bool sandwich = (var_estimation[0] == "sandwich");

    // Varianz des bereits geschaetzen Modells abspeichern:
    arma::mat variance = arma::inv_sympd(model.information / model.n_obs_effective);
    arma::mat information_inv = variance;
    if(sandwich){
        variance = variance * (model.information_with_correlation / model.n_obs_effective) * variance;
    }

    // Matrizen bei Regression auf vergangene Linkwerte initialisieren um wiederholte Berechnung zu vermeiden.
    if(model.n_param_ma > 0){
        data->set_param_matrices(model.moving_average);
    }

    #pragma omp parallel for num_threads(n_cores)
    for (int i = 0; i < time_points.n_elem; i++) {
        for (int j = 0; j < locations.n_elem; j++) {
            arma::uvec tp = time_points.subvec(i, i);
            arma::uvec loc = locations.subvec(j, j);
            Intervention interv(tp, loc, intervention_param, data->dim, 0);
            test_values(i, j) = calc_test_value(model, data, interv, variance, information_inv, sandwich);
        }
    }
    return test_values;
}


// [[Rcpp::export]]
arma::mat detect_intervention(Rcpp::XPtr<glmstarma> result_ptr, arma::uvec time_points, arma::uvec locations, arma::vec intervention_param, Rcpp::CharacterVector var_estimation, Rcpp::LogicalVector adjust){
    glmstarma * ptr = result_ptr.get();
    Model model_fitted = *ptr->model;
    return detect_intervention(model_fitted, ptr->data, time_points, locations, intervention_param, var_estimation, adjust);
}


// [[Rcpp::export]]
arma::mat detect_intervention_parallel(Rcpp::XPtr<glmstarma> result_ptr, arma::uvec time_points, arma::uvec locations, arma::vec intervention_param, Rcpp::CharacterVector var_estimation, Rcpp::LogicalVector adjust, int n_cores){
    glmstarma * ptr = result_ptr.get();
    Model model_fitted = *ptr->model;
    return detect_intervention_parallel(model_fitted, ptr->data, time_points, locations, intervention_param, var_estimation, adjust, n_cores);
}

// [[Rcpp::export]]
arma::mat detect_intervention_parallel(Rcpp::XPtr<glmstarma> result_ptr, arma::uvec time_points, arma::uvec locations, arma::vec intervention_param, Rcpp::CharacterVector var_estimation, Rcpp::LogicalVector adjust, int n_cores){
    glmstarma * ptr = result_ptr.get();
    Model model_fitted = *ptr->model;
    return detect_intervention_parallel(model_fitted, ptr->data, time_points, locations, intervention_param, var_estimation, n_cores);
}



// [[Rcpp::export]]
double bootstrap_iteration(Rcpp::XPtr<glmstarma> result_ptr, arma::uvec time_points, arma::uvec locations, arma::vec intervention_param, Rcpp::CharacterVector var_estimation, Rcpp::LogicalVector adjust){
    glmstarma * ptr = result_ptr.get();
    Model model_fitted(ptr->model);
    Data * data = ptr->data->clone();
    glmstarma_sim_internal(model_fitted, data, model_fitted.max_time_lag, data->dim);

    model_fitted.initialize_design(data);
    bool update = model_fitted.update_if_valid(model_fitted.parameter_vector, data);
    if(!update){
        Rcpp::warning("Parameter Vector is not valid\n");
    }
    arma::mat values = detect_intervention(model_fitted, data, time_points, locations, intervention_param, var_estimation, adjust);
    return values.max();
}


// [[Rcpp::export]]
double bootstrap_iteration_parallel(Rcpp::XPtr<glmstarma> result_ptr, arma::uvec time_points, arma::uvec locations, arma::vec intervention_param, Rcpp::CharacterVector var_estimation, Rcpp::LogicalVector adjust, int n_cores){
    glmstarma * ptr = result_ptr.get();
    Model model_fitted(ptr->model);
    Data * data = ptr->data->clone();
    glmstarma_sim_internal(model_fitted, data, model_fitted.max_time_lag, data->dim);

    model_fitted.initialize_design(data);
    bool update = model_fitted.update_if_valid(model_fitted.parameter_vector, data);
    if(!update){
        Rcpp::warning("Parameter Vector is not valid\n");
    }
    arma::mat values = detect_intervention_parallel(model_fitted, data, time_points, locations, intervention_param, var_estimation, n_cores);
    return values.max();
}


// [[Rcpp::export]]
arma::vec bootstrap_parallel(Rcpp::XPtr<glmstarma> result_ptr, arma::uvec time_points, arma::uvec locations, arma::vec intervention_param, Rcpp::CharacterVector var_estimation, Rcpp::LogicalVector adjust, int B, int n_cores, bool display_progress){
    arma::vec results(B);
    if(display_progress){
        Rcpp::Rcout << "Start of " << B << "bootstrap iterations.\n";
    }
    Progress prog(B, display_progress);
    for(int i = 0; i < B; i++){
        if(Progress::check_abort()){
            return results;
        }
        results(i) = bootstrap_iteration_parallel(result_ptr, time_points, locations, intervention_param, var_estimation, adjust, n_cores);
        prog.increment();
    }
    return results;
    
}

// [[Rcpp::export]]
arma::vec bootstrap(Rcpp::XPtr<glmstarma> result_ptr, arma::uvec time_points, arma::uvec locations, arma::vec intervention_param, Rcpp::CharacterVector var_estimation, Rcpp::LogicalVector adjust, int B, int n_cores, bool display_progress){
    arma::vec results(B);
    if(display_progress){
        Rcpp::Rcout << "Start of " << B << "bootstrap iterations.\n";
    }
    Progress prog(B, display_progress);
    for(int i = 0; i < B; i++){
        if(Progress::check_abort()){
            return results;
        }
        results(i) = bootstrap_iteration(result_ptr, time_points, locations, intervention_param, var_estimation, adjust);
        prog.increment();
    }
    return results;
    
}

*/

