print.summary.glmstarma <- function(x, digits = max(3L, getOption("digits") - 3L), signif.stars = getOption("show.signif.stars"), ...){
    cat("\nCall:\n", paste(deparse(x$call), sep = "\n", collapse = "\n"), "\n\n", sep = "")
    cat("\nCoefficients:\n")
    printCoefmat(x$coefficients, digits = digits, signif.stars = signif.stars, na.print = "NA", ...)

    cat("\nMarginal Distribution: ", x$distribution, "\n", sep = "")
    cat("Link: ", x$link, "\n", sep = "")

    cat("\nNumber of coefficients: ", x$df, "\n", sep = "")
    cat("\nQuasi-Log-Likelihood: ", x$log_likelihood, "\n", sep = "")
    cat("AIC: ", x$aic, "\n", sep = "")
    cat("BIC: ", x$bic, "\n", sep = "")
    cat("QIC: ", x$qic, "\n", sep = "")
    cat("\n")
    invisible(x)
}