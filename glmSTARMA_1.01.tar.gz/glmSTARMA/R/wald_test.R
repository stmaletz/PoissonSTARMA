# Funktion - wald.test
# Führt einen asymptotischen Wald-Test für übergebene Hypothesen durch
# Input:
# - object - Objekt der Klasse glmstarma
# - intercept - Logischer Wert, ob auf einen inhomogenen Intercept getestet werden soll oder nicht.
# - params - Index-Vektor für Koeffizienten die auf Signifikanz untersucht werden sollen
# - hypothesis - Matrix, die eine Hypothese bestimmt auf die getestet werden soll.
# - c0 - Optionaler Vektor, der die Hypothese beeinflussen kann. Siehe Details.

# Output:
# - Liste mit Teststatistiken und p-Werten der Tests

# TODO: Approximation der Verteilung bzw. p-Werte fuer lineares Modell ueberpruefen

wald.test <- function(object, intercept = FALSE, params = NULL, hypothesis = NULL, c0 = NULL){
    result <- list()
    variance <- variance_estimation(object$model_pointer)
    if(intercept){
        stopifnot("Testing for an homogenous intercept is only possible if an inhomogenous model was fitted" = object$model$intercept == "inhomogeneous")
        # Add error if time-constant covariates are present
        C_matrix <- cbind(diff(diag(object$target_dim)), matrix(0, ncol = length(coef(object)) - object$target_dim, nrow = object$target_dim - 1))
        statistics <- drop(t(C_matrix %*% coef(object)) %*% solve(C_matrix %*% variance %*% t(C_matrix)) %*% (C_matrix %*% coef(object)))
        p.value <- pchisq(statistics, object$target_dim - 1, lower.tail = FALSE)
        result$intercept <- list(statistics = statistics, p.value = p.value)
    }
    if(!is.null(params)){
        # TODO: Check auf Ganzzahligkeit
        stopifnot("params has to be a vector of indices for the coefficients" = is.numeric(params))
        C_matrix <- matrix(0, ncol = length(coef(object)), nrow = length(coef(object)))
        diag(C_matrix)[params] <- 1
        statistics <- drop(t(C_matrix %*% coef(object)) %*% solve(C_matrix %*% variance %*% t(C_matrix)) %*% (C_matrix %*% coef(object)))
        p.value <- pchisq(statistics, length(params), lower.tail = FALSE)
        result$params <- list(statistics = statistics, p.value = p.value)
    }
    if(!is.null(hypothesis)){
        stopifnot("hypothesis has to be supplied as a matrix" = is.matrix(hypothesis),
                  "number of columns does not match the length of coefficients" = ncol(hypothesis) == length(coef(object)))
        degrees <- qr(hypothesis)$rank
        if(is.null(c0)){
            c0 <- rep(0, nrow(hypothesis))
        }
        statistics <- drop(t(hypothesis %*% coef(object) - c0) %*% solve(hypothesis %*% variance %*% t(hypothesis)) %*% (hypothesis %*% coef(object) - c0))
        p.value <- pchisq(statistics, degrees, lower.tail = FALSE)
        result$hypothesis <- list(statistics = statistics, p.value = p.value)      
    }
    class(result) <- "wald.glmstarma"
    return(result)
}