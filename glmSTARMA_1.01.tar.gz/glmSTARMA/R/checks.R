# Function for checking the model orders and time lags submitted to glmstarma
# Input:
# - orders:
# - time_lags
# Output: named list with orders in the correct form and the corresponding time-lags

check_orders <- function(orders, time_lags){
  stopifnot("Model orders must be numeric or logical" = is.numeric(orders) || is.logical(orders),
            "Model orders must be submitted as vector or matrix" = is.vector(orders) || is.matrix(orders))
  if(!is.null(time_lags)){
    stopifnot("Time lags must be numeric" = is.numeric(time_lags),
              "Time lags must be positive" = all(time_lags > 0L),
              "Time-lags must be unique" = all(!duplicated(time_lags)))
    time_lags <- floor(time_lags)
  }
  
  if(!is.matrix(orders)){
    if(is.null(time_lags)){
      time_lags <- seq(1, length(orders), by = 1L)
    } else {
      stopifnot("The number of time lags submitted does not equal the number of time-lags to be regressed on" = length(time_lags) == length(orders))
    }
    
    stopifnot("Model orders must be NA or >= -1" = all(is.na(orders) | orders >= -1 ))
    orders <- floor(orders)
    orders[is.na(orders)] <- -1L
    time_lags <- time_lags[orders >= 0L]
    orders <- orders[orders >= 0L]
    order_matrix <- matrix(0L, ncol = length(orders), nrow = max(c(1, orders + 1)))
    for(i in seq_along(orders)){
      order_matrix[seq(orders[i] + 1), i] <- 1L
    }
  } else {
    if(is.null(time_lags)){
      time_lags <- seq(1, ncol(orders), by = 1L)
    } else {
      stopifnot("The number of time lags submitted does not equal the number of time-lags to be regressed on" = length(time_lags) == ncol(orders))
    }
    stopifnot("Orders must be submitted binary" = all(orders == 0 | orders == 1) || is.logical(orders))
    orders <- 1 * orders
    # remove all zero columns
    non_zeros <- !apply(orders, 2, function(y) all(y == 0))
    time_lags <- time_lags[non_zeros]
    orders <- orders[, non_zeros, drop = FALSE]
    highest_order <- max(which(apply(orders, 1, function(y) any(y != 0L))))
    order_matrix <- orders[seq(highest_order),, drop = FALSE]
  }
  
  row.names(order_matrix) <- paste0("s_", seq(0, nrow(order_matrix) - 1))
  colnames(order_matrix) <- paste0("t_", time_lags)
  return(list(orders = order_matrix, time_lags = time_lags))
}

# Function for checking parameters submitted for simulation

param_check <- function(parameters, orders){
    stopifnot("Parameters must be submitted as numeric values in a matrix or vector" = is.numeric(parameters))
    if(is.matrix(parameters)){
        stopifnot("The parameters submitted do not match the model orders" = all(dim(parameters) == dim(orders)))
        if(any((parameters != 0) & (orders == 0))){
            warning(
                "There are parameters not equal to 0 which are ignored due to the model specification"
            )
            parameters[(parameters != 0) & (orders == 0)] <- 0
        }
        return(parameters)
    } else {
        stopifnot("The number of parameters submitted does not match the number of parameters required by the model orders" = length(parameters) == sum(orders))
        param_temp <- orders
        param_temp[orders != 0] <- parameters
        return(param_temp)
    }
}

# Funktion zum ueberpruefen der Modellspezifikation.
# Es werden die Eingaben fuer das Modellfitting usw. angepasst und vereinheitlicht

model.check <- function(model){
    stopifnot("'model' has to be a list" = is.list(model))

    # Check model regarding intercept:
    model$intercept <- match.arg(model$intercept, c("homogeneous", "inhomogeneous"))

    # Checking for Autoregressive specification:
    if(is.null(model$past_obs)){
        stop("Models without regression on past observations are not supported")
    } else {
        check <- check_orders(model$past_obs, model$past_obs_time_lags)
        model$past_obs <- check$orders
        model$past_obs_time_lags <- check$time_lags
    }

    # Checking for Moving Average specification:
    if(!is.null(model$past_mean)) {
        check <- check_orders(model$past_mean, model$past_mean_time_lags)
        model$past_mean <- check$orders
        model$past_mean_time_lags <- check$time_lags
    }
    
    # Checking for Covariate specification:
    if(!is.null(model$covariates)) {
        check <- check_orders(model$covariates, NULL)
        model$covariates <- check$orders
        if(is.null(model$external)){
            model$external <- integer(ncol(model$covariates))
        } else {
            stopifnot("Length of external does not match the number of covariates" = length(model$external) == ncol(model$covariates))
            model$external <- as.integer((as.logical(model$external)))
        }
    }
    return(model)
}

model_and_parameter.check <- function(model, parameters, dim){
    stopifnot("'model' has to be a list" = is.list(model),
              "intercept parameter is missing" = !is.null(model$intercept),
              "autoregressive parameters are missing" = !is.null(model$past_obs))

    # Check model regarding intercept:
    model$intercept <- match.arg(model$intercept, c("homogeneous", "inhomogeneous"))
    if(model$intercept == "homogeneous"){
        stopifnot("The number of intercept parameters submitted does not match the model" = length(parameters$intercept) == 1)
    } else {
        stopifnot("The number of intercept parameters submitted does not match the model" = length(parameters$intercept) == dim)
    }
    # Checking for Autoregressive specification:
    if(is.null(model$past_obs)){
        stop("Models without regression on past observations are not supported")
    } else {
        check <- check_orders(model$past_obs, model$past_obs_time_lags)
        model$past_obs <- check$orders
        model$past_obs_time_lags <- check$time_lags
        parameters$past_obs <- param_check(parameters$past_obs, check$orders)
        stopifnot("Models without regression on past observations are not supported" = any(model$past_obs != 0) && any(parameters$past_obs != 0))
        row.names(parameters$past_obs) <- row.names(check$orders)
        colnames(parameters$past_obs) <- colnames(check$orders)
    }

    # Checking for Moving Average specification:
    if(!is.null(model$past_mean)) {
        check <- check_orders(model$past_mean, model$past_mean_time_lags)
        model$past_mean <- check$orders
        model$past_mean_time_lags <- check$time_lags
        parameters$past_mean <- param_check(parameters$past_mean, check$orders)
        if(all(model$past_mean == 0) && all(parameters$past_mean == 0)){
            model$past_mean <- NULL
            model$past_mean_time_lags <- NULL
            parameters$past_mean <- NULL
        } else {
            row.names(parameters$past_mean) <- row.names(check$orders)
            colnames(parameters$past_mean) <- colnames(check$orders)
        }
    }
    
    # Checking for Covariate specification:
    if(!is.null(model$covariates)) {
        check <- check_orders(model$covariates, NULL)
        model$covariates <- check$orders
        parameters$covariates <- param_check(parameters$covariates, check$orders)
        if(all(model$covariates == 0) && all(parameters$covariates == 0)){
            model$covariates <- NULL
            model$external <- NULL
            parameters$covariates <- NULL
        } else {
            row.names(parameters$covariates) <- row.names(check$orders)
            colnames(parameters$covariates) <- colnames(check$orders) # Noch anpassen
        }
    }
    return(list(model = model, parameters = parameters))
}

wlist.check <- function(wlist){
    stopifnot("All elements of the wlists must be matrices" = all(sapply(wlist, is.matrix)),
             "All matrices must have the same dimensions" = length(unique(c(sapply(wlist, dim)))) == 1,
             "The matrices must contain non-negative values" = all(sapply(wlist, function(x) all(x >= 0))))
}







