# Falls in model fuer covariate keine Ordnungen uebergeben werden, aber Kovariablen vorhanden sind, dann wird die Ordnung 0 gewaehlt und fuer wlist_covariates die Einheitsmatrix gewaehlt, sofern nichts anderes uebergeben wurde
# Falls Ordnungen gewaehlt werden, so wird wlist_covariates verwendet und falls dies NULL ist, wird wlist verwendet

glmstarma.sim <- function(ntime, parameters, model, wlist, covariates = list(), wlist_covariates = NULL, family = vpoisson(), n_start = 50, control = list()){
  require(copula)
  stopifnot("ntime must be a numeric value" = is.numeric(ntime),
            "covariates must be submitted in a list" = is.list(covariates),
            "wlist must be a list of numeric matrices" = is.list(wlist),
            "wlist_covariates must be a list of matrices" = is.null(wlist_covariates) | is.list(wlist_covariates),
            "n_start must be numeric" = is.numeric(n_start),
            "parameters must be submitted in a list" = is.list(parameters),
            "control must be a list" = is.list(control),
            "wlist must not be an empty list" = length(wlist) > 0)

    wlist.check(wlist)
    dim <- ncol(wlist[[1]])
    if(is.null(model$covariates) && length(covariates) > 0){
        model$covariates <- rep(0, length(covariates))
        model$external <- integer(length(covariates))
        if(is.null(wlist_covariates)){
            wlist_covariates = list(diag(dim))
        }
    }
    if(!is.null(model$covariates) && is.null(wlist_covariates)){
        wlist_covariates = wlist
    } else if(!is.null(wlist_covariates)) {
        wlist.check(wlist_covariates)
        stopifnot("Dimensions of matrices in wlist and wlist_covariates do not match" = nrow(wlist[[1]]) == nrow(wlist_covariates[[1]]))
    }
    if(!is.null(model$covariates) && is.null(model$external)){
        model$external <- integer(length(covariates))
    } 




    temp <- model_and_parameter.check(model, parameters, dim)
    model <- temp$model
    parameters <- temp$parameters

    max_order <- nrow(model$past_obs)
    if(!is.null(model$past_mean)){
        max_order <- max(max_order, nrow(model$past_mean))
    }
    stopifnot("Too few matrices in wlist" = length(wlist) >= max_order)
    wlist <- wlist[seq(length = max_order)]
    if(!is.null(model$covariates)){
        stopifnot("Model orders for covariates do not match the number of covariates" = ncol(model$covariates) == length(covariates),
                  "Too few matrices in wlist_covariates" = length(wlist_covariates) >= nrow(model$covariates))
        wlist_covariates <- wlist_covariates[seq(length = nrow(model$covariates))] 
    }
    control$parameter_init <- parameters
    control <- do.call("glmstarma_sim.control", control)
      
    if(!is.null(family$copula)){
        if(family$copula %in% c("normal", "t")){
            copula_obj <- ellipCopula(family$copula, param = family$copula_param, dim = nrow(wlist[[1]]))
        } else {
            copula_obj <- archmCopula(family$copula, param = family$copula_param, dim = nrow(wlist[[1]]))
        }
    } else {
        copula_obj <- NULL
    }
    result <- glmstarma_sim_cpp(ntime, parameters, model, wlist, family, covariates, wlist_covariates, copula_obj, n_start, control)
    return(result)
}