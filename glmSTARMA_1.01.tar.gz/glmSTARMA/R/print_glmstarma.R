print.glmstarma <- function(x, digits = max(3, getOption("digits") - 3), ...){
    cat("\nCall:\n", paste(deparse(x$call), sep = "\n", collapse = "\n"), "\n\n", sep = "")
    if (length(coef(x)) > 0) {
        coefficents <- coef(x, TRUE)
        cat("Estimated Coefficients:\n")
        cat("Intercept:\n")
        print.default(format(drop(coefficents$intercept), digits = digits), print.gap = 2L, quote = FALSE)
        if(!is.null(coefficents$past_obs)){
            cat("\nAutoregressive Coefficients:\n")
            ar <- format(coefficents$past_obs, digits = digits)
            ar[x$model$past_obs == 0] <- "."
            colnames(ar) <- colnames(x$model$past_obs)
            row.names(ar) <- row.names(x$model$past_obs)
            print.default(ar, print.gap = 2L, quote = FALSE)
            cat("\n")
        }
        if(!is.null(coefficents$past_mean)){
          cat("\nMoving-Average Coefficients:\n")
            ma <- format(coefficents$past_mean, digits = digits)
            ma[x$model$past_mean == 0] <- "."
            colnames(ma) <- colnames(x$model$past_mean)
            row.names(ma) <- row.names(x$model$past_mean)
            print.default(ma, print.gap = 2L, quote = FALSE)
            cat("\n")
        }
        if(!is.null(coefficents$covariates)){
          cat("\nCovariate Coefficients:\n")
            cova <- format(coefficents$covariates, digits = digits)
            cova[x$model$covariates == 0] <- "."
            colnames(cova) <- colnames(x$model$covariates)
            row.names(cova) <- row.names(x$model$covariates)
            print.default(cova, print.gap = 2L, quote = FALSE)
            cat("\n")
        }
  } else {
    cat("No coefficients\n")
  }
  invisible(x)
}