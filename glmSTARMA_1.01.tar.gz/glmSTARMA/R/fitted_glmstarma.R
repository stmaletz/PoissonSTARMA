fitted.glmstarma <- function(object, drop_init = TRUE){
    if(drop_init){
        return(object$fitted.values[,-seq(length(object$max_time_lag))])
    }
    return(object$fitted.values)
}