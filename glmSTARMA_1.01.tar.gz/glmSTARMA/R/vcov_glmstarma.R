vcov.glmstarma <- function(object){
    return(variance_estimation(object$model_pointer))
}