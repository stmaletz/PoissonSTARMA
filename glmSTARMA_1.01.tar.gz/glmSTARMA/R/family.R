#TODO:
# Argumente bei anderen Verteilungen:
# - Obere und Untere Grenze
# - Wertebereich (natuerliche Zahlen oder reelle Zahlen)

vpoisson <- function(link = c("log", "identity", "sqrt", "softplus"), const = 1, copula = NULL, copula_param = NULL, fast_sampling = FALSE){
  fam <- list()
  fam$link <- match.arg(link)
  fam$distribution <- "poisson"
  fam$non_negative_parameters <- FALSE
  if(fam$link %in% c("identity", "sqrt")){
    fam$non_negative_parameters <- TRUE
  }
  fam$const <- const
  ## moegliche Copulas:
  if(!is.null(copula)){
    fam$copula <- match.arg(copula, c("normal", "t", "clayton", "frank", "gumbel", "joe"))
    fam$copula_param <- copula_param
    fam$fast_sampling <- fast_sampling
  } else {
    fam$copula <- NULL
    fam$copula_param <- NULL
    fam$fast_sampling <- NULL
  }
  class(fam) <- "stfamily"
  return(fam)
}

vnegative.binomial <- function(link = c("log", "identity", "sqrt", "softplus"), dispersion = NULL, const = 1, copula = NULL, copula_param = NULL){
  if(is.null(dispersion)){
    stop("'dispersion' must be specified in the Negative-Binomial distribution")
  }
  fam <- list()
  fam$link <- match.arg(link)
  fam$distribution <- "negative_binomial"
  fam$non_negative_parameters <- FALSE
  fam$dispersion <- dispersion
  if(fam$link %in% c("identity", "sqrt")){
    fam$non_negative_parameters <- TRUE
  }
  fam$const <- const
  ## moegliche Copulas:
  if(!is.null(copula)){
    fam$copula <- match.arg(copula, c("normal", "t", "clayton", "frank", "gumbel", "joe"))
    fam$copula_param <- copula_param
  } else {
    fam$copula <- NULL
    fam$copula_param <- NULL
  }
  class(fam) <- "stfamily"
  return(fam)
}


vbinomial <- function(link = c("softclipping", "identity", "logit", "probit", "log", "cloglog"), size = 1, const = NULL, transform_obs = FALSE, copula = NULL, copula_param = NULL){
  fam <- list()
  fam$link <- match.arg(link)
  fam$distribution <- "binomial"
  fam$non_negative_parameters <- FALSE
  fam$transform_obs <- transform_obs
  if(transform_obs && is.null(const)){
    fam$const <- 1e-5
  }
  if(link == "softclipping" && is.null(const)){
    fam$const <- 1
  }
  if(fam$link %in% c("identity", "sqrt")){
    fam$non_negative_parameters <- TRUE
  }
  fam$size <- size
  ## moegliche Copulas:
  if(!is.null(copula)){
    fam$copula <- match.arg(copula, c("normal", "t", "clayton", "frank", "gumbel", "joe"))
    fam$copula_param <- copula_param
  } else {
    fam$copula <- NULL
    fam$copula_param <- NULL
  }
  class(fam) <- "stfamily"
  return(fam)
}


vgamma <- function(link = c("inverse", "log", "identity"), shape = NULL, copula = NULL, copula_param = NULL){
  fam <- list()
  fam$link <- match.arg(link)
  fam$distribution <- "gamma"
  fam$non_negative_parameters <- FALSE

  if(is.null(shape)){
    fam$dispersion <- shape
    fam$shape <- 1.0
  } else {
    fam$dispersion <- 1 / shape
    fam$shape <- shape
  }
  if(fam$link %in% c("identity", "inverse")){
    fam$non_negative_parameters <- TRUE
  }
  ## moegliche Copulas:
  if(!is.null(copula)){
    fam$copula <- match.arg(copula, c("normal", "t", "clayton", "frank", "gumbel", "joe"))
    fam$copula_param <- copula_param
  } else {
    fam$copula <- NULL
    fam$copula_param <- NULL
  }
  class(fam) <- "stfamily"
  return(fam)
}


vinverse.gaussian <- function(link = c("1/mu^2", "inverse", "identity", "log"), shape = NULL, copula = NULL, copula_param = NULL){
  fam <- list()
  fam$link <- match.arg(link)
  fam$distribution <- "inverse_gaussian"
  fam$non_negative_parameters <- FALSE

  if(is.null(shape)){
    fam$dispersion <- shape
    fam$shape <- 1.0
  } else {
    fam$dispersion <- shape
    fam$shape <- shape
  }
  if(fam$link %in% c("1/mu^2", "identity", "inverse")){
    fam$non_negative_parameters <- TRUE
  }
  ## moegliche Copulas:
  if(!is.null(copula)){
    fam$copula <- match.arg(copula, c("normal", "t", "clayton", "frank", "gumbel", "joe"))
    fam$copula_param <- copula_param
  } else {
    fam$copula <- NULL
    fam$copula_param <- NULL
  }
  class(fam) <- "stfamily"
  return(fam)
}


vnormal <- function(link = c("identity", "log", "inverse"), sigma2 = NULL, copula = NULL, copula_param = NULL){
  fam <- list()
  fam$link <- match.arg(link)
  fam$distribution <- "gaussian"
  fam$non_negative_parameters <- FALSE

  if(is.null(sigma2)){
    fam$dispersion <- sigma2
    fam$sigma2 <- 1.0
  } else {
    fam$dispersion <- sigma2
    fam$sigma2 <- sigma2
  }
  ## moegliche Copulas:
  if(!is.null(copula)){
    fam$copula <- match.arg(copula, c("normal", "t", "clayton", "frank", "gumbel", "joe"))
    fam$copula_param <- copula_param
  } else {
    fam$copula <- NULL
    fam$copula_param <- NULL
  }
  class(fam) <- "stfamily"
  return(fam)
}


vgarch <- function(link = c("identity", "log"), copula = NULL, copula_param = NULL){
  fam <- list()
  fam$link <- match.arg(link)
  fam$distribution <- "garch"
  fam$non_negative_parameters <- FALSE

  ## moegliche Copulas:
  if(!is.null(copula)){
    fam$copula <- match.arg(copula, c("normal", "t", "clayton", "frank", "gumbel", "joe"))
    fam$copula_param <- copula_param
  } else {
    fam$copula <- NULL
    fam$copula_param <- NULL
  }
  class(fam) <- "stfamily"
  return(fam)
}








print.stfamily <- function(x, ...){
  cat("\nMarginal distribution:", x$distribution, "\n")
  cat("Link function:", x$link, "\n\n")
  invisible(x)
}

