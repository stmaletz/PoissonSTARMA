residuals.glmstarma <- function(object, type = c("response", "pearson"), drop_init = TRUE){
    type <- match.arg(type)
    res <- object$ts - object$fitted.values
    if(type == "pearson"){
        res <- res / sqrt(object$fitted.values)
    }
    if(drop_init){
        res <- res[, -seq(length(object$max_time_lag))]
    }
    return(res)
}