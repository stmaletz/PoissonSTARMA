BIC.glmstarma <- function(object){
    return(object$bic)
}