#' Zusammenfassungsmethode für glmstarma-Objekte
#'
#' Diese Funktion gibt eine Zusammenfassung eines glmstarma-Modells zurück. Sie berechnet verschiedene Statistiken und 
#' Diagnosemaße, einschließlich der Koeffizientenschätzungen, Standardfehler, z-Werte und p-Werte.
#'
#' @param object Ein glmstarma-Objekt.
#' 
#' @return Eine Liste mit den folgenden Elementen:
#'   * call: Der ursprüngliche Funktionsaufruf.
#'   * coefficients: Ein Datenrahmen mit den Koeffizientenschätzungen, Standardfehlern, z-Werten und p-Werten.
#'   * distribution: Die Verteilung der Familie des glmstarma-Modells.
#'   * link: Die Link-Funktion der Familie des glmstarma-Modells.
#'   * df: Die Anzahl der Koeffizienten im Modell.
#'   * log_likelihood: Die Log-Likelihood des Modells.
#'   * aic: Das Akaike-Informationskriterium des Modells.
#'   * bic: Das Bayes'sche Informationskriterium des Modells.
#'   * qic: Das Quasi-Informationskriterium des Modells.
#' 
#' @examples
#' # Erstellen Sie ein glmstarma-Objekt und rufen Sie die Zusammenfassungsmethode auf
#' model <- glmstarma(y ~ x)
#' summary(model)

summary.glmstarma <- function(object){
    cl <- object$call
    if(length(coef(object) > 0)){
        ll <- logLik(object)
        k <- length(coef(object))
        n <- object$n_obs_effective

        # Create row-names
        if(object$model$intercept == "homogeneous"){
            param_names <- "(Intercept)"
        } else {
            param_names <- paste0("(Intercept ", seq(object$target_dim), ")")
        }
        if(!is.null(object$coefficients_list$past_mean)){
            name_temp <- outer(row.names(object$model$past_mean), colnames(object$model$past_mean), paste, sep = ", ")[object$model$past_mean == 1]
            name_temp <- paste0("past_mean_{", name_temp, "}")
            param_names <- c(param_names, name_temp)
        }
        if(!is.null(object$coefficients_list$past_obs)){
            name_temp <- outer(row.names(object$model$past_obs), colnames(object$model$past_obs), paste, sep = ", ")[object$model$past_obs == 1]
            name_temp <- paste0("past_obs_{", name_temp, "}")
            param_names <- c(param_names, name_temp)
        }
        if(!is.null(object$coefficients_list$covariates)){
            name_temp <- outer(colnames(object$model$covariates), row.names(object$model$covariates), paste, sep = "_{")[object$model$covariates == 1]
            name_temp <- paste0(name_temp, "}")
            param_names <- c(param_names, name_temp)
        }
        se <- sqrt(diag(vcov(object)) / n)
        z_values <- coef(object) / se
        p_vals <- 2 * pnorm(abs(z_values), lower.tail = FALSE)
        if(object$family$non_negative_parameters){
            p_vals <- p_vals / 2
        }
        results <- data.frame(Estimate = coef(object), "Std. Error" = se, "z value" = z_values, p.values = p_vals)
        names(results) <- c("Estimate", "Std. Error", "z value", "Pr(>|z|)")
        row.names(results) <- param_names

        result <- list(call = cl, coefficients = results, distribution = object$family$distribution, link = object$family$link, df = length(coef(object)), log_likelihood = object$log_likelihood, aic = object$aic, bic = object$bic, qic = object$qic)
    } else {
        result <- list(call = cl)
    }
    class(result) <- "summary.glmstarma"
    return(result)
}