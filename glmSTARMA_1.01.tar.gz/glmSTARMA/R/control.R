# Zu beruecksichtigende Kontroll-Parameter:
# parameter_init
# return_burn_in
# init_link -> parameter erlaubt oder Matrix uebergabe
# use_sparsity = TRUE
# sparsity_threshold = 2 / 3


glmstarma_sim.control <- function(parameter_init = list(), return_burn_in = FALSE, init_link = "parameter", use_sparsity = TRUE, sparsity_threshold = 2 / 3){
    stopifnot("init_link must be 'parameter' or a matrix with first link-values" = (init_link == "parameter") || is.matrix(init_link))
    stopifnot("'return_burn_in' must be logical" = is.logical(return_burn_in))
    stopifnot("'use_sparsity' must be logical" = is.logical(use_sparsity))
    stopifnot("'sparsity_threshold' must be a numeric between 0 and 1" = is.numeric(sparsity_threshold) && sparsity_threshold >= 0 && sparsity_threshold <= 1)
    return(list(parameter_init = parameter_init, return_burn_in = return_burn_in, init_link = init_link, use_sparsity = use_sparsity, sparsity_threshold = sparsity_threshold))
}



#TODO: Ueberpruefungen ergaenzen.
#glmstarma.control <- function(numBasis = 10L, max_iter = 500L, min_score = 1e-6, min_step = 1e-6, max_iters_inside = 10L, max_iter_total = 1000L, penalty = 1e-2,
#                                parameter_init = "zero", return_burn_in = FALSE, init_link = "mean", use_sparsity = TRUE, sparsity_threshold = 2 / 3, variance_estimation = "sandwich", use_fastglm = TRUE, fast_tol = 1e-14){
#    return(list(numBasis = numBasis, max_iter = max_iter, min_score = min_score, min_step = min_step, max_iters_inside = max_iters_inside, max_iter_total = max_iter_total, penalty = penalty,
#                                parameter_init = parameter_init, return_burn_in = return_burn_in, init_link = init_link, use_sparsity = use_sparsity, sparsity_threshold = sparsity_threshold, fast_tol = fast_tol, use_fastglm = use_fastglm, variance_estimation = variance_estimation))
#}

## Argument fuer negative: ignore, clamp, refit

glmstarma.control <- function(parameter_init = "zero", return_burn_in = FALSE, init_link = "first_obs", use_sparsity = TRUE, sparsity_threshold = 2 / 3, 
                                method = NULL, negative_params = "refit", constrained = TRUE, constraint_tol = 1e-8, gradtol = sqrt(.Machine$double.eps), changetol = sqrt(.Machine$double.eps),
                                trace = 0L, fnscale = 1.0, maxit = 100L, abstol = -Inf, reltol = sqrt(.Machine$double.eps), lmm = 5, factr = 1e7, pgtol = 0.0){
    if(is.character(parameter_init)){
        parameter_init <- match.arg(parameter_init, c("zero", "random", "lm")) # Evtl. noch andere Methoden ergaenzen
    } else {
        stopifnot("If not automatically chosen, parameters must be submitted as list" = is.list(parameter_init))
    }
    
    if(is.character(init_link)){
        init_link <- match.arg(init_link, c("first_obs", "mean", "transformed_mean", "parameter", "zero"))
    } else {
        stopifnot("init_link has to be a character or a matrix" = is.matrix(init_link))
    }
    

    method <- match.arg(method, c("fisher", "optim", "fastglm", "nloptr"))
    if(method == "fastglm"){
        stopifnot("fastglm could not be loaded" = require("fastglm"))
    }
    if(method == "nloptr"){
        stopifnot("nloptr could not be loaded" = require("nloptr"))
    }
    negative_params <- match.arg(negative_params, c("refit", "ignore", "clamp"))
    return(list(negative_params = negative_params, constrained = constrained, constraint_tol = constraint_tol, parameter_init = parameter_init, return_burn_in = return_burn_in, init_link = init_link, use_sparsity = use_sparsity, sparsity_threshold = sparsity_threshold, method = method,
                                trace = trace, gradtol = gradtol, changetol = changetol, fnscale = fnscale, maxit = maxit, abstol = abstol, reltol = reltol, lmm = lmm, factr = factr, pgtol = pgtol))
}






#glmstarma.control <- function(parameter_init = list(), init_link = "mean", use_sparsity = TRUE, sparsity_threshold = 2 / 3){
#    stopifnot("init_link must be 'parameter' or a matrix with first link-values" = (init_link == "parameter") || is.matrix(init_link))
#    stopifnot("'return_burn_in' must be logical" = is.logical(return_burn_in))
#    stopifnot("'use_sparsity' must be logical" = is.logical(use_sparsity))
#    stopifnot("'sparsity_threshold' must be a numeric between 0 and 1" = is.numeric(sparsity_threshold) && sparsity_threshold >= 0 && sparsity_threshold <= 1)
#    return(list(parameter_init = parameter_init, return_burn_in = return_burn_in, init_link = init_link, use_sparsity = use_sparsity, sparsity_threshold = sparsity_threshold))
#}

