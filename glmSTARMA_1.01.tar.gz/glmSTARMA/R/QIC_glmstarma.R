QIC <- function(...) UseMethod("QIC")

QIC.glmstarma <- function(object){
    return(object$qic)
}