predict.glmstarma <- function(object, n.ahead = 1, type = c("response", "link", "sample"), newobs = NULL, newxreg = NULL){
    if(!is.null(object$family$copula)){
        if(object$family$copula %in% c("normal", "t")){
            copula_obj <- ellipCopula(object$family$copula, param = object$family$copula_param, dim = object$target_dim)
        } else {
            copula_obj <- archmCopula(object$family$copula, param = object$family$copula_param, dim = object$target_dim)
        }
    } else {
        copula_obj <- NULL
    }

    #TODO: Checks der Eingaben hinzufuegen.
    glmstarma_predict(object$model_pointer, type, newobs, newxreg, n.ahead, copula_obj)
}