# Funktionen zum fitten:

glmstarma <- function(ts, model = list(), wlist, covariates = NULL, wlist_covariates = NULL, family = vpoisson(), control = list()){
    stopifnot("covariates must be submitted in a list" = is.null(covariates) || is.list(covariates),
            "wlist must be a list of numeric matrices" = is.list(wlist),
            "wlist_covariates must be a list of matrices" = is.null(wlist_covariates) | is.list(wlist_covariates),
            "control must be a list" = is.list(control),
            "wlist must not be an empty list" = length(wlist) > 0)
    wlist.check(wlist)
    dim <- ncol(wlist[[1]])
    if(is.null(model$covariates) && length(covariates) > 0){
        model$covariates <- rep(0, length(covariates))
        if(is.null(wlist_covariates)){
            wlist_covariates <- list(diag(dim))
        }
    }
    if(!is.null(model$covariates) && is.null(wlist_covariates)){
        wlist_covariates <- wlist
    } else if(!is.null(wlist_covariates)) {
        wlist.check(wlist_covariates)
        stopifnot("Dimensions of matrices in wlist and wlist_covariates do not match" = nrow(wlist[[1]]) == nrow(wlist_covariates[[1]]))
    }
    model <- model.check(model)
    max_order <- nrow(model$past_obs)
    if(!is.null(model$past_mean)){
        max_order <- max(max_order, nrow(model$past_mean))
    }
    stopifnot("Too few matrices in wlist" = length(wlist) >= max_order)
    if(!is.null(model$covariates)){
        stopifnot("Model orders for covariates do not match the number of covariates" = ncol(model$covariates) == length(covariates),
                  "Too few matrices in wlist_covariates" = length(wlist_covariates) >= nrow(model$covariates))
        if(is.null(names(covariates))){
            colnames(model$covariates) <- paste0("X", seq(length(covariates)))
        } else {
            names_temp <- names(covariates)
            names_temp[names_temp == ""] <- paste0("X", which(names_temp == ""))
            colnames(model$covariates) <- names_temp
        }
        ## TODO: Check for categorical covariates
        wlist_covariates <- wlist_covariates[seq(length = nrow(model$covariates))] 
    }

    if(is.null(control$method)){
        if(family$non_negative_parameters){
            control$method <- "optim"
        } else {
            control$method <- "fisher"
        }
    }
    control <- do.call("glmstarma.control", control) 

    result <- glmstarma_cpp(ts, model, wlist, covariates, wlist_covariates, family, control)

    result_list <- get_results(result)
    result_list$model <- model
    result_list$family <- family
    result_list$model_pointer <- result
    result_list$call <- match.call()
    
    # TODO: Eingabeparameter zuerueckgeben:
    result_list$ts <- ts

    class(result_list) <- "glmstarma"
    return(result_list)
}