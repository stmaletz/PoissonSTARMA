# Funktionen zum fitten:

stGARCH <- function(ts, model = list(), wlist, covariates = NULL, wlist_covariates = NULL, link = c("identity", "log"), control = list()){
    errors <- ts^2
    link <- match.arg(link)
    garch_family <- vgarch(link)
    result_list <- glmstarma(errors, model, wlist, covariates, wlist_covariates, garch_family, control)
    result_list$ts <- ts
    result_list$squared_errors <- errors
    result_list$call <- match.call()
    class(result_list) <- c("stgarch", "glmstarma")
    return(result_list)
}