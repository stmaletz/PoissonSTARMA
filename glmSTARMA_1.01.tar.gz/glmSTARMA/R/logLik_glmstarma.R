logLik.glmstarma <- function(object){
    return(object$log_likelihood)
}