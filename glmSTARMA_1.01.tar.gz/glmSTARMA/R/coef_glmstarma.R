coef.glmstarma <- function(object, asList = FALSE){
    if(asList){
        return(object$coefficients_list)
    } else {
        return(drop(object$coefficients))
    }
}