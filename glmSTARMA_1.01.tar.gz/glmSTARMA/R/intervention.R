# Funktionen zum Fitten der Interventionen:

# Input:
# - model: mit glmstarma geschaetzes Modell ohne Interventionen unter H0.
# - time_points: Vektor mit Zeitpunkten an denen auf eine Intervention getestet wird.
# - locations: Vektor mit numerischen Indizes der Orte an denen auf eine Intervention getestet wird
# - intervention_param: Interventionsparameter der die Art der Intervention festlegt (mehrere Werte zulassen????)
# - external: Als externe oder interne Intervention? -> Kein Einfluss auf Teststatisitk

# - p_vals = c("bootstrap", "analytical")
# - B : Anzahl an Bootstrapwiederholungen
# - n.core: Anzahl verwendeter Kerne fuer Bootstraps
# - estimate_intervention: Intervention am Ende schaetzen?


# TODO: Analytische Verteilung der Test-Statistik
# TODO: Schaetzung der Intervention einbauen.
# TODO: Ueberpruefung der Eingabeparameter
# TODO: Seed setzen moeglich machen


intervention.test <- function(model, time_points, locations, intervention_param, external = FALSE, 
                              p_vals = c("bootstrap", "analytic"), B = 500L, n.cores = 1L,
                              copula = NULL, copula_param = NULL,
                              estimate_intervention = FALSE){
    p_vals <- match.arg(p_vals)
    
    # Berechne Teststatistik:
    test_values <- detect_intervention(model$model_pointer, time_points, locations, intervention_param, external)
    # Finde Index des maximalen Interventionswertes
    test.statistic <- max(test_values)
    index <- which(test_values == test.statistic, arr.ind = TRUE) 
    tp_intervention <- time_points[index[1, 1]]
    loc_intervention <- locations[index[1, 2]]

    if(p_vals == "bootstrap"){
        if(!is.null(copula)){
            if(!is.null(model$family$copula)){
                warning("The family used for fitting the model already includes a copula. If you want to use this, set copula = NULL.")
            }
            if(copula %in% c("normal", "t")){
                copula_obj <- ellipCopula(copula, param = copula_param, dim = model$target_dim)
            } else {
                copula_obj <- archmCopula(copula, param = copula_param, dim = model$target_dim)
            }
        } else if(!is.null(model$family$copula)){
            if(model$family$copula %in% c("normal", "t")){
                copula_obj <- ellipCopula(model$family$copula, param = model$family$copula_param, dim = model$target_dim)
            } else {
                copula_obj <- archmCopula(model$family$copula, param = model$family$copula_param, dim = model$target_dim)
            }
        } else {
            copula_obj <- NULL
        }
        bootstraps <- bootstrap_intervention(model$model_pointer, time_points, locations, intervention_param, external, B, n.cores, model$family, copula_obj)
        p.value <- mean(test.statistic >= c(test.statistic, bootstraps))
    } else {
        if(length(time_points) > 1 || length(locations) > 1){
            warning("Analytic distribution of test-statistic is unknown")
        }
        p.value <- pchisq(test.statistic, 1, lower.tail = FALSE)
    }
    result_list <- list(test.statistic = test.statistic, p.value = p.value, intervention = list(time_point = tp_intervention, location = loc_intervention))
    return(result_list)
}

