AIC.glmstarma <- function(object, k = 2){
    return(-2 * object$log_likelihood + k * length(object$coefficients))
}