# Functions for generating the W matrices

# Input:
# - method      - character out of
#                   'full'        - full model of Fokianos (p^2 matrices are generated)
#                   'independent' - independent time series (p matrices are generated)
#                   'circle'      - matrices for circle neighborhood
#                   'line'        - matrices for line neighborhood
#                   'rectangle'   - matrices for rectangle neighborhood
# - dim           - dimension of target
# - maxOrder    - spatial order up to which the matrices are required
# - width       - parameter for method 'rectangle' indicating the width of the rectangle



generateW <- function(method = c("rectangle", "line", "circle", "full", "independent"), dim, maxOrder, width){
  method <- match.arg(method)
  pars <- list(dim = dim, maxOrder = maxOrder)
  if(method %in% c("full", "independent"))
    pars <- list(dim = dim)
  if(method == "rectangle")
    pars <- list(dim = dim, maxOrder = maxOrder, width = width)
  toCall <- paste0("generateW.", method)
  return(do.call(toCall, pars))
}


generateW.full <- function(dim){
  W <- vector(mode = "list", length = dim^2)
  for(i in seq(dim^2)){
    vec <- numeric(dim^2)
    vec[i] <- 1
    W[[i]] <- matrix(vec, nrow = dim, ncol = dim)
  }
  return(W)
}

generateW.independent <- function(dim){
  W <- vector(mode = "list", length = dim)
  index <- 1 - (dim + 1)
  for(i in seq(dim)){
    vec <- numeric(dim^2)
    index <- index + (dim + 1)
    vec[index] <- 1
    W[[i]] <- matrix(vec, nrow = dim, ncol = dim)
  }
  return(W)
}

generateW.line <- function(dim, maxOrder){
  if(maxOrder > floor(dim / 2)){
    stop("maxOrder must not be larger than floor(dim/2)")
  }
  if(maxOrder == -1){
    return(list(matrix(0, dim, dim)))
  }
  if(maxOrder == 0){
    return(list(diag(dim)))
  }
  result <- vector(mode = "list", length = maxOrder + 1)
  distances <- as.matrix(dist(seq(dim)))
  rownames(distances) <- NULL
  colnames(distances) <- NULL
  for(l in seq(from = 0, to = maxOrder, by = 1L)){
    result[[l + 1]] <- 1 * (distances == l)
    result[[l + 1]] <- result[[l + 1]] / rowSums(result[[l + 1]])
  }
  return(result)
}

generateW.circle <- function(dim, maxOrder){
  if(maxOrder > floor(dim / 2)){
    warning("maxOrder should not be larger than floor(dim/2) for identifiability of the model")
  }
  if(maxOrder == -1){
    return(list(matrix(0, dim, dim)))
  }
  if(maxOrder == 0){
    return(list(diag(dim)))
  }
  #x <- 1:p / p * 2 * pi
  #dist <- as.matrix(dist(cbind(sin(x), cos(x))))
  #dist <- round(dist, digits = 8)
  result <- vector(mode = "list", length = maxOrder + 1)
  result[[1]] <- diag(dim)
  for(l in seq(from = 1, to = maxOrder, by = 1L)){
    result[[l + 1]] <- matrix(0, nrow = dim, ncol = dim)
    for(i in seq(dim)){
      indexes <- c(-l, l) + i
      indexes <- ifelse(indexes < 1, indexes + dim, indexes)
      indexes <- ifelse(indexes > dim, indexes - dim, indexes)
      result[[l + 1]][i, indexes] <- ifelse(diff(indexes) == 0, 1, 0.5)
    }
  }
  return(result)
}

generateW.rectangle <- function(dim, width, maxOrder){
  height <- dim / width
  if(dim %% width != 0){
    stop("'dim' has to be in the form dim = witdh * a for a natural number a")
  }
  if(maxOrder == -1){
    return(list(matrix(0, dim, dim)))
  }
  if(maxOrder == 0){
    return(list(diag(dim)))
  }
  coordinates <- expand.grid(x = seq(width), y = seq(height))
  distances <- as.matrix(dist(coordinates)^2)
  uni_dist <- sort(unique(as.numeric(distances)))
  rownames(distances) <- NULL
  colnames(distances) <- NULL
  result <- vector(mode = "list", length = maxOrder + 1)
  for(l in seq(0L, maxOrder, by = 1L)){
    result[[l + 1]] <- 1 * (distances == uni_dist[l + 1])
    result[[l + 1]] <- result[[l + 1]] / rowSums(result[[l + 1]])
  }
  return(result)
}


