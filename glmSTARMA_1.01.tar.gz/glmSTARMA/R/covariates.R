# Funktionen mit denen gewisse Kovariablen erzeugt werden koennen

TimeConstant <- function(x){
  if(!is.numeric(x)){
    stop("For now only numeric covariates are allowed.")
  }
  attr(x, "const") <- "time"
  return(x)
}

SpatialConstant <- function(x){
  if(!is.numeric(x)){
    stop("For now only numeric covariates are allowed.")
  }
  attr(x, "const") <- "space"
  return(x)
}

Intervention <- function(tp, dim, intensities){
  if(length(tp) != length(dim) && length(tp) != 1){
    stop("tp has to have the same length as dim or length 1.")
  }
  if(length(intensities) != length(dim) && length(intensities) != 1){
    stop("intensities has to have the same length as dim or length 1.")
  }
  if(any(intensities > 1) || any(intensities < 0)){
    stop("intensities must have values in [0, 1].")
  }
  covariate <- list(time_points = tp, dimensions = dim, intensities = intensities)
  attr(covariate, "intervention") <- "intervention"
  return(covariate)
}